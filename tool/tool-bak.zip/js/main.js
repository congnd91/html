(function ($) {
  $(document).on('ready', function () {
    var db = new Object();
    db.preLoad = function () {
      $('.page-loader').delay(800).fadeOut(600, function () {
        $('body').fadeIn();
      });

      $(".custom-file-input").on("change", function () {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
      });

      $('.file-import-settings').click(function () {
        var x = $('.box-settings');
        if ($(x).is(":visible")) {
          $(x).slideUp();
        } else {
          $(x).slideDown();
        }
        return false;
      });

      $('.add-more').click(function () {

        var id = $(this).attr('data-id');
        // alert(id);

        $(id).parent().append($(id).clone());
        //  $(this).parent(".text-right").prev().append($('.item-cop-wrap').children().first().clone());

        // $('.item-cop-wrap').append($('.item-cop-wrap').children().first().clone());
        return false;
      });



    }
    db.menu = function () {
      $('.menu-icon').click(function () {
        $('body').toggleClass("open-menu");
      });
    }

    db.preLoad();
    db.menu();
  });
})(jQuery);
