<?php
include_once 'header.php';
$values['admin_notes'] = "Lorem Ipsum";
$values['application_status'] = "Lorem Ipsum";
$values['applicant_name'] = "Lorem Ipsum";
$values['applicant_email'] = "Lorem Ipsum";
$values['applicant_address'] = "Lorem Ipsum";
$values['applicant_location'] = "Lorem Ipsum";
$values['applicant_phone'] = "Lorem Ipsum";
$values['applicant_dob'] = "Lorem Ipsum";
$values['applicant_birth_loc'] = "Lorem Ipsum";
$values['applicant_us_citizen'] = "Lorem Ipsum";
$values['applicant_time_us'] = "Lorem Ipsum";
$values['applicant_disabilities'] = "Lorem Ipsum";
$values['maternal_name'] = "Lorem Ipsum";
$values['maternal_phone'] = "Lorem Ipsum";
$values['maternal_address'] = "Lorem Ipsum";
$values['maternal_employer_loc'] = "Lorem Ipsum";
$values['maternal_time_us'] = "Lorem Ipsum";
$values['maternal_occupation'] = "Lorem Ipsum";
$values['maternal_employer'] = "Lorem Ipsum";
$values['maternal_reg_contact'] = "Lorem Ipsum";
$values['maternal_last_contact'] = "Lorem Ipsum";
$values['paternal_name'] = "Lorem Ipsum";
$values['paternal_phone'] = "Lorem Ipsum";
$values['paternal_address'] = "Lorem Ipsum";
$values['paternal_employer_loc'] = "Lorem Ipsum";
$values['paternal_time_us'] = "Lorem Ipsum";
$values['paternal_occupation'] = "Lorem Ipsum";
$values['paternal_employer'] = "Lorem Ipsum";
$values['paternal_reg_contact'] = "Lorem Ipsum";
$values['paternal_last_contact'] = "Lorem Ipsum";
$values['guardian_name'] = "Lorem Ipsum";
$values['guardian_phone'] = "Lorem Ipsum";
$values['guardian_address'] = "Lorem Ipsum";
$values['guardian_employer_loc'] = "Lorem Ipsum";
$values['guardian_time_us'] = "Lorem Ipsum";
$values['guardian_occupation'] = "Lorem Ipsum";
$values['guardian_employer'] = "Lorem Ipsum";
$values['guardian_reg_contact'] = "Lorem Ipsum";
$values['guardian_last_contact'] = "Lorem Ipsum";
$values['applicant_siblings'] = "Lorem Ipsum";
$values['guardians_income'] = "Lorem Ipsum";
$values['guardians_support'] = "Lorem Ipsum";
$values['hs_name'] = "Lorem Ipsum";
$values['hs_city'] = "Lorem Ipsum";
$values['hs_state'] = "Lorem Ipsum";
$values['hs_gpa'] = "Lorem Ipsum";
$values['hs_transcript'] = "Lorem Ipsum";
$values['sat_verbal'] = "Lorem Ipsum";
$values['sat_math'] = "Lorem Ipsum";
$values['hs_extras'] = "Lorem Ipsum";
$values['grad_date'] = "Lorem Ipsum";
$values['hs_employment'] = "Lorem Ipsum";
$values['target_postsec_name'] = "Lorem Ipsum";
$values['target_postsec_city'] = "Lorem Ipsum";
$values['target_postsec_state'] = "Lorem Ipsum";
$values['target_major'] = "Lorem Ipsum";
$values['tuition_assistance'] = "Lorem Ipsum";
$values['tuition_contributing'] = "Lorem Ipsum";
$values['tuition_gap'] = "Lorem Ipsum";
$values['longform1'] = "Lorem Ipsum";
$values['longform2'] = "Lorem Ipsum";
$values['longform3'] = "Lorem Ipsum";
$values['longform4'] = "Lorem Ipsum";
$values["hs_transcript"]= "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2aWNlUkdCCi9GaWx0ZXIgL0RDVERlY29kZQovSGVpZ2h0IDYwCi9MZW5ndGggMzM5NQovU3VidHlwZSAvSW1hZ2UKL1R5cGUgL1hPYmplY3QKL1dpZHRoIDIwMwo";
?>
    <div class="content">
        <form role="form" name="kmf-app-form" id="kmf-app-form" action="" enctype="multipart/form-data" method="post">
            <input type='hidden' name='id' value='<?php echo $id; ?>' />
            <div class="admin_btns">
                <div class="form-group">
                    <button class="btn btn-primary btn-step-4" type="submit" name="save">Save</button>
                    <!--<button class="btn btn-primary btn-step-4" type="submit" name="delete" >Delete</button> -->
                    <button class="btn btn-primary btn-step-4">Download</button>
                </div>
            </div>
            <div class="container container-form">

                <div class="mb-4 d-flex align-items-center">
                    <span class="caption">Admin Section</span>
                </div>
                <div class="row">

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <div>Admin Notes</div>
                            <textarea name="admin_notes" id="admin_notes"><?php echo $values['admin_notes']; ?></textarea>
                        </div>

                        <div class="form-group">
                            <div class="pt-3 radio-text">
                                <div class="">Application Status</div>
                                <input type="radio" id="application_status_approved" name="application_status" <?php if (isset($values[ 'application_status']) && $values[ 'application_status']=="approved" ) echo "checked";?> value="approved">Approved
                                <input type="radio" id="application_status_shortlist" name="application_status" <?php if (isset($values[ 'application_status']) && $values[ 'application_status']=="shortlist" ) echo "checked";?> value="shortlist">Shortlist
                                <input type="radio" id="application_status_deny" name="application_status" <?php if (isset($values[ 'application_status']) && $values[ 'application_status']=="deny" ) echo "checked";?> value="deny">Deny
                            </div>
                        </div>

                    </div>


                </div>

                <div class="mb-4 d-flex align-items-center">
                    <span class="caption">Personal and Family</span>
                </div>

                <div class="row">

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Name</span>

                            <p id="applicant_name">
                                <?php echo $values['applicant_name']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Email</span>
                            <p id="applicant_email">
                                <?php echo $values['applicant_email']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Home Address</span>
                            <p id="applicant_address">
                                <?php echo $values['applicant_address']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">City, State</span>
                            <p id="applicant_location">
                                <?php echo $values['applicant_location']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Telephone</span>
                            <p id="applicant_phone">
                                <?php echo $values['applicant_phone']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Date of Birth</span>
                            <p id="applicant_dob">
                                <?php echo $values['applicant_dob']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Place of Birth</span>
                            <p id="applicant_birth_loc">
                                <?php echo $values['applicant_birth_loc']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Are you a U.S. citizen</span>
                            <p id="applicant_us_citizen">
                                <?php echo $values['applicant_us_citizen']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">How long have you lived in the U.S.?</span>
                            <p id="applicant_time_us">
                                <?php echo $values['applicant_time_us']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">List any psychological and/or physical disabilities:</span>
                            <p id="applicant_disabilities">
                                <?php echo $values['applicant_disabilities']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="pb-5"></div>

                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Parent 1 Name</span>
                            <p id="maternal_name">
                                <?php echo $values['maternal_name']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Telephone</span>
                            <p id="maternal_phone">
                                <?php echo $values['maternal_phone']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Home Address</span>
                            <p id="maternal_address">
                                <?php echo $values['maternal_address']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">City, State</span>
                            <p id="maternal_employer_loc">
                                <?php echo $values['maternal_employer_loc']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Years in U.S.</span>
                            <p id="maternal_time_us">
                                <?php echo $values['maternal_time_us']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Occupation</span>
                            <p id="maternal_occupation">
                                <?php echo $values['maternal_occupation']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Employer</span>
                            <p id="maternal_employer">
                                <?php echo $values['maternal_employer']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Are you in regular contact?</span>
                            <p id="maternal_reg_contact">
                                <?php echo $values['maternal_reg_contact']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Date of last contact</span>
                            <p id="maternal_last_contact">
                                <?php echo $values['maternal_last_contact']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="pb-5"></div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Parent 2 Name</span>
                            <p id="paternal_name">
                                <?php echo $values['paternal_name']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Telephone</span>
                            <p id="paternal_phone">
                                <?php echo $values['paternal_phone']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Home Address</span>
                            <p id="paternal_address">
                                <?php echo $values['paternal_address']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">City, State</span>
                            <p id="paternal_employer_loc">
                                <?php echo $values['paternal_employer_loc']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Years in U.S.</span>
                            <p id="paternal_time_us">
                                <?php echo $values['paternal_time_us']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Occupation</span>
                            <p id="paternal_occupation">
                                <?php echo $values['paternal_occupation']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Employer</span>
                            <p id="paternal_employer">
                                <?php echo $values['paternal_employer']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Are you in regular contact?</span>
                            <p id="paternal_reg_contact">
                                <?php echo $values['paternal_reg_contact']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Date of last contact</span>
                            <p id="paternal_last_contact">
                                <?php echo $values['paternal_last_contact']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="pb-5"></div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">Guardian’s Name</span>
                            <p id="guardian_name">
                                <?php echo $values['guardian_name']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Telephone</span>
                            <p id="guardian_phone">
                                <?php echo $values['guardian_phone']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Home Address</span>
                            <p id="guardian_address">
                                <?php echo $values['guardian_address']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="review-field mb-3">
                            <span class="field-caption">City, State</span>
                            <p id="guardian_employer_loc">
                                <?php echo $values['guardian_employer_loc']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Years in U.S.</span>
                            <p id="guardian_time_us">
                                <?php echo $values['guardian_time_us']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Occupation</span>
                            <p id="guardian_occupation">
                                <?php echo $values['guardian_occupation']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Employer</span>
                            <p id="guardian_employer">
                                <?php echo $values['guardian_employer']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Are you in regular contact with them?</span>
                            <p id="guardian_reg_contact">
                                <?php echo $values['guardian_reg_contact']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Date of last contact</span>
                            <p id="guardian_last_contact">
                                <?php echo $values['guardian_last_contact']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Sibling(s) Name(s) and Age(s):</span>
                            <p id="applicant_siblings">
                                <?php echo $values['applicant_siblings']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Parents’ / Legal Guardian’s $ annual income (combined)</span>
                            <p id="guardians_income">
                                <?php echo $values['guardians_income']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Annual $ financial support they are able to provide to you (if any):</span>
                            <p id="guardians_support">
                                <?php echo $values['guardians_support']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="pb-5">
                        </div>
                    </div>
                </div>




                <div class="mb-4 d-flex align-items-center">
                    <span class="caption">School Information</span>
                </div>
                <div class="row">
                    <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">High School Name</span>
                            <p id="hs_name">
                                <?php echo $values['hs_name']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">City</span>
                            <p id="hs_city">
                                <?php echo $values['hs_city']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">State</span>
                            <p id="hs_state">
                                <?php echo $values['hs_state']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-9 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">GPA</span>
                            <p id="hs_gpa">
                                <?php echo $values['hs_gpa']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Attached Transcript</span>
                            <p id="hs_transcript">
                                <?php echo $values['hs_transcript']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-4 col-4">

                        <div class="review-field mb-3">
                            <span class="field-caption">Sat Scores</span>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-4">

                        <div class="review-field mb-3">
                            <span class="field-caption">Verbal</span>
                            <p id="sat_verbal">
                                <?php echo $values['sat_verbal']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-4 col-4">

                        <div class="review-field mb-3">
                            <span class="field-caption">Math</span>
                            <p id="sat_math">
                                <?php echo $values['sat_math']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</span>
                            <p id="hs_extras">
                                <?php echo $values['hs_extras']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Graduation date</span>
                            <p id="grad_date">
                                <?php echo $values['grad_date']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Employment (part-time and/or summers, last 3 years)</span>
                            <p id="hs_employment">
                                <?php echo $values['hs_employment']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">TARGET COLLEGE / UNIVERSITY Name</span>
                            <p id="target_postsec_name">
                                <?php echo $values['target_postsec_name']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">City</span>
                            <p id="target_postsec_city">
                                <?php echo $values['target_postsec_city']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">State</span>
                            <p id="target_postsec_state">
                                <?php echo $values['target_postsec_state']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Likely Major</span>
                            <p id="target_major">
                                <?php echo $values['target_major']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Financial assistance will be provided by the institution</span>
                            <p id="tuition_assistance">
                                <?php echo $values['tuition_assistance']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">How much are you and your family able to contribute?</span>
                            <p id="tuition_contributing">
                                <?php echo $values['tuition_contributing']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">How much is the gap?</span>
                            <p id="tuition_gap">
                                <?php echo $values['tuition_gap']; ?>
                            </p>
                        </div>
                    </div>

                </div>

                <div class="mb-4 d-flex align-items-center">
                    <span class="caption">Essay Questions</span>
                </div>
                <div class="row">

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Why should KMF award you this scholarship? What is unique and/or special about your achievements and/or circumstances?</span>
                            <p id="longform1">
                                <?php echo $values['longform1']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">What two accomplishments are you most proud of?</span>
                            <p id="longform2">
                                <?php echo $values['longform2']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">Provide two example of significant mistakes you have made and what you learned from each one.</span>
                            <p id="longform3">
                                <?php echo $values['longform3']; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="review-field mb-3">
                            <span class="field-caption">On a scale of 1-100 with 100 being the highest, how would you rate your level of determination to succeed? Provide one or two examples of situations in which you showed resilience after failing at something.</span>
                            <p id="longform4">
                                <?php echo $values['longform4']; ?>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="mb-4 d-flex align-items-center">
                            <span class="caption">Transcripts</span>
                        </div>
                    </div>

                    <div class="pb-5">
                    </div>

                    <?php
                if (!empty($values["hs_transcript"])) {                
                    $pdf_encoded = $values["hs_transcript"];
                    $data = explode(';',"data:application/pdf;base64,".$pdf_encoded.""); 
                    $encoded = explode(',',$data[1]);
                    file_put_contents("test.pdf",base64_decode($encoded[1]));
            ?>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            <object align="left" data="data:application/pdf;base64,<?php echo $pdf_encoded ?>" type="application/pdf" style="height:600px;width:100%"></object>
                        </div>
                        <?php
                } //close if-statement for existing transcript
            ?>

                            <?php
                if (!empty($values["postsec_transcript"])) {                
                    $pdf_encoded = $values["postsec_transcript"];
                    $data = explode(';',"data:application/pdf;base64,".$pdf_encoded.""); 
                    $encoded = explode(',',$data[1]);
                    file_put_contents("test.pdf",base64_decode($encoded[1]));
            ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <object align="left" data="data:application/pdf;base64,<?php echo $pdf_encoded ?>" type="application/pdf" style="height:600px;width:100%"></object>
                                </div>
                                <?php
                } //close if-statement for existing transcript
            ?>

                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="mb-4 pb-4"></div>
                                        <div class="form-group">
                                            <a class="btn btn-primary btn-step-4" href="list-view.php">Back to List View</a>
                                        </div>
                                    </div>
                </div>
            </div>
        </form>
    </div>
