<?php

$config = parse_ini_file('../kmf_admin_connect/config.ini'); 

//$mysqli = new mysqli($config['servername'],$config['username'],$config['password'],$config['dbname']);
$mysqli = new mysqli('localhost','root','','kmfdb');

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>