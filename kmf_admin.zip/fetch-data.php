<?php
include_once 'dbConnect.php';

$sql = 'SELECT * FROM applicants';
$res = $mysqli->query($sql);

$values = $res->fetch_all(MYSQLI_ASSOC);
$columns = array();

if(!empty($values)){
    $columns = array_keys($values[0]);
}

print_r("<pre>");
print_r($values);
print_r("</pre>");

?>