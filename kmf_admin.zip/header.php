<head>

    <title>Kohlberg-Manacher Foundation Application Administration</title>
    <!-- Dependencies -->
    <script type="text/javascript" src="libraries/jquery/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="libraries/bootstrap/bootstrap-4.4.1-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="libraries/list.min.js"></script>  

    <!-- My scripts and styles -->
    <script></script>    
    <link rel="stylesheet" href="css/style.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">

</head>
<header>
        <a class="margin-lg navbar-brand d-lg-inline-block" id="logo-lg" href="index.php">
            The Kohlberg-Manacher Foundation Admin Module
        </a>

</header>