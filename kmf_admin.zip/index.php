<?php
include_once 'dbConnect.php';
include_once 'header.php';

//Which fields to display in list view:
$display_fields = [
		"id"=>"ID",
		"applicant_name"=>"Applicant Name",
		"applicant_address"=>"Applicant Address",
		"applicant_location"=>"City, State",
		"applicant_email"=>"Email",
		"applicant_phone"=>"Phone",
		"hs_gpa"=>"GPA",
		"tuition_gap"=>"Tuition Gap",
		"application_status"=>"Status",
];
?>
<table class="table">


<?php
$select = implode(",", array_keys($display_fields));
$sql = 'SELECT '. $select .' FROM applicants ORDER BY id';
$res = $mysqli->query($sql);

$values = $res->fetch_all(MYSQLI_ASSOC);
$columns = array();

if(!empty($values)){
    $columns = array_keys($values[0]);
}

foreach ($values as $index => $row) {
	//Headers for the table
	if ($index==0) {
		echo "<thead class=\"thead-dark\">";
		echo "<tr scope=\"row\">";
		foreach ($row as $field_name => $value) {
			echo "<th scope=\"col\">";
			echo $display_fields[$field_name];
			echo "</th>";
		}
		echo "<th scope=\"col\">Detail</th>";
		// echo "<th scope=\"col\">Delete</th>";
		echo "</tr>";
		echo "</thead>";
		echo "<tbody>";
	}

	echo "<tr scope=\"row\">";

	foreach ($row as $field_name => $value) {
			echo "<td>";
			echo $value;
			echo "</td>";
	}

	echo "<form role='form' name='' action='form-view.php' method='post'>";
	echo "<input type='hidden' name='id' value='".$row["id"]."'/>";
	echo "<td>";
	echo "<button type='submit' name='detail'>";
	echo file_get_contents("./assets/detail.svg");
	echo "</button>";
	echo "</td>";
	// echo "<td>";
	// echo "<button type='submit' name='delete'>";
	// echo file_get_contents("./assets/delete.svg");
	// echo "</button>";
	// echo "</td>";
	echo "</tr>";
	echo "</form>";
}

// $pdf_encoded=$values[0]["hs_transcript"];
// $data = explode(';',"data:application/pdf;base64,".$pdf_encoded.""); 
// $encoded = explode(',',$data[1]);
// file_put_contents("test.pdf",base64_decode($encoded[1]));
?>

<!-- <a href="server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a> -->
<!-- <object data="data:application/pdf;base64,<?php echo $pdf_encoded ?>" type="application/pdf" style="height:200px;width:60%"></object> -->

</tbody>
</table>