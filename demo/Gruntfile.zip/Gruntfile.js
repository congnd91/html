module.exports = function (grunt) {
    // grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-notify');
    grunt.loadNpmTasks('grunt-sass');
    grunt.loadNpmTasks('grunt-browser-sync');
    grunt.loadNpmTasks('grunt-copy');
    grunt.loadNpmTasks('grunt-autoprefixer');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    var target = grunt.option('target');
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        sass: {
            options: {
                sourceMap: true,
                style: 'compressed'
            },
            all: {
                src: target + '/css/main.scss',
                dest: target + '/css/main.css',
            },
            toan: {
                src: 'html/wp/iwpserver/htdocs/wordpress/wp-content/themes/greeky/css/main.scss',
                dest: 'html/wp/iwpserver/htdocs/wordpress/wp-content/themes/greeky/css/main.css',
            },

            db2019: {
                src: 'html/db2019/css/scss/main.scss',
                dest: 'html/db2019/css/main.css',
            },
            amos: {
                src: 'html/amos/sass/style.scss',
                dest: 'html/amos/css/style.css',
            },

            admin: {
                src: 'html/demo/scss/main.scss',
                dest: 'html/demo/css/main.css',
            },
            basetom: {
                src: 'html/basetom/basetom.scss',
                dest: 'html/basetom/css/basetom.css',
            }
        },
        autoprefixer: {
            files: {
                src: 'D:/Workspace/html/example/html/db/css/main.css',
                dest: 'D:/Workspace/html/example/html/db/css/main.css',
            },
        },

        cssmin: {
            target: {
                files: [{
                    expand: true,
                    cwd: target + '/css',
                    src: ['*.css', '!*.min.css'],
                    dest: target + '/css',
                    ext: '.min.css'
            }]
            }

        },

        notify: {
            watch_concat: {
                options: {
                    title: 'Task Complete', // optional 
                    message: 'SASS and Uglify finished running', //required 
                }
            }
        },
        browserSync: {
            all: {
                bsFiles: {
                    src: [target + '/css/*.scss', target + '/css/scss/*.scss', target + '/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./" + target
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            },
            toan: {
                bsFiles: {
                    src: ['html/wp/iwpserver/htdocs/wordpress/wp-content/themes/greeky/css/*.scss', 'html/doctor/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./html/doctor"
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            },

            db2019: {
                bsFiles: {
                    src: ['html/db2019/css/scss/*.scss', 'html/db2019/css/scss/shared/*.scss', 'html/db2019/css/scss/pages/*.scss', 'html/db2019/css/scss/components/*.scss', 'html/db2019/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./html/db2019"
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            },

            amos: {
                bsFiles: {
                    src: ['html/amos/sass/*.scss', 'html/db2019/css/scss/shared/*.scss', 'html/db2019/css/scss/pages/*.scss', 'html/db2019/css/scss/components/*.scss', 'html/db2019/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./html/db2019"
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            },

            admin: {


                bsFiles: {
                    src: ['html/demo/scss/*.scss', 'html/demo/scss/*/*.scss', 'html/demo/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./html/demo"
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            },
            basetom: {
                bsFiles: {
                    src: ['html/basetom/*.scss', 'html/basetom/*.html'],
                },
                options: {
                    server: {
                        baseDir: "./html/basetom"
                        // baseDir: "./"
                    },
                    watchTask: true,
                    reloadDelay: 3000
                },
            }
        },
        watch: {
            all: {
                files: [target + '/css/*.scss', target + '/css/scss/*.scss', target + '/*.html'],
                tasks: ['sass:all', 'cssmin'],
            },
            toan: {
                files: ['html/wp/iwpserver/htdocs/wordpress/wp-content/themes/greeky/css/*.scss', 'html/doctor/*.html'],
                tasks: ['sass:toan'],
            },

            db2019: {
                files: ['html/db2019/css/scss/*.scss', 'html/db2019/css/scss/shared/*.scss', 'html/db2019/css/scss/pages/*.scss', 'html/db2019/css/scss/components/*.scss', 'html/db2019/*.html'],
                tasks: ['sass:db2019'],
            },

            amos: {
                files: ['html/amos/sass/*.scss', 'html/db2019/css/scss/shared/*.scss', 'html/db2019/css/scss/pages/*.scss', 'html/db2019/css/scss/components/*.scss', 'html/db2019/*.html'],
                tasks: ['sass:amos'],
            },
            admin: {



                files: [' html/demo/scss/*.scss', ' html/demo/scss/*/*.scss', ' html/demo/*.html'],
                tasks: ['sass:admin'],
            },
            basetom: {
                files: ['html/basetom/*.scss', 'html/basetom/*.html', 'html/basetom/scss/grid/*.scss', ],
                tasks: ['sass:basetom'],
            }
        },
        copy: {
            files: {
                'dest/default_options': ['D:/test.txt', 'D:/demo/test.txt'],
            },
        },
    });
    grunt.registerTask('default', ['browserSync', 'watch']);
    grunt.registerTask('copy1', 'copy');
    grunt.registerTask('css', 'Grunt css', function () {
        grunt.task.run(['browserSync:all', 'watch:all']);
    });
    grunt.registerTask('toan', ['browserSync:toan', 'watch:toan']);
    grunt.registerTask('db2019', ['browserSync:db2019', 'watch:db2019']);

    grunt.registerTask('amos', ['browserSync:amos', 'watch:amos']);
    grunt.registerTask('admin', ['browserSync:admin', 'watch:admin']);
    grunt.registerTask('basetom', ['browserSync:basetom', 'watch:basetom']);
    grunt.registerTask('prefix', 'autoprefixer');
    grunt.registerTask('min', 'cssmin');
};
