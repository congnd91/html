
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>ขอบคุณ</title>
    <style>
        html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, summary, time, mark, audio, video { margin: 0px; padding: 0px; border: 0px none; font-family: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; font-size-adjust: inherit; font-stretch: inherit; -moz-font-feature-settings: inherit; -moz-font-language-override: inherit; font-size: 100%; vertical-align: baseline; }
body { line-height: 1; font-family: Arial; font-size: 15px; color: rgb(49, 62, 71); width: 100%; height: 100%; background: url('point-bgr.png') repeat scroll 0% 0% transparent; }
html { height: 100%; }
ol, ul { list-style: none outside none; }
h2 { font-size: 36px; line-height: 44px; color: rgb(49, 62, 71); text-align: center; text-transform: uppercase; font-weight: bold; }
h3 { font-size: 18px; font-weight: bold; text-align: center; margin: 20px 0px; }
a { color: rgb(105, 185, 255); }
a:hover { color: rgb(225, 71, 64); }
.wrap_block_success {  }
.url_more_info { text-align: center; font-size: 20px; display: block; margin: 20px 0px; }
.url_more_info:hover { color: rgb(225, 71, 64); }
.block_success { max-width: 960px; padding: 70px 30px; margin: 0px auto; }
.success { text-align: center; }
.list_info { text-align: left; display: inline-block; }
.list_info li { margin: 11px 0px; }
.list_info li span { width: 150px; display: inline-block; font-weight: bold; font-style: normal; }
.fail { margin: 25px 0px 40px; text-align: center; }
.wrap_list_info { text-align: center; }
.email { position: relative; text-align: center; margin-top: 40px; }
.error { position: absolute; display: none; top: -28px; color: rgb(202, 63, 63); }
.mail_block { display: inline-block; }
.email input { height: 30px; width: 200px; font-size: 14px; padding-right: 10px; padding-left: 10px; outline: medium none; border-radius: 5px; border: 1px solid rgb(182, 182, 182); margin-bottom: 10px; }
.button { display: inline-block; outline: medium none; cursor: pointer; text-align: center; text-decoration: none; font: 15px/100% Arial,Helvetica,sans-serif; padding: 0.55em 2em 0.6em; text-shadow: 0px 1px 1px rgba(0, 0, 0, 0.3); border-radius: 0.5em; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); color: rgb(217, 238, 247); border: 1px solid rgb(0, 118, 163); background: -moz-linear-gradient(center top , rgb(0, 173, 238), rgb(0, 120, 165)) repeat scroll 0% 0% transparent; }
.button:hover { text-decoration: none; color: rgb(217, 238, 247); background: -moz-linear-gradient(center top , rgb(0, 149, 204), rgb(0, 103, 142)) repeat scroll 0% 0% transparent; }
.button:active { position: relative; top: 1px; color: rgb(128, 190, 214); background: -moz-linear-gradient(center top , rgb(0, 120, 165), rgb(0, 173, 238)) repeat scroll 0% 0% transparent; }
    </style>
	<img height=1 width=1 border=0 src="//www.googleadservices.com/pagead/conversion/854357427/?label=DufZCITyjZkBELPrsZcD&amp;value=10.0&amp;currency_code=USD&amp;guid=ON&amp;script=0">
</head>
<body>
    <div class="wrap_block_success">
        <div class="block_success">
            
            
                <h1>ขอบคุณ</h1>
                <br>
                <p class="success">ได้รับการสั่งซื้อเรียบร้อยแล้ว ขณะนี้อยู่ระหว่างดำเนินการ></p>
                <p class="success">เร็วๆ นี้จะมีเจ้าหน้าที่ติดต่อกลับไปหาคุณเพื่อยืนยันข้อมูลและรายละเอียด</p>

                        
                <p class="fail">&nbsp;</p>
                <hr>
                <br>
                <div class="clear"></div>       </div>
    </div>
    </body>

</html>