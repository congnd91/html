<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input type="search-text" value="" placeholder="<?php esc_html_e( 'Search...', 'mazpage' ); ?>" name="s" class="txt-search" />

    <button class="search-icon">
                                 <i class="icon ion-ios-search"></i>
                            </button>
</form>
