<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package mazpage
 */

?>

    <!--footer-->
    <footer class="footer">

        <div class="footer-bg">
        </div>
        <div class="container">

            <div class="box-contact">
                <h2>Liên hệ tư vấn, đặt hàng</h2>

                <p> 096 275 1191 - 096 993 1091</p>

            </div>
        </div>
    </footer>
    </div>
    <?php wp_footer(); ?>
    </body>

    </html>
