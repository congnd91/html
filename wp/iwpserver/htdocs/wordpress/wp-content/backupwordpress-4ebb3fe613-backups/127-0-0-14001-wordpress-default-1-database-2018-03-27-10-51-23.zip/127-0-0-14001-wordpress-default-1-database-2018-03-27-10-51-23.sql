# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (65 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2012-10-02 22:12:12', '2012-10-02 22:12:12', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 5, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:16:35', '2008-09-17 22:16:35', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (3, 32, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:14:05', '2008-09-17 22:14:05', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (4, 32, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:16:01', '2008-09-17 22:16:01', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (5, 35, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:14:02', '2008-09-17 22:14:02', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (6, 37, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:17:42', '2008-09-17 22:17:42', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (7, 37, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:18:11', '2008-09-17 22:18:11', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text. Alternating content so I don\'t get caught spamming ;)', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (8, 39, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:58', '2008-09-17 22:13:58', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (9, 43, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:19:27', '2008-09-17 22:19:27', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (10, 45, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:55', '2008-09-17 22:13:55', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (11, 45, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:19:42', '2008-09-17 22:19:42', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (12, 53, 'Mr WordPress', '', 'http://wordpress.org/', '', '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (13, 53, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:50', '2008-09-17 22:13:50', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (14, 57, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:35', '2008-09-17 22:13:35', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (15, 57, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:20:13', '2008-09-17 22:20:13', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (16, 155, 'Anon', 'anon@example.com', '', '59.167.157.3', '2007-09-04 10:49:28', '2007-09-04 00:49:28', 'Anonymous comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (17, 155, 'tellyworthtest2', 'tellyworth+test2@gmail.com', '', '59.167.157.3', '2007-09-04 10:49:03', '2007-09-04 00:49:03', 'Contributor comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (18, 155, 'John Doe', 'example@example.org', 'http://example.org', '59.167.157.3', '2007-09-04 10:48:51', '2007-09-04 17:48:51', 'Author comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (19, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '59.167.157.3', '2012-09-03 10:18:04', '2012-09-03 17:18:04', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<tbody>
<tr>
<th>Employee</th>
<th class="views">Salary</th>
<th></th>
</tr>
<tr class="odd">
<td><a href="http://example.org/" rel="nofollow">John Saddington</a></td>
<td>$1</td>
<td>Because that\'s all Steve Job\' needed for a salary.</td>
</tr>
<tr class="even">
<td><a href="http://example.org/" rel="nofollow">Tom McFarlin</a></td>
<td>$100K</td>
<td>For all the blogging he does.</td>
</tr>
<tr class="odd">
<td><a href="http://example.org/" rel="nofollow">Jared Erickson</a></td>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Tom x 1,000.</td>
</tr>
<tr class="even">
<td><a href="http://example.org/" rel="nofollow">Chris Ames</a></td>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c" rel="nofollow">explain</a> this one.</dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/" rel="nofollow">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com" rel="nofollow">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag</strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
  margin: 0 0 5px;
  font-weight: bold;
  font-size: 38px;
  line-height: 1.2;
}</pre>

<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag</strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (20, 1148, 'Anonymous User', 'fake@email.com', '', '67.3.69.40', '2013-03-11 23:45:54', '2013-03-12 04:45:54', 'This user it trying to be anonymous.


    They used a fake email, so there should be no <a href="http://gravatar.com/" title="Gravatar" rel="nofollow">Gravatar</a> associated with it.
    They did not speify a website, so there should be no link to it in the comment.
', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (21, 1148, 'Jane Doe', 'example@example.org', 'http://example.org/', '204.54.106.1', '2013-03-12 13:17:35', '2013-03-12 20:17:35', 'Comments? I love comments!', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (22, 1148, 'John Doe', 'example@example.org', 'http://example.org', '24.126.245.62', '2013-03-14 07:53:26', '2013-03-14 14:53:26', 'These tests are amazing!', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (23, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 07:56:46', '2013-03-14 14:56:46', 'Author Comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (24, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 07:57:01', '2013-03-14 14:57:01', 'Comment Depth 01', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (25, 1148, 'Jane Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:01:21', '2013-03-14 15:01:21', 'Comment Depth 02', 0, '1', '', '', 24, 0) ; 
INSERT INTO `wp_comments` VALUES (26, 1148, 'Fred Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:02:06', '2013-03-14 15:02:06', 'Comment Depth 03', 0, '1', '', '', 25, 0) ; 
INSERT INTO `wp_comments` VALUES (27, 1148, 'Fred Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:03:22', '2013-03-14 15:03:22', 'Comment Depth 04', 0, '1', '', '', 26, 0) ; 
INSERT INTO `wp_comments` VALUES (28, 1148, 'Joe Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:10:29', '2013-03-14 15:10:29', 'Comment Depth 05

Also an author comment.', 0, '1', '', '', 27, 0) ; 
INSERT INTO `wp_comments` VALUES (29, 1148, 'Jane Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:12:16', '2013-03-14 15:12:16', 'Comment Depth 06', 0, '1', '', '', 28, 0) ; 
INSERT INTO `wp_comments` VALUES (30, 1148, 'Joe Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:12:58', '2013-03-14 15:12:58', 'Comment Depth 07', 0, '1', '', '', 29, 0) ; 
INSERT INTO `wp_comments` VALUES (31, 1148, 'Jane Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:13:42', '2013-03-14 15:13:42', 'Comment Depth 08', 0, '1', '', '', 30, 0) ; 
INSERT INTO `wp_comments` VALUES (32, 1148, 'Joe Bloggs', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:14:13', '2013-03-14 15:14:13', 'Comment Depth 09', 0, '1', '', '', 31, 0) ; 
INSERT INTO `wp_comments` VALUES (33, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 08:14:47', '2013-03-14 15:14:47', 'Comment Depth 10

Also an author comment.', 0, '1', '', '', 32, 0) ; 
INSERT INTO `wp_comments` VALUES (34, 1148, 'Jane Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 09:56:43', '2013-03-14 09:56:43', 'Image comment.

', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (35, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 11:23:24', '2013-03-14 18:23:24', 'We are totally going to blog about these tests!', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (36, 1148, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 11:27:54', '2013-03-14 18:27:54', 'We use these tests all the time! Killer stuff!', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (37, 1148, 'Jane Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 11:30:33', '2013-03-14 18:30:33', 'Thanks for all the comments, everyone!', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (38, 1149, 'Ping 1 &laquo; What&#8217;s a tellyworth?', '', 'http://tellyworth.wordpress.com/2007/11/21/ping-1/', '72.232.101.12', '2007-11-21 11:31:12', '2007-11-21 01:31:12', '[...] Trackback test. [...]', 0, '1', '', 'pingback', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (39, 1149, 'Ping 2 with a much longer title than the previous ping, which was called Ping 1 &laquo; What&#8217;s a tellyworth?', '', 'http://tellyworth.wordpress.com/2007/11/21/ping-2-with-a-much-longer-title-than-the-previous-ping-which-was-called-ping-1/', '72.232.101.12', '2007-11-21 11:35:47', '2007-11-21 01:35:47', '[...] Another trackback test.  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec hendrerit gravida nisi. Praesent libero odio, tincidunt nec, fringilla et, mollis ut, ipsum. Proin a lacus quis nisi pulvinar bibendum. Donec massa justo, dapibus at, imperdiet vestibulum, dapibus in, leo. Donec pretium tellus in dui. Phasellus tristique aliquet justo. Donec sodales. Nulla urna mi, molestie ac, malesuada sit amet, sagittis id, lacus. Mauris auctor leo ac justo. Proin convallis. Nulla eleifend dictum mi. Donec at lectus. Integer augue sapien, ornare vitae, rhoncus quis, rhoncus sed, sapien. Nunc mattis diam sodales diam.Etiam porttitor, ante sed varius semper, ante arcu rutrum tortor, at luctus nunc urna id nibh. Fusce sodales. Integer sed ligula. Donec posuere, nibh aliquet auctor congue, augue est porttitor odio, imperdiet facilisis tortor urna vel mauris. Pellentesque pretium, lorem non pellentesque varius, elit diam ultrices mi, sed posuere sapien lectus sed mi. Donec vestibulum urna. Donec gravida elit et enim. Ut dignissim neque ut erat. Morbi tincidunt nunc vitae lorem. Morbi rhoncus mi. Praesent facilisis tincidunt enim. Ut pulvinar. Suspendisse potenti. Vivamus turpis odio, porta at, malesuada in, iaculis eget, odio. Aenean faucibus, urna quis congue dignissim, orci tellus ornare leo, eget viverra ante ipsum sit amet magna. Suspendisse mattis nunc at justo. Nullam malesuada lobortis lorem. Morbi ultricies. Nam risus erat, sagittis ut, tristique rhoncus, luctus id, ante. Maecenas ac dui. [...]', 0, '1', '', 'pingback', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (40, 1149, 'Ping 4 &laquo; What&#8217;s a tellyworth?', '', 'http://tellyworth.wordpress.com/2007/11/21/ping-4/', '72.232.101.12', '2007-11-21 11:39:25', '2007-11-21 01:39:25', '[...] Another short one. [...]', 0, '1', '', 'pingback', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (41, 1149, 'Ping 3 &laquo; What&#8217;s a tellyworth?', '', 'http://tellyworth.wordpress.com/2007/11/21/ping-3/', '72.232.101.12', '2007-11-21 11:38:22', '2007-11-21 01:38:22', '[...] Just a short one. [...]', 0, '1', '', 'pingback', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (42, 1149, 'John Doe', 'example@example.org', 'http://example.org/', '146.214.103.251', '2010-06-11 15:27:04', '2010-06-11 22:27:04', 'This is a comment amongst pingbacks and trackbacks.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (43, 1168, 'Jane Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 11:56:08', '2013-03-14 18:56:08', 'This comment should not be visible until the password is entered.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (44, 1170, 'John Doe', 'example@example.org', 'http://example.org/', '24.126.245.62', '2013-03-14 12:35:07', '2013-03-14 19:35:07', 'Having no content in the post should have no adverse effects on the layout or functionality.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (45, 13, 'hdhdkjh', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 11:49:29', '2014-04-28 11:49:29', 'adhlkadjlkajd', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (46, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:10:25', '2014-04-28 13:10:25', 'a comment', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (47, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:11:25', '2014-04-28 13:11:25', 'a reply', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 17, 0) ; 
INSERT INTO `wp_comments` VALUES (48, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:21:09', '2014-04-28 13:21:09', 'a new reply', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 47, 0) ; 
INSERT INTO `wp_comments` VALUES (49, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:21:32', '2014-04-28 13:21:32', 'one more', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 48, 0) ; 
INSERT INTO `wp_comments` VALUES (50, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:21:56', '2014-04-28 13:21:56', 'a new', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 47, 0) ; 
INSERT INTO `wp_comments` VALUES (51, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:22:21', '2014-04-28 13:22:21', 'fff', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 49, 0) ; 
INSERT INTO `wp_comments` VALUES (52, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:23:02', '2014-04-28 13:23:02', 'ddd', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (53, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:23:53', '2014-04-28 13:23:53', 'more than one', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (54, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:38:42', '2014-04-28 13:38:42', 'gtt', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (55, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:41:29', '2014-04-28 13:41:29', 'tralala', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (56, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:57:40', '2014-04-28 13:57:40', 'dddddfwf', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (57, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:58:58', '2014-04-28 13:58:58', 'hfkhfhf', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (58, 155, 'admin', 'maniuni@gmail.com', '', '127.0.0.1', '2014-04-28 13:59:13', '2014-04-28 13:59:13', 'laasst', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (59, 155, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-04-29 13:32:47', '2014-04-29 13:32:47', 'fff', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (60, 155, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-04-29 13:34:08', '2014-04-29 13:34:08', 'dshrh', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 18, 1) ; 
INSERT INTO `wp_comments` VALUES (61, 155, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-04-29 13:38:20', '2014-04-29 13:38:20', 'comment from author', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 49, 1) ; 
INSERT INTO `wp_comments` VALUES (62, 155, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-04-30 07:03:18', '2014-04-30 07:03:18', 'Lorem Ipsum е елементарен примерен текст, използван в печатарската и типографската индустрия. Lorem Ipsum е индустриален стандарт от около 1500 година, когато неизвестен печатар взема няколко печатарски букви и ги разбърква, за да напечата с тях книга с примерни шрифтове. Този начин не само е оцелял повече от 5 века, но е навлязъл и в публикуването на електронни издания като е запазен почти без промяна. Популяризиран е през 60те години на 20ти век със издаването на Letraset листи, съдържащи Lorem Ipsum пасажи, популярен е и в наши дни във софтуер за печатни издания като Aldus PageMaker, който включва различни версии на Lorem Ipsum.', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (63, 155, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-04-30 09:27:14', '2014-04-30 09:27:14', 'jkhfhkjf', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 60, 1) ; 
INSERT INTO `wp_comments` VALUES (64, 1148, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-05-08 11:29:18', '2014-05-08 11:29:18', 'http://bavotasan.com/2009/how-to-add-nested-comments-to-your-wordpress-theme/', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 37, 1) ; 
INSERT INTO `wp_comments` VALUES (65, 1148, 'admin', 'admin@localhost.local', '', '127.0.0.1', '2014-05-08 11:31:17', '2014-05-08 11:31:17', 'http://hogash-demo.com/files/kallyaswp_desc/d1_01.jpg', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/news/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/news/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/support/', 'Support Forums', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/support/forum/requests-and-feedback', 'Feedback', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) DEFAULT NULL,
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3132 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (369 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://127.0.0.1:4001/wordpress', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Purple Modena', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'A simple, light theme in shades of purple that supports Google Chrome, Safari 5.1, Opera, Firefox and Internet Explorer 8+.', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'admin@localhost.local', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (285, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:16:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:19:"akismet/akismet.php";i:2;s:23:"debug-bar/debug-bar.php";i:3;s:23:"developer/developer.php";i:4;s:9:"hello.php";i:5;s:19:"jetpack/jetpack.php";i:6;s:49:"log-deprecated-notices/log-deprecated-notices.php";i:7;s:33:"monster-widget/monster-widget.php";i:8;s:35:"simply-show-ids/simply-show-ids.php";i:9;s:27:"theme-check/theme-check.php";i:10;s:91:"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php";i:11;s:57:"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php";i:12;s:27:"woocommerce/woocommerce.php";i:13;s:41:"wordpress-importer/wordpress-importer.php";i:14;s:31:"wp-migrate-db/wp-migrate-db.php";i:15;s:43:"wp-native-dashboard/wp-native-dashboard.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://127.0.0.1:4001/wordpress', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '3', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', 'a:5:{i:0;s:127:"C:\\Users\\irivanova\\Dropbox\\InstantWP_4.3.1 (Purple Modena)\\iwpserver\\htdocs\\wordpress/wp-content/themes/purple-modena/style.css";i:2;s:91:"G:\\InstantWP_4.3.1\\iwpserver\\htdocs\\wordpress/wp-content/themes/purple-modena/functions.php";i:3;s:87:"G:\\InstantWP_4.3.1\\iwpserver\\htdocs\\wordpress/wp-content/themes/purple-modena/style.css";i:4;s:84:"G:\\InstantWP_4.3.1\\iwpserver\\htdocs\\wordpress/wp-content/plugins/akismet/akismet.php";i:5;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'smart4baby', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'smart4baby', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'db_version', '38590', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_h', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'avatar_default', 'gravatar_default', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_h', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'image_default_link_type', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments_depth', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'page_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'comments_per_page', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'sticky_posts', 'a:1:{i:0;i:1241;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_text', 'a:2:{i:2;a:3:{s:5:"title";s:15:"Contact details";s:4:"text";s:82:"1407, Sofia
29 Atanas Dukov Str. 
tel. 02/9321 708
email: irantonova@actavis.bg";s:6:"filter";b:1;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'uninstall_plugins', 'a:2:{s:49:"log-deprecated-notices/log-deprecated-notices.php";a:2:{i:0;s:14:"Deprecated_Log";i:1;s:12:"on_uninstall";}s:30:"lightbox-plus/lightboxplus.php";s:12:"UninstallLBP";}', 'no') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '703', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'initial_db_version', '21707', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, '_transient_random_seed', '3a0cb0d36f2fc8fde2c259cbfce6d913', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_search', 'a:3:{i:2;a:1:{s:5:"title";s:0:"";}i:4;a:1:{s:5:"title";s:6:"search";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_recent-posts', 'a:3:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:12:"Recent posts";s:6:"number";i:5;s:9:"show_date";b:1;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'widget_recent-comments', 'a:3:{i:1;a:0:{}i:2;a:2:{s:5:"title";s:15:"recent comments";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'widget_archives', 'a:3:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:8:"archives";s:5:"count";i:0;s:8:"dropdown";i:1;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'widget_meta', 'a:3:{i:4;a:1:{s:5:"title";s:8:"Мета";}i:5;a:1:{s:5:"title";s:4:"Meta";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, 'sidebars_widgets', 'a:6:{s:16:"mazpage_home_big";a:1:{i:0;s:7:"pages-2";}s:23:"mazpage_footer_column_1";a:1:{i:0;s:6:"meta-4";}s:19:"wp_inactive_widgets";a:19:{i:0;s:10:"calendar-2";i:1;s:10:"archives-2";i:2;s:7:"links-2";i:3;s:6:"meta-5";i:4;s:8:"search-2";i:5;s:8:"search-4";i:6;s:6:"text-2";i:7;s:14:"recent-posts-2";i:8;s:17:"recent-comments-2";i:9;s:11:"tag_cloud-2";i:10;s:10:"nav_menu-2";i:11;s:16:"akismet_widget-2";i:12;s:9:"monster-4";i:13;s:9:"monster-5";i:14;s:9:"monster-6";i:15;s:9:"monster-7";i:16;s:9:"monster-8";i:17;s:9:"monster-9";i:18;s:25:"woocommerce_layered_nav-2";}s:15:"mazpage_sidebar";a:1:{i:0;s:9:"monster-3";}s:12:"mazpage_home";a:3:{i:0;s:28:"mazpage_widget_slider_home-2";i:1;s:30:"mazpage_widget_category_home-2";i:2;s:30:"mazpage_widget_category_home-3";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2476, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1522045348', 'no') ; 
INSERT INTO `wp_options` VALUES (2477, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:"stdClass":100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";i:4441;}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";i:2671;}s:4:"post";a:3:{s:4:"name";s:4:"post";s:4:"slug";s:4:"post";s:5:"count";i:2546;}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";i:2410;}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";i:1861;}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";i:1641;}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";i:1636;}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";i:1449;}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";i:1384;}s:8:"facebook";a:3:{s:4:"name";s:8:"facebook";s:4:"slug";s:8:"facebook";s:5:"count";i:1381;}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";i:1380;}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";i:1305;}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";i:1280;}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";i:1188;}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";i:1090;}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";i:1056;}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";i:1015;}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";i:995;}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";i:872;}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";i:866;}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";i:823;}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";i:797;}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";i:794;}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";i:700;}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";i:690;}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";i:683;}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";i:674;}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";i:674;}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";i:656;}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";i:654;}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";i:639;}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";i:637;}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";i:632;}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";i:613;}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";i:610;}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";i:601;}s:4:"ajax";a:3:{s:4:"name";s:4:"ajax";s:4:"slug";s:4:"ajax";s:5:"count";i:600;}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";i:588;}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";i:586;}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";i:585;}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";i:557;}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";i:545;}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";i:535;}s:3:"css";a:3:{s:4:"name";s:3:"css";s:4:"slug";s:3:"css";s:5:"count";i:531;}s:5:"share";a:3:{s:4:"name";s:5:"share";s:4:"slug";s:5:"share";s:5:"count";i:521;}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";i:516;}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";i:511;}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";i:504;}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";i:491;}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";i:487;}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";i:486;}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";i:483;}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";i:479;}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";i:471;}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";i:466;}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";i:463;}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";i:457;}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";i:451;}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";i:436;}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";i:428;}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";i:423;}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";i:420;}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";i:418;}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";i:416;}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";i:412;}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";i:411;}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";i:402;}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";i:399;}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";i:390;}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";i:385;}s:7:"payment";a:3:{s:4:"name";s:7:"payment";s:4:"slug";s:7:"payment";s:5:"count";i:381;}s:4:"news";a:3:{s:4:"name";s:4:"news";s:4:"slug";s:4:"news";s:5:"count";i:362;}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";i:356;}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";i:353;}s:5:"popup";a:3:{s:4:"name";s:5:"popup";s:4:"slug";s:5:"popup";s:5:"count";i:350;}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";i:343;}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";i:343;}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";i:340;}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";i:338;}s:4:"chat";a:3:{s:4:"name";s:4:"chat";s:4:"slug";s:4:"chat";s:5:"count";i:336;}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";i:335;}s:4:"code";a:3:{s:4:"name";s:4:"code";s:4:"slug";s:4:"code";s:5:"count";i:334;}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";i:333;}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";i:329;}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";i:328;}s:15:"payment-gateway";a:3:{s:4:"name";s:15:"payment gateway";s:4:"slug";s:15:"payment-gateway";s:5:"count";i:328;}s:8:"redirect";a:3:{s:4:"name";s:8:"redirect";s:4:"slug";s:8:"redirect";s:5:"count";i:319;}s:5:"forms";a:3:{s:4:"name";s:5:"forms";s:4:"slug";s:5:"forms";s:5:"count";i:310;}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";i:305;}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";i:302;}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";i:302;}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";i:300;}s:7:"adsense";a:3:{s:4:"name";s:7:"adsense";s:4:"slug";s:7:"adsense";s:5:"count";i:295;}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";i:293;}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";i:292;}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";i:291;}s:6:"author";a:3:{s:4:"name";s:6:"author";s:4:"slug";s:6:"author";s:5:"count";i:289;}s:16:"google-analytics";a:3:{s:4:"name";s:16:"google analytics";s:4:"slug";s:16:"google-analytics";s:5:"count";i:288;}s:11:"performance";a:3:{s:4:"name";s:11:"performance";s:4:"slug";s:11:"performance";s:5:"count";i:286;}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";i:285;}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2473, '_split_terms', 'a:6:{i:2;a:1:{s:13:"link_category";i:216;}i:10;a:1:{s:3:"tag";i:217;}i:11;a:1:{s:3:"tag";i:218;}i:12;a:1:{s:3:"tag";i:219;}i:54;a:1:{s:8:"post_tag";i:220;}i:204;a:1:{s:3:"tag";i:221;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2472, 'category_children', 'a:9:{i:3;a:2:{i:0;i:6;i:1;i:7;}i:5;a:1:{i:0;i:8;}i:7;a:1:{i:0;i:9;}i:19;a:1:{i:0;i:62;}i:51;a:1:{i:0;i:73;}i:73;a:1:{i:0;i:74;}i:52;a:5:{i:0;i:75;i:1;i:76;i:2;i:77;i:3;i:78;i:4;i:79;}i:40;a:1:{i:0;i:80;}i:77;a:1:{i:0;i:81;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'logged_in_key', 'w_JTTa+Qx9`MM3vr~VL*(^M7tk/nEIB#&FLnz1{V9Ckm3/q._m2j(&4&-;N^>Mp)', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'logged_in_salt', '?7DQKJ>AgDCyL;{94WSdxkyf--2k>!Mr?d>}5g$`U.y8D/d0O6X+`~!MZu|76iu=', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'auth_key', 'Gwuy8P`2*_,Mtz,hxIplx+7A_<?vH2 =wP$X kw*#L8_3;MlfD`mt#Y0(6t2cTe+', 'yes') ; 
INSERT INTO `wp_options` VALUES (109, 'auth_salt', 'y.3t+|LzEImjjy*^:]{R$6ei9#S97{L;U+Q2OWrGs=I{v}#bK6:pyQ~ NJayBK-3', 'yes') ; 
INSERT INTO `wp_options` VALUES (110, 'cron', 'a:14:{i:1522098000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1522100669;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1522102339;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1522119882;a:1:{s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1522121449;a:1:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1522139221;a:1:{s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1522140642;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1522145534;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1522164649;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1522180800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1522540800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1522713600;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:7:"monthly";s:4:"args";a:0:{}s:8:"interval";i:2635200;}}}i:1577880018;a:1:{s:19:"publish_future_post";a:1:{s:32:"53e45760b4285163a94322f2b432f7d3";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:1153;}}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (284, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (155, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3125, '_site_transient_timeout_theme_roots', '1522138852', 'no') ; 
INSERT INTO `wp_options` VALUES (3126, '_site_transient_theme_roots', 'a:7:{s:7:"mazpage";s:7:"/themes";s:10:"smart4baby";s:7:"/themes";s:10:"storefront";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";s:9:"twentyten";s:7:"/themes";}', 'no') ; 
INSERT INTO `wp_options` VALUES (119, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:31:"http://127.0.0.1:4001/wordpress";s:4:"link";s:107:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://127.0.0.1:4001/wordpress/";s:3:"url";s:140:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://127.0.0.1:4001/wordpress/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (120, 'nonce_key', 'n@QkHTPhTgVEgs3$* k|pgY!jK2bwY$R`cT:Dt/w>E9mm{U3 bUzl.Tdkc$NL0qA', 'yes') ; 
INSERT INTO `wp_options` VALUES (121, 'nonce_salt', '0Ib UM_{BY61@ 42V?~|le@N{8>*<d#Sn<uiQ%*0ys4)H IT&t;>Vnry$nyLgk%E', 'yes') ; 
INSERT INTO `wp_options` VALUES (2438, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2439, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2440, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2441, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2442, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1621, 'widget_akismet_widget', 'a:3:{i:1;a:0:{}i:2;a:1:{s:5:"title";s:12:"Spam Blocked";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2428, 'theme_mods_mazpage', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522033499;s:4:"data";a:10:{s:19:"wp_inactive_widgets";a:18:{i:0;s:10:"calendar-2";i:1;s:8:"search-2";i:2;s:6:"text-2";i:3;s:10:"archives-2";i:4;s:8:"search-4";i:5;s:14:"recent-posts-2";i:6;s:17:"recent-comments-2";i:7;s:11:"tag_cloud-2";i:8;s:10:"nav_menu-2";i:9;s:16:"akismet_widget-2";i:10;s:9:"monster-9";i:11;s:7:"links-2";i:12;s:6:"meta-5";i:13;s:9:"monster-4";i:14;s:9:"monster-5";i:15;s:9:"monster-6";i:16;s:9:"monster-7";i:17;s:9:"monster-8";}s:15:"mazpage_sidebar";a:1:{i:0;s:9:"monster-3";}s:12:"mazpage_home";a:0:{}s:21:"mazpage_social_footer";a:0:{}s:16:"mazpage_home_big";a:1:{i:0;s:7:"pages-2";}s:23:"mazpage_footer_column_1";a:1:{i:0;s:6:"meta-4";}s:23:"mazpage_footer_column_2";a:0:{}s:23:"mazpage_footer_column_3";N;s:13:"mazpage_about";N;s:15:"mazpage_contact";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2425, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1522076332', 'no') ; 
INSERT INTO `wp_options` VALUES (2426, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1522076332', 'no') ; 
INSERT INTO `wp_options` VALUES (2427, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1522033132', 'no') ; 
INSERT INTO `wp_options` VALUES (346, 'a8c_developer', 'a:1:{s:12:"project_type";s:11:"wporg-theme";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (379, 'log_deprecated_notices', 'a:2:{s:11:"last_viewed";s:19:"2014-07-11 11:38:44";s:10:"db_version";i:4;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2175, 'theme_mods_modelun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1407147728;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:15:{i:0;s:10:"archives-2";i:1;s:8:"search-4";i:2;s:14:"recent-posts-2";i:3;s:17:"recent-comments-2";i:4;s:11:"tag_cloud-2";i:5;s:10:"nav_menu-2";i:6;s:16:"akismet_widget-2";i:7;s:9:"monster-9";i:8;s:7:"links-2";i:9;s:6:"meta-5";i:10;s:9:"monster-4";i:11;s:9:"monster-5";i:12;s:9:"monster-6";i:13;s:9:"monster-7";i:14;s:9:"monster-8";}s:4:"blog";a:1:{i:0;s:9:"monster-3";}s:9:"portfolio";a:3:{i:0;s:6:"text-2";i:1;s:8:"search-2";i:2;s:10:"calendar-2";}s:4:"page";a:0:{}s:14:"footer-sidebar";a:0:{}s:18:"orphaned_widgets_1";a:1:{i:0;s:7:"pages-2";}s:18:"orphaned_widgets_2";a:1:{i:0;s:6:"meta-4";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2177, 'simplecorp', 'a:66:{s:8:"sc_clogo";s:81:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/logo.png";s:13:"sc_clogo_text";s:10:"SimpleCorp";s:14:"sc_colorscheme";s:0:"";s:26:"sc_custom_shortcut_favicon";s:0:"";s:17:"sc_showpageheader";s:1:"1";s:16:"sc_pageheaderurl";s:87:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/pageheader.jpg";s:19:"sc_customtypography";s:1:"1";s:18:"sc_headingfontlink";s:103:"&lt;link href=\\\'http://fonts.googleapis.com/css?family=Dosis\\\' rel=\\\'stylesheet\\\' type=\\\'text/css\\\'&gt;";s:18:"sc_headingfontface";s:34:"font-family: \\\'Dosis\\\', sans-serif";s:12:"sc_blurbhome";s:1:"1";s:8:"sc_blurb";s:170:"Welcome to Our Small Agency. We specialize in <strong>Web Design</strong> and <strong>Development</strong>. Check out our outstanding portfolio, and get in touch with Us!";s:14:"sc_homecontent";s:1:"1";s:20:"sc_homecontent1title";s:16:"Awesome Features";s:15:"sc_homecontent1";s:111:"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.";s:18:"sc_homecontent1img";s:105:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/sampleimages/featured-img-01.png";s:18:"sc_homecontent1url";s:1:"#";s:20:"sc_homecontent2title";s:21:"Browser Compatibility";s:15:"sc_homecontent2";s:111:"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.";s:18:"sc_homecontent2img";s:105:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/sampleimages/featured-img-02.png";s:18:"sc_homecontent2url";s:1:"#";s:20:"sc_homecontent3title";s:23:"Works on Mobile Devices";s:15:"sc_homecontent3";s:111:"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.";s:18:"sc_homecontent3img";s:105:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/sampleimages/featured-img-03.png";s:18:"sc_homecontent3url";s:1:"#";s:20:"sc_homecontent4title";s:18:"Full Documentation";s:15:"sc_homecontent4";s:111:"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.";s:18:"sc_homecontent4img";s:105:"http://127.0.0.1:4001/wordpress/wp-content/themes/modelun/library/images/sampleimages/featured-img-04.png";s:18:"sc_homecontent4url";s:1:"#";s:16:"sc_portfoliohome";s:1:"1";s:21:"sc_portfoliohometitle";s:29:"Some of Our Featured Projects";s:27:"sc_portfoliohomebuttontitle";s:19:"View full portfolio";s:25:"sc_portfoliohomebuttonurl";s:1:"#";s:16:"sc_displayslider";s:0:"";s:12:"sc_slidertag";s:0:"";s:13:"sc_slidertype";s:4:"flex";s:15:"sc_slidereffect";s:5:"slide";s:23:"sc_slideranimationspeed";s:3:"500";s:18:"sc_sliderpausetime";s:4:"3000";s:12:"sc_authorbox";s:1:"1";s:19:"sc_portfoliofilters";s:7:"regular";s:24:"sc_portfolioitemsperpage";s:1:"6";s:18:"sc_contact_address";s:53:"75 Ninth Avenue 2nd and 4th Floors New York, NY 10011";s:16:"sc_contact_phone";s:15:"+1 212-565-0000";s:14:"sc_contact_fax";s:15:"+1 212-565-0000";s:16:"sc_contact_email";s:17:"info@yoursite.com";s:14:"sc_contact_map";s:0:"";s:10:"sc_twitter";s:0:"";s:11:"sc_facebook";s:0:"";s:13:"sc_googleplus";s:0:"";s:10:"sc_dribble";s:0:"";s:8:"sc_vimeo";s:0:"";s:8:"sc_skype";s:0:"";s:11:"sc_linkedin";s:0:"";s:12:"sc_pinterest";s:0:"";s:6:"sc_rss";s:1:"1";s:9:"sc_extrss";s:0:"";s:13:"sc_enablemeta";s:1:"1";s:18:"sc_metadescription";s:69:"full functionable, premium wordpress theme solution for your website.";s:15:"sc_metakeywords";s:108:"proffesional wordpress theme, flexible wordpress theme, wordpress all in one theme, premium wordpress theme ";s:15:"sc_revisitafter";s:1:"2";s:14:"sc_enablerobot";s:1:"1";s:11:"sc_metabots";s:0:"";s:16:"sc_metagooglebot";s:0:"";s:19:"sc_footer_copyright";s:105:"&copy; Copyright 2012 SimpleCorp by <a href=\\\'http://www.site5.com\\\'>Site5.com</a>. All Rights Reserved. ";s:8:"sc_stats";s:0:"";s:11:"sc_css_code";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (916, 'jetpack_activated', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (917, 'jetpack_options', 'a:4:{s:7:"version";s:16:"2.9.3:1397217664";s:11:"old_version";s:16:"2.9.3:1397217664";s:28:"fallback_no_verify_ssl_certs";i:0;s:9:"time_diff";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (919, 'jetpack_log', 'a:3:{i:0;a:4:{s:4:"time";i:1397217672;s:7:"user_id";i:1;s:7:"blog_id";b:0;s:4:"code";s:8:"register";}i:1;a:4:{s:4:"time";i:1399552028;s:7:"user_id";i:1;s:7:"blog_id";b:0;s:4:"code";s:8:"register";}i:2;a:4:{s:4:"time";i:1399552307;s:7:"user_id";i:1;s:7:"blog_id";b:0;s:4:"code";s:8:"register";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (926, 'lightboxplus_options', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1723, 'theme_mods_sumi-shoshi', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1404204115;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:18:"orphaned_widgets_1";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:18:"orphaned_widgets_2";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}s:18:"orphaned_widgets_3";a:5:{i:0;s:8:"search-4";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:9:"monster-8";}s:18:"orphaned_widgets_4";a:3:{i:0;s:9:"monster-9";i:1;s:16:"akismet_widget-2";i:2;s:7:"links-2";}s:18:"orphaned_widgets_5";a:1:{i:0;s:10:"nav_menu-2";}s:18:"orphaned_widgets_6";a:1:{i:0;s:6:"meta-5";}s:18:"orphaned_widgets_7";a:1:{i:0;s:11:"tag_cloud-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (871, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:21:"admin@localhost.local";s:7:"version";s:6:"3.9.23";s:9:"timestamp";i:1522032248;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1730, 'theme_mods_starkers-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1404109864;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:18:"orphaned_widgets_1";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:18:"orphaned_widgets_2";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}s:18:"orphaned_widgets_3";a:5:{i:0;s:8:"search-4";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:9:"monster-8";}s:18:"orphaned_widgets_4";a:3:{i:0;s:9:"monster-9";i:1;s:16:"akismet_widget-2";i:2;s:7:"links-2";}s:18:"orphaned_widgets_5";a:1:{i:0;s:10:"nav_menu-2";}s:18:"orphaned_widgets_6";a:1:{i:0;s:6:"meta-5";}s:18:"orphaned_widgets_7";a:1:{i:0;s:11:"tag_cloud-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1790, 'location_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2176, 'optionsframework', 'a:2:{s:2:"id";s:10:"simplecorp";s:12:"knownoptions";a:1:{i:0;s:10:"simplecorp";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (466, 'widget_pages', 'a:2:{i:2;a:3:{s:5:"title";s:16:"Страници";s:6:"sortby";s:10:"post_title";s:7:"exclude";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2433, '_transient_timeout_feed_c338a64000c51ebf6963bece9325ec30', '1522076353', 'no') ; 
INSERT INTO `wp_options` VALUES (3102, '_transient_timeout_feed_mod_c338a64000c51ebf6963bece9325ec30', '1522095810', 'no') ; 
INSERT INTO `wp_options` VALUES (2370, 'rewrite_rules', 'a:147:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1656, 'theme_mods_twentytwelve-child', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1402907566;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:9:"sidebar-1";a:1:{i:0;s:9:"monster-8";}s:9:"sidebar-2";a:1:{i:0;s:12:"categories-2";}s:9:"sidebar-3";a:1:{i:0;s:8:"search-3";}s:18:"orphaned_widgets_1";a:1:{i:0;s:6:"meta-5";}s:18:"orphaned_widgets_2";a:1:{i:0;s:7:"links-2";}s:18:"orphaned_widgets_3";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:18:"orphaned_widgets_4";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2447, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2853, '_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e', 'a:2:{s:8:"location";a:1:{s:2:"ip";s:9:"127.0.0.0";}s:6:"events";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2422, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1522076330', 'no') ; 
INSERT INTO `wp_options` VALUES (2852, '_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e', '1522079487', 'no') ; 
INSERT INTO `wp_options` VALUES (1340, 'jetpack_register', 'WwgHvgxP4BQkXMJfYpL42Yn7KhZzQ4QM:Mh0QwJdkNLWAWbUwtdD3LxOonGiGFhFK:1399552907', 'yes') ; 
INSERT INTO `wp_options` VALUES (344, 'theme_mods_twentyten-child', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392113216;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";N;s:24:"first-footer-widget-area";N;s:25:"second-footer-widget-area";N;s:24:"third-footer-widget-area";N;s:25:"fourth-footer-widget-area";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (294, 'theme_mods_twentyten', 'a:7:{i:0;b:0;s:16:"background_color";s:6:"f1f1f1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398683663;s:4:"data";a:8:{s:9:"sidebar-1";a:1:{i:0;s:9:"monster-3";}s:21:"in-header-widget-area";a:3:{i:0;s:6:"text-2";i:1;s:8:"search-2";i:2;s:10:"calendar-2";}s:19:"wp_inactive_widgets";a:0:{}s:19:"sidebar-widget-area";a:2:{i:0;s:6:"text-3";i:1;s:9:"monster-2";}s:24:"first-footer-widget-area";a:1:{i:0;s:14:"recent-posts-4";}s:25:"second-footer-widget-area";a:1:{i:0;s:7:"pages-2";}s:24:"third-footer-widget-area";a:1:{i:0;s:6:"meta-4";}s:25:"fourth-footer-widget-area";a:1:{i:0;s:10:"archives-3";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (292, 'theme_mods_twentythirteen', 'a:3:{i:0;b:0;s:16:"header_textcolor";s:6:"220e10";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1400056451;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:11:{i:0;s:10:"calendar-2";i:1;s:7:"links-2";i:2;s:6:"meta-5";i:3;s:8:"search-3";i:4;s:12:"categories-2";i:5;s:9:"monster-3";i:6;s:9:"monster-4";i:7;s:9:"monster-5";i:8;s:9:"monster-6";i:9;s:9:"monster-7";i:10;s:9:"monster-8";}s:18:"orphaned_widgets_1";a:2:{i:0;s:6:"text-2";i:1;s:8:"search-2";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}s:18:"orphaned_widgets_4";a:1:{i:0;s:7:"pages-2";}s:18:"orphaned_widgets_5";a:1:{i:0;s:6:"meta-4";}s:18:"orphaned_widgets_6";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, 'theme_mods_twentyeleven', 'a:8:{s:16:"header_textcolor";s:3:"000";s:16:"background_color";s:6:"f1f1f1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:0;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398683438;s:4:"data";a:8:{s:9:"sidebar-1";a:1:{i:0;s:9:"monster-3";}s:21:"in-header-widget-area";a:3:{i:0;s:6:"text-2";i:1;s:8:"search-2";i:2;s:10:"calendar-2";}s:19:"wp_inactive_widgets";a:0:{}s:19:"sidebar-widget-area";a:2:{i:0;s:6:"text-3";i:1;s:9:"monster-2";}s:24:"first-footer-widget-area";a:1:{i:0;s:14:"recent-posts-4";}s:25:"second-footer-widget-area";a:1:{i:0;s:7:"pages-2";}s:24:"third-footer-widget-area";a:1:{i:0;s:6:"meta-4";}s:25:"fourth-footer-widget-area";a:1:{i:0;s:10:"archives-3";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (163, 'current_theme', 'MazPage', 'yes') ; 
INSERT INTO `wp_options` VALUES (164, 'theme_mods_twentytwelve', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:3:"444";s:16:"background_color";s:6:"e6e6e6";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392118564;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (165, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (166, 'twentyeleven_theme_options', 'a:3:{s:12:"color_scheme";s:5:"light";s:10:"link_color";s:7:"#1b8be0";s:12:"theme_layout";s:15:"content-sidebar";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (403, 'theme_mods_wordpress-from-static', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:17;s:9:"secondary";i:18;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1396530182;s:4:"data";a:8:{s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:19:"wp_inactive_widgets";a:0:{}s:21:"in-header-widget-area";a:2:{i:0;s:6:"text-2";i:1;s:8:"search-3";}s:19:"sidebar-widget-area";a:2:{i:0;s:14:"recent-posts-3";i:1;s:6:"meta-3";}s:24:"first-footer-widget-area";a:1:{i:0;s:14:"recent-posts-4";}s:25:"second-footer-widget-area";a:1:{i:0;s:7:"pages-2";}s:24:"third-footer-widget-area";a:1:{i:0;s:6:"meta-4";}s:25:"fourth-footer-widget-area";a:1:{i:0;s:10:"archives-3";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (170, 'wp-native-dashboard', 'O:8:"stdClass":8:{s:7:"version";s:3:"1.0";s:9:"installed";b:0;s:21:"enable_login_selector";s:1:"1";s:24:"enable_profile_extension";s:1:"1";s:24:"enable_language_switcher";b:0;s:24:"enable_adminbar_switcher";s:1:"1";s:24:"translate_front_adminbar";s:1:"1";s:21:"cleanup_on_deactivate";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2429, '_transient_timeout_plugin_slugs', '1522120933', 'no') ; 
INSERT INTO `wp_options` VALUES (2430, '_transient_plugin_slugs', 'a:17:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:23:"debug-bar/debug-bar.php";i:3;s:39:"debug-bar-console/debug-bar-console.php";i:4;s:23:"developer/developer.php";i:5;s:9:"hello.php";i:6;s:19:"jetpack/jetpack.php";i:7;s:30:"lightbox-plus/lightboxplus.php";i:8;s:49:"log-deprecated-notices/log-deprecated-notices.php";i:9;s:33:"monster-widget/monster-widget.php";i:10;s:35:"simply-show-ids/simply-show-ids.php";i:11;s:27:"theme-check/theme-check.php";i:12;s:41:"wordpress-importer/wordpress-importer.php";i:13;s:35:"wordpress-reset/wordpress-reset.php";i:14;s:28:"wp-example-content/magic.php";i:15;s:31:"wp-migrate-db/wp-migrate-db.php";i:16;s:43:"wp-native-dashboard/wp-native-dashboard.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2431, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1522076347', 'no') ; 
INSERT INTO `wp_options` VALUES (2432, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/03/the-month-in-wordpress-february-2018/\'>The Month in WordPress: February 2018</a> <span class="rss-date">March 1, 2018</span><div class="rssSummary">Judging by the flurry of activity across the WordPress project throughout February, it looks like everyone is really getting into the swing of things for 2018. There have been a lot of interesting new developments, so read on to see what the community has been up to for the past month. WordPress 4.9.3 &amp; 4.9.4 […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://buddypress.org/2018/03/10-years/\' title=\'In 2008 (just 10 short years ago) Andy Peatling made the very first code-commit to the newly adopted BuddyPress project, joining bbPress, GlotPress, and BackPress at the time. As most of you can probably imagine, BuddyPress was a different piece of software back then, trying to solve a completely different decade’s worth of problems for a completely differen\'>BuddyPress: 10 years</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\' title=\'WordPress 4.9.5 Beta 1 is available for testing and brings with it 23 bug fixes and improvements. A release candidate is scheduled for release on March 20th and a final release on April 3rd. Here are some notable changes you can expect in the release. &quot;Cheatin’ uh?&quot; Error Message is Replaced The &quot;Cheatin’ uh?&quot; error message has existed in\'>WPTavern: Noteworthy Changes Coming in WordPress 4.9.5</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wpweekly-episode-309-all-amped-up\' title=\'In this episode, I’m joined by Alberto Medina, Developer Advocate working with the Web Content Ecosystems Team at Google, and Weston Ruter, CTO of XWP. We have a candid conversation about Google’s AMP Project. We start by learning why the project was created, what its main goal is, and the technology behind it. We also dive into some of the controversy surro\'>WPTavern: WPWeekly Episode 309 – All AMPed Up</a></li></ul></div><div class="rss-widget"><ul></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (305, 'theme_mods_responsive-bootstrap', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392041679;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (338, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (999, 'widget_calendar', 'a:3:{i:1;a:0:{}i:2;a:1:{s:5:"title";s:8:"Calendar";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1000, 'widget_links', 'a:3:{i:1;a:0:{}i:2;a:7:{s:6:"images";i:1;s:4:"name";i:1;s:11:"description";i:1;s:6:"rating";i:1;s:7:"orderby";s:4:"name";s:8:"category";i:0;s:5:"limit";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1001, 'widget_tag_cloud', 'a:3:{i:1;a:0:{}i:2;a:2:{s:5:"title";s:4:"Tags";s:8:"taxonomy";s:8:"post_tag";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1002, 'widget_nav_menu', 'a:3:{i:1;a:0:{}i:2;a:2:{s:5:"title";s:4:"Menu";s:8:"nav_menu";i:191;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1003, 'widget_monster', 'a:9:{i:1;a:0:{}i:3;a:0:{}i:4;a:0:{}i:5;a:0:{}i:6;a:0:{}i:7;a:0:{}i:8;a:0:{}i:9;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2420, '_site_transient_timeout_browser_efc56fe28520bcd166ef136f44025003', '1522637926', 'yes') ; 
INSERT INTO `wp_options` VALUES (2421, '_site_transient_browser_efc56fe28520bcd166ef136f44025003', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:13:"65.0.3325.181";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2173, 'theme_mods_unabg', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1406112104;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:9:"sidebar-1";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:9:"sidebar-2";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}s:9:"sidebar-3";a:5:{i:0;s:8:"search-4";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:9:"monster-8";}s:18:"orphaned_widgets_1";a:3:{i:0;s:9:"monster-9";i:1;s:16:"akismet_widget-2";i:2;s:7:"links-2";}s:18:"orphaned_widgets_2";a:1:{i:0;s:10:"nav_menu-2";}s:18:"orphaned_widgets_3";a:1:{i:0;s:6:"meta-5";}s:18:"orphaned_widgets_4";a:1:{i:0;s:11:"tag_cloud-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (748, 'theme_mods_twentyfourteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522033134;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:18:{i:0;s:10:"calendar-2";i:1;s:8:"search-2";i:2;s:6:"text-2";i:3;s:10:"archives-2";i:4;s:8:"search-4";i:5;s:14:"recent-posts-2";i:6;s:17:"recent-comments-2";i:7;s:11:"tag_cloud-2";i:8;s:10:"nav_menu-2";i:9;s:16:"akismet_widget-2";i:10;s:9:"monster-9";i:11;s:7:"links-2";i:12;s:6:"meta-5";i:13;s:9:"monster-4";i:14;s:9:"monster-5";i:15;s:9:"monster-6";i:16;s:9:"monster-7";i:17;s:9:"monster-8";}s:18:"orphaned_widgets_1";a:1:{i:0;s:9:"monster-3";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}s:18:"orphaned_widgets_4";a:1:{i:0;s:7:"pages-2";}s:18:"orphaned_widgets_5";a:1:{i:0;s:6:"meta-4";}s:18:"orphaned_widgets_6";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (751, 'theme_mods_purple-modena', 'a:43:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:17;}s:12:"header_image";s:118:"http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg";s:16:"background_color";s:6:"ede1a8";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:16:"header_textcolor";s:6:"000000";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:1765;s:3:"url";s:118:"http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg";s:13:"thumbnail_url";s:118:"http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg";s:6:"height";i:300;s:5:"width";i:1200;}s:15:"tt_gfp_body_tag";s:0:"";s:25:"tt_gfp_body_css_selectors";s:10:"site-title";s:23:"tt_gfp_body_font_family";s:9:"Audiowide";s:23:"tt_gfp_body_font_weight";s:7:"regular";s:12:"tt_gfp_p_tag";s:0:"";s:22:"tt_gfp_p_css_selectors";s:0:"";s:20:"tt_gfp_p_font_family";s:7:"default";s:20:"tt_gfp_p_font_weight";s:7:"regular";s:13:"tt_gfp_h1_tag";s:0:"";s:23:"tt_gfp_h1_css_selectors";s:0:"";s:21:"tt_gfp_h1_font_family";s:7:"default";s:21:"tt_gfp_h1_font_weight";s:7:"regular";s:13:"tt_gfp_h2_tag";s:0:"";s:23:"tt_gfp_h2_css_selectors";s:0:"";s:21:"tt_gfp_h2_font_family";s:7:"default";s:21:"tt_gfp_h2_font_weight";s:7:"regular";s:13:"tt_gfp_h3_tag";s:0:"";s:23:"tt_gfp_h3_css_selectors";s:0:"";s:21:"tt_gfp_h3_font_family";s:7:"default";s:21:"tt_gfp_h3_font_weight";s:7:"regular";s:12:"tt_gfp_a_tag";s:0:"";s:22:"tt_gfp_a_css_selectors";s:0:"";s:20:"tt_gfp_a_font_family";s:7:"default";s:20:"tt_gfp_a_font_weight";s:7:"regular";s:21:"tt_gfp_blockquote_tag";s:0:"";s:31:"tt_gfp_blockquote_css_selectors";s:0:"";s:29:"tt_gfp_blockquote_font_family";s:7:"default";s:29:"tt_gfp_blockquote_font_weight";s:7:"regular";s:13:"tt_gfp_li_tag";s:0:"";s:23:"tt_gfp_li_css_selectors";s:0:"";s:21:"tt_gfp_li_font_family";s:7:"default";s:21:"tt_gfp_li_font_weight";s:7:"regular";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522033131;s:4:"data";a:8:{s:18:"orphaned_widgets_1";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:18:"orphaned_widgets_2";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:19:"sidebar-widget-area";a:5:{i:0;s:8:"search-4";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:9:"monster-8";}s:24:"first-footer-widget-area";a:3:{i:0;s:9:"monster-9";i:1;s:16:"akismet_widget-2";i:2;s:7:"links-2";}s:25:"second-footer-widget-area";a:1:{i:0;s:10:"nav_menu-2";}s:24:"third-footer-widget-area";a:1:{i:0;s:6:"meta-5";}s:25:"fourth-footer-widget-area";a:1:{i:0;s:11:"tag_cloud-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1782, 'project_category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1787, 'theme_mods_twentyfourteen-child', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1403874448;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:4:{i:0;s:9:"monster-4";i:1;s:9:"monster-5";i:2;s:9:"monster-6";i:3;s:9:"monster-7";}s:9:"sidebar-1";a:2:{i:0;s:9:"monster-3";i:1;s:7:"pages-2";}s:9:"sidebar-2";a:4:{i:0;s:6:"meta-4";i:1;s:6:"text-2";i:2;s:8:"search-2";i:3;s:10:"calendar-2";}s:9:"sidebar-3";a:5:{i:0;s:8:"search-4";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:9:"monster-8";}s:18:"orphaned_widgets_1";a:3:{i:0;s:9:"monster-9";i:1;s:16:"akismet_widget-2";i:2;s:7:"links-2";}s:18:"orphaned_widgets_2";a:1:{i:0;s:10:"nav_menu-2";}s:18:"orphaned_widgets_3";a:1:{i:0;s:6:"meta-5";}s:18:"orphaned_widgets_4";a:1:{i:0;s:11:"tag_cloud-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1920, 'ser_cyr_to_lat_slug', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2569, 'woocommerce_email_background_color', '#f7f7f7', 'no') ; 
INSERT INTO `wp_options` VALUES (2570, 'woocommerce_email_body_background_color', '#ffffff', 'no') ; 
INSERT INTO `wp_options` VALUES (2571, 'woocommerce_email_text_color', '#3c3c3c', 'no') ; 
INSERT INTO `wp_options` VALUES (2572, 'woocommerce_api_enabled', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2574, 'current_theme_supports_woocommerce', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (3103, '_transient_feed_mod_c338a64000c51ebf6963bece9325ec30', '1522052610', 'no') ; 
INSERT INTO `wp_options` VALUES (2142, 'hmbkp_default_path', 'C:/Users/DanhCong/Desktop/wp/iwpserver/htdocs/wordpress/wp-content/backupwordpress-4ebb3fe613-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (2143, 'hmbkp_path', 'C:/Users/DanhCong/Desktop/wp/iwpserver/htdocs/wordpress/wp-content/backupwordpress-4ebb3fe613-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (2144, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1406145600;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2145, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1406419200;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2146, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (2149, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2812302926', 'no') ; 
INSERT INTO `wp_options` VALUES (2150, '_transient_hmbkp_schedule_default-1_database_filesize', '1070236', 'no') ; 
INSERT INTO `wp_options` VALUES (2443, 'finished_splitting_shared_terms', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2444, 'site_icon', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (2445, 'medium_large_size_w', '768', 'yes') ; 
INSERT INTO `wp_options` VALUES (2446, 'medium_large_size_h', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (2623, 'theme_mods_storefront', 'a:7:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:17:"storefront_styles";s:5060:"
			.main-navigation ul li a,
			.site-title a,
			ul.menu li a,
			.site-branding h1 a,
			.site-footer .storefront-handheld-footer-bar a:not(.button),
			button.menu-toggle,
			button.menu-toggle:hover {
				color: #333333;
			}

			button.menu-toggle,
			button.menu-toggle:hover {
				border-color: #333333;
			}

			.main-navigation ul li a:hover,
			.main-navigation ul li:hover > a,
			.site-title a:hover,
			a.cart-contents:hover,
			.site-header-cart .widget_shopping_cart a:hover,
			.site-header-cart:hover > li > a,
			.site-header ul.menu li.current-menu-item > a {
				color: #747474;
			}

			table th {
				background-color: #f8f8f8;
			}

			table tbody td {
				background-color: #fdfdfd;
			}

			table tbody tr:nth-child(2n) td,
			fieldset,
			fieldset legend {
				background-color: #fbfbfb;
			}

			.site-header,
			.secondary-navigation ul ul,
			.main-navigation ul.menu > li.menu-item-has-children:after,
			.secondary-navigation ul.menu ul,
			.storefront-handheld-footer-bar,
			.storefront-handheld-footer-bar ul li > a,
			.storefront-handheld-footer-bar ul li.search .site-search,
			button.menu-toggle,
			button.menu-toggle:hover {
				background-color: #ffffff;
			}

			p.site-description,
			.site-header,
			.storefront-handheld-footer-bar {
				color: #404040;
			}

			.storefront-handheld-footer-bar ul li.cart .count,
			button.menu-toggle:after,
			button.menu-toggle:before,
			button.menu-toggle span:before {
				background-color: #333333;
			}

			.storefront-handheld-footer-bar ul li.cart .count {
				color: #ffffff;
			}

			.storefront-handheld-footer-bar ul li.cart .count {
				border-color: #ffffff;
			}

			h1, h2, h3, h4, h5, h6 {
				color: #333333;
			}

			.widget h1 {
				border-bottom-color: #333333;
			}

			body,
			.secondary-navigation a,
			.onsale,
			.pagination .page-numbers li .page-numbers:not(.current), .woocommerce-pagination .page-numbers li .page-numbers:not(.current) {
				color: #6d6d6d;
			}

			.widget-area .widget a,
			.hentry .entry-header .posted-on a,
			.hentry .entry-header .byline a {
				color: #727272;
			}

			a  {
				color: #96588a;
			}

			a:focus,
			.button:focus,
			.button.alt:focus,
			.button.added_to_cart:focus,
			.button.wc-forward:focus,
			button:focus,
			input[type="button"]:focus,
			input[type="reset"]:focus,
			input[type="submit"]:focus {
				outline-color: #96588a;
			}

			button, input[type="button"], input[type="reset"], input[type="submit"], .button, .added_to_cart, .widget a.button, .site-header-cart .widget_shopping_cart a.button {
				background-color: #eeeeee;
				border-color: #eeeeee;
				color: #333333;
			}

			button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, .button:hover, .added_to_cart:hover, .widget a.button:hover, .site-header-cart .widget_shopping_cart a.button:hover {
				background-color: #d5d5d5;
				border-color: #d5d5d5;
				color: #333333;
			}

			button.alt, input[type="button"].alt, input[type="reset"].alt, input[type="submit"].alt, .button.alt, .added_to_cart.alt, .widget-area .widget a.button.alt, .added_to_cart, .widget a.button.checkout {
				background-color: #333333;
				border-color: #333333;
				color: #ffffff;
			}

			button.alt:hover, input[type="button"].alt:hover, input[type="reset"].alt:hover, input[type="submit"].alt:hover, .button.alt:hover, .added_to_cart.alt:hover, .widget-area .widget a.button.alt:hover, .added_to_cart:hover, .widget a.button.checkout:hover {
				background-color: #1a1a1a;
				border-color: #1a1a1a;
				color: #ffffff;
			}

			.pagination .page-numbers li .page-numbers.current, .woocommerce-pagination .page-numbers li .page-numbers.current {
				background-color: #e6e6e6;
				color: #636363;
			}

			#comments .comment-list .comment-content .comment-text {
				background-color: #f8f8f8;
			}

			.site-footer {
				background-color: #f0f0f0;
				color: #6d6d6d;
			}

			.site-footer a:not(.button) {
				color: #333333;
			}

			.site-footer h1, .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5, .site-footer h6 {
				color: #333333;
			}

			#order_review {
				background-color: #ffffff;
			}

			#payment .payment_methods > li .payment_box,
			#payment .place-order {
				background-color: #fafafa;
			}

			#payment .payment_methods > li:not(.woocommerce-notice) {
				background-color: #f5f5f5;
			}

			#payment .payment_methods > li:not(.woocommerce-notice):hover {
				background-color: #f0f0f0;
			}

			@media screen and ( min-width: 768px ) {
				.secondary-navigation ul.menu a:hover {
					color: #595959;
				}

				.secondary-navigation ul.menu a {
					color: #404040;
				}

				.site-header-cart .widget_shopping_cart,
				.main-navigation ul.menu ul.sub-menu,
				.main-navigation ul.nav-menu ul.children {
					background-color: #f0f0f0;
				}

				.site-header-cart .widget_shopping_cart .buttons,
				.site-header-cart .widget_shopping_cart .total {
					background-color: #f5f5f5;
				}

				.site-header {
					border-bottom-color: #f0f0f0;
				}
			}";s:29:"storefront_woocommerce_styles";s:2283:"
			a.cart-contents,
			.site-header-cart .widget_shopping_cart a {
				color: #333333;
			}

			table.cart td.product-remove,
			table.cart td.actions {
				border-top-color: #ffffff;
			}

			.woocommerce-tabs ul.tabs li.active a,
			ul.products li.product .price,
			.onsale,
			.widget_search form:before,
			.widget_product_search form:before {
				color: #6d6d6d;
			}

			.woocommerce-breadcrumb a,
			a.woocommerce-review-link,
			.product_meta a {
				color: #727272;
			}

			.onsale {
				border-color: #6d6d6d;
			}

			.star-rating span:before,
			.quantity .plus, .quantity .minus,
			p.stars a:hover:after,
			p.stars a:after,
			.star-rating span:before,
			#payment .payment_methods li input[type=radio]:first-child:checked+label:before {
				color: #96588a;
			}

			.widget_price_filter .ui-slider .ui-slider-range,
			.widget_price_filter .ui-slider .ui-slider-handle {
				background-color: #96588a;
			}

			.order_details {
				background-color: #f8f8f8;
			}

			.order_details > li {
				border-bottom: 1px dotted #e3e3e3;
			}

			.order_details:before,
			.order_details:after {
				background: -webkit-linear-gradient(transparent 0,transparent 0),-webkit-linear-gradient(135deg,#f8f8f8 33.33%,transparent 33.33%),-webkit-linear-gradient(45deg,#f8f8f8 33.33%,transparent 33.33%)
			}

			p.stars a:before,
			p.stars a:hover~a:before,
			p.stars.selected a.active~a:before {
				color: #6d6d6d;
			}

			p.stars.selected a.active:before,
			p.stars:hover a:before,
			p.stars.selected a:not(.active):before,
			p.stars.selected a.active:before {
				color: #96588a;
			}

			.single-product div.product .woocommerce-product-gallery .woocommerce-product-gallery__trigger {
				background-color: #eeeeee;
				color: #333333;
			}

			.single-product div.product .woocommerce-product-gallery .woocommerce-product-gallery__trigger:hover {
				background-color: #d5d5d5;
				border-color: #d5d5d5;
				color: #333333;
			}

			.button.loading {
				color: #eeeeee;
			}

			.button.loading:hover {
				background-color: #eeeeee;
			}

			.button.loading:after {
				color: #333333;
			}

			@media screen and ( min-width: 768px ) {
				.site-header-cart .widget_shopping_cart,
				.site-header .product_list_widget li .quantity {
					color: #404040;
				}
			}";s:39:"storefront_woocommerce_extension_styles";s:0:"";s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522036353;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:19:{i:0;s:10:"calendar-2";i:1;s:10:"archives-2";i:2;s:7:"links-2";i:3;s:6:"meta-5";i:4;s:8:"search-2";i:5;s:8:"search-4";i:6;s:6:"text-2";i:7;s:14:"recent-posts-2";i:8;s:17:"recent-comments-2";i:9;s:11:"tag_cloud-2";i:10;s:10:"nav_menu-2";i:11;s:16:"akismet_widget-2";i:12;s:9:"monster-4";i:13;s:9:"monster-5";i:14;s:9:"monster-6";i:15;s:9:"monster-7";i:16;s:9:"monster-8";i:17;s:9:"monster-9";i:18;s:7:"pages-2";}s:9:"sidebar-1";a:1:{i:0;s:9:"monster-3";}s:8:"header-1";a:1:{i:0;s:25:"woocommerce_layered_nav-2";}s:8:"footer-1";a:1:{i:0;s:6:"meta-4";}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2624, 'storefront_nux_fresh_site', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (2450, 'widget_mazpage_widget_post_by_tag', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2451, 'widget_mazpage_widget_sticky_post', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2452, 'widget_mazpage_widget_posts_by_tag_home', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2453, 'widget_mazpage_widget_social', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2454, 'widget_mazpage_widget_subscribe', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2455, 'widget_mazpage_widget_advertisement', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2456, 'widget_mazpage_widget_trending_posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2457, 'widget_mazpage_widget_tab_posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2458, 'widget_mazpage_widget_social_footer', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2459, 'widget_mazpage_instagram', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2460, 'widget_mazpage_widget_category_home', 'a:3:{i:2;a:4:{s:8:"category";s:3:"240";s:5:"style";s:12:"big_thumnail";s:6:"number";s:1:"5";s:5:"title";s:26:"san pham <span>hot </span>";}i:3;a:3:{s:8:"category";s:3:"242";s:5:"title";s:0:"";s:6:"number";s:1:"5";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2461, 'widget_mazpage_widget_social_about_page', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2462, 'widget_mazpage_widget_contact_form', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2463, 'widget_mazpage_widget_contact_information', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2464, 'widget_mazpage_widget_slider_home', 'a:2:{i:2;a:2:{s:3:"tag";s:4:"news";s:6:"number";s:1:"5";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2466, 'can_compress_scripts', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (2625, 'woocommerce_catalog_rows', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (2626, 'woocommerce_catalog_columns', '3', 'yes') ; 
INSERT INTO `wp_options` VALUES (2627, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes') ; 
INSERT INTO `wp_options` VALUES (2845, '_transient_wc_report_sales_by_date', 'a:16:{s:32:"d8cda2239908f57e1578fc7e42d2c605";a:0:{}s:32:"9439dabe82e60d0383590b548d0b8b5c";a:0:{}s:32:"bd91efba28c289040f345f10c153f809";a:0:{}s:32:"f8327418aeeb3ea2cb7bef3b98779183";N;s:32:"4dc9eff7b91e93e8038c694de80329e9";a:0:{}s:32:"145da9387bcf4b6bf171e335b69b2cd7";a:0:{}s:32:"1eb18f23af746b23a04efec027234e66";a:0:{}s:32:"1f830efa89abc9104ae018040dbc5ef7";a:0:{}s:32:"3f967106e99eb668bcf4fca0b56c26e6";a:0:{}s:32:"b760b55b241ed7232feaa987c2279bc8";a:0:{}s:32:"c204238f76648cbe475c2b09b077ad0c";a:0:{}s:32:"87527719fcc790f7da58378c48552317";N;s:32:"94b2fd0ff917db19d3d595f062601923";a:0:{}s:32:"74d98da4308895636ddd3c539d70fb9c";a:0:{}s:32:"9457a64ee8eca6a6eada5f8769e1f4c2";a:0:{}s:32:"e4da66afaaa794d4b68214d827e91dc1";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2846, '_transient_timeout_wc_admin_report', '1522122683', 'no') ; 
INSERT INTO `wp_options` VALUES (2847, '_transient_wc_admin_report', 'a:1:{s:32:"d927111096590ee47a5bd9e60d96f659";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2724, '_transient_product-transient-version', '1522055192', 'yes') ; 
INSERT INTO `wp_options` VALUES (2719, '_transient_product_query-transient-version', '1522055192', 'yes') ; 
INSERT INTO `wp_options` VALUES (2711, 'storefront_nux_guided_tour', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2854, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1522079488', 'no') ; 
INSERT INTO `wp_options` VALUES (2855, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1522036288', 'no') ; 
INSERT INTO `wp_options` VALUES (2856, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1522079489', 'no') ; 
INSERT INTO `wp_options` VALUES (2663, '_transient_shipping-transient-version', '1522035213', 'yes') ; 
INSERT INTO `wp_options` VALUES (2664, '_transient_timeout_wc_shipping_method_count_0_1522035213', '1524627213', 'no') ; 
INSERT INTO `wp_options` VALUES (2665, '_transient_wc_shipping_method_count_0_1522035213', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (2822, '_transient_timeout_wc_shipping_method_count_1_1522035213', '1524628087', 'no') ; 
INSERT INTO `wp_options` VALUES (2823, '_transient_wc_shipping_method_count_1_1522035213', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (2844, '_transient_timeout_wc_report_sales_by_date', '1522133681', 'no') ; 
INSERT INTO `wp_options` VALUES (2629, '_transient_timeout_external_ip_address_127.0.0.1', '1522639988', 'no') ; 
INSERT INTO `wp_options` VALUES (2630, '_transient_external_ip_address_127.0.0.1', '503 Over Quota Error &nbsp; Over Quota This application is temporarily over its serving quota. Please try again later.', 'no') ; 
INSERT INTO `wp_options` VALUES (2615, '_transient_timeout__woocommerce_helper_updates', '1522078343', 'no') ; 
INSERT INTO `wp_options` VALUES (2616, '_transient__woocommerce_helper_updates', 'a:4:{s:4:"hash";s:32:"d751713988987e9331980363e24189ce";s:7:"updated";i:1522035143;s:8:"products";a:0:{}s:6:"errors";a:1:{i:0;s:10:"http-error";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2485, 'woocommerce_store_address', 'danhcong', 'yes') ; 
INSERT INTO `wp_options` VALUES (2486, 'woocommerce_store_address_2', 'danhcong', 'yes') ; 
INSERT INTO `wp_options` VALUES (2487, 'woocommerce_store_city', 'hanoi', 'yes') ; 
INSERT INTO `wp_options` VALUES (2488, 'woocommerce_default_country', 'GB', 'yes') ; 
INSERT INTO `wp_options` VALUES (2489, 'woocommerce_store_postcode', '90000', 'yes') ; 
INSERT INTO `wp_options` VALUES (2490, 'woocommerce_allowed_countries', 'all', 'yes') ; 
INSERT INTO `wp_options` VALUES (2491, 'woocommerce_all_except_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2492, 'woocommerce_specific_allowed_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2493, 'woocommerce_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2494, 'woocommerce_specific_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2495, 'woocommerce_default_customer_address', 'geolocation', 'yes') ; 
INSERT INTO `wp_options` VALUES (2496, 'woocommerce_calc_taxes', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2497, 'woocommerce_currency', 'GBP', 'yes') ; 
INSERT INTO `wp_options` VALUES (2498, 'woocommerce_currency_pos', 'left', 'yes') ; 
INSERT INTO `wp_options` VALUES (2499, 'woocommerce_price_thousand_sep', ',', 'yes') ; 
INSERT INTO `wp_options` VALUES (2500, 'woocommerce_price_decimal_sep', '.', 'yes') ; 
INSERT INTO `wp_options` VALUES (2501, 'woocommerce_price_num_decimals', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (2502, 'woocommerce_shop_page_id', '1802', 'yes') ; 
INSERT INTO `wp_options` VALUES (2503, 'woocommerce_cart_redirect_after_add', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2504, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2505, 'woocommerce_weight_unit', 'kg', 'yes') ; 
INSERT INTO `wp_options` VALUES (2506, 'woocommerce_dimension_unit', 'cm', 'yes') ; 
INSERT INTO `wp_options` VALUES (2507, 'woocommerce_enable_reviews', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2508, 'woocommerce_review_rating_verification_label', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2509, 'woocommerce_review_rating_verification_required', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2510, 'woocommerce_enable_review_rating', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2511, 'woocommerce_review_rating_required', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2512, 'woocommerce_manage_stock', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2513, 'woocommerce_hold_stock_minutes', '60', 'no') ; 
INSERT INTO `wp_options` VALUES (2514, 'woocommerce_notify_low_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2515, 'woocommerce_notify_no_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2516, 'woocommerce_stock_email_recipient', 'admin@localhost.local', 'no') ; 
INSERT INTO `wp_options` VALUES (2517, 'woocommerce_notify_low_stock_amount', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (2518, 'woocommerce_notify_no_stock_amount', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (2519, 'woocommerce_hide_out_of_stock_items', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2520, 'woocommerce_stock_format', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2521, 'woocommerce_file_download_method', 'force', 'no') ; 
INSERT INTO `wp_options` VALUES (2522, 'woocommerce_downloads_require_login', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2523, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2524, 'woocommerce_prices_include_tax', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2525, 'woocommerce_tax_based_on', 'shipping', 'yes') ; 
INSERT INTO `wp_options` VALUES (2526, 'woocommerce_shipping_tax_class', 'inherit', 'yes') ; 
INSERT INTO `wp_options` VALUES (2527, 'woocommerce_tax_round_at_subtotal', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2528, 'woocommerce_tax_classes', 'Reduced rate
Zero rate', 'yes') ; 
INSERT INTO `wp_options` VALUES (2529, 'woocommerce_tax_display_shop', 'excl', 'yes') ; 
INSERT INTO `wp_options` VALUES (2530, 'woocommerce_tax_display_cart', 'excl', 'no') ; 
INSERT INTO `wp_options` VALUES (2531, 'woocommerce_price_display_suffix', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2532, 'woocommerce_tax_total_display', 'itemized', 'no') ; 
INSERT INTO `wp_options` VALUES (2533, 'woocommerce_enable_shipping_calc', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2534, 'woocommerce_shipping_cost_requires_address', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2535, 'woocommerce_ship_to_destination', 'billing', 'no') ; 
INSERT INTO `wp_options` VALUES (2536, 'woocommerce_shipping_debug_mode', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2537, 'woocommerce_enable_coupons', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2538, 'woocommerce_calc_discounts_sequentially', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2539, 'woocommerce_enable_guest_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2540, 'woocommerce_force_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2541, 'woocommerce_unforce_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2542, 'woocommerce_cart_page_id', '1803', 'yes') ; 
INSERT INTO `wp_options` VALUES (2543, 'woocommerce_checkout_page_id', '1804', 'yes') ; 
INSERT INTO `wp_options` VALUES (2544, 'woocommerce_terms_page_id', '', 'no') ; 
INSERT INTO `wp_options` VALUES (2545, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes') ; 
INSERT INTO `wp_options` VALUES (2546, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes') ; 
INSERT INTO `wp_options` VALUES (2547, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes') ; 
INSERT INTO `wp_options` VALUES (2548, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes') ; 
INSERT INTO `wp_options` VALUES (2549, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes') ; 
INSERT INTO `wp_options` VALUES (2550, 'woocommerce_myaccount_page_id', '1805', 'yes') ; 
INSERT INTO `wp_options` VALUES (2551, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2552, 'woocommerce_enable_myaccount_registration', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2553, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2554, 'woocommerce_registration_generate_username', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (2555, 'woocommerce_registration_generate_password', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (2556, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes') ; 
INSERT INTO `wp_options` VALUES (2557, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes') ; 
INSERT INTO `wp_options` VALUES (2558, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes') ; 
INSERT INTO `wp_options` VALUES (2559, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes') ; 
INSERT INTO `wp_options` VALUES (2560, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes') ; 
INSERT INTO `wp_options` VALUES (2561, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes') ; 
INSERT INTO `wp_options` VALUES (2562, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes') ; 
INSERT INTO `wp_options` VALUES (2563, 'woocommerce_logout_endpoint', 'customer-logout', 'yes') ; 
INSERT INTO `wp_options` VALUES (2564, 'woocommerce_email_from_name', 'Purple Modena', 'no') ; 
INSERT INTO `wp_options` VALUES (2565, 'woocommerce_email_from_address', 'admin@localhost.local', 'no') ; 
INSERT INTO `wp_options` VALUES (2566, 'woocommerce_email_header_image', '', 'no') ; 
INSERT INTO `wp_options` VALUES (2567, 'woocommerce_email_footer_text', '{site_title}', 'no') ; 
INSERT INTO `wp_options` VALUES (2568, 'woocommerce_email_base_color', '#96588a', 'no') ; 
INSERT INTO `wp_options` VALUES (2467, 'theme_mods_smart4baby', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:9:"main-menu";i:17;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522035174;s:4:"data";a:10:{s:19:"wp_inactive_widgets";N;s:15:"mazpage_sidebar";a:1:{i:0;s:9:"monster-3";}s:12:"mazpage_home";a:0:{}s:21:"mazpage_social_footer";a:0:{}s:16:"mazpage_home_big";a:1:{i:0;s:7:"pages-2";}s:23:"mazpage_footer_column_1";a:1:{i:0;s:6:"meta-4";}s:23:"mazpage_footer_column_2";a:0:{}s:23:"mazpage_footer_column_3";N;s:13:"mazpage_about";N;s:15:"mazpage_contact";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2575, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (2576, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3061, 'product_cat_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2578, 'default_product_cat', '235', 'yes') ; 
INSERT INTO `wp_options` VALUES (2599, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2600, 'woocommerce_product_type', 'both', 'yes') ; 
INSERT INTO `wp_options` VALUES (2581, 'woocommerce_version', '3.3.4', 'yes') ; 
INSERT INTO `wp_options` VALUES (2582, 'woocommerce_db_version', '3.3.4', 'yes') ; 
INSERT INTO `wp_options` VALUES (3129, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.4.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.4.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.4";s:7:"version";s:5:"4.9.4";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1522137077;s:15:"version_checked";s:5:"4.9.4";s:12:"translations";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (3130, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1522137079;s:7:"checked";a:7:{s:7:"mazpage";s:3:"1.0";s:10:"smart4baby";s:3:"1.0";s:10:"storefront";s:5:"2.2.8";s:13:"twentyfifteen";s:3:"1.9";s:15:"twentyseventeen";s:3:"1.4";s:13:"twentysixteen";s:3:"1.4";s:9:"twentyten";s:3:"1.6";}s:8:"response";a:1:{s:9:"twentyten";a:4:{s:5:"theme";s:9:"twentyten";s:11:"new_version";s:3:"2.4";s:3:"url";s:39:"https://wordpress.org/themes/twentyten/";s:7:"package";s:55:"https://downloads.wordpress.org/theme/twentyten.2.4.zip";}}s:12:"translations";a:0:{}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2583, 'woocommerce_admin_notices', 'a:2:{i:0;s:19:"no_shipping_methods";i:1;s:14:"template_files";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2584, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2585, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2586, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2587, 'widget_woocommerce_layered_nav', 'a:2:{i:2;a:4:{s:5:"title";s:9:"Filter by";s:9:"attribute";s:0:"";s:12:"display_type";s:4:"list";s:10:"query_type";s:3:"and";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2588, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2589, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2590, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2591, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2592, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2593, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2594, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2595, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2596, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2598, '_transient_wc_count_comments', 'O:8:"stdClass":7:{s:14:"total_comments";i:65;s:3:"all";i:65;s:8:"approved";s:2:"65";s:9:"moderated";i:0;s:4:"spam";i:0;s:5:"trash";i:0;s:12:"post-trashed";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2601, 'woocommerce_allow_tracking', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (2602, 'woocommerce_tracker_last_send', '1522035121', 'yes') ; 
INSERT INTO `wp_options` VALUES (2603, 'fresh_site', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (2611, 'wc_ppec_version', '1.5.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (2605, 'woocommerce_stripe_settings', 'a:3:{s:7:"enabled";s:3:"yes";s:14:"create_account";b:0;s:5:"email";s:18:"congnd91@gmail.com";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2612, 'wc_gateway_ppce_bootstrap_warning_message', 'WooCommerce Gateway PayPal Express Checkout requires OpenSSL >= 1.0.1 to be installed on your server', 'yes') ; 
INSERT INTO `wp_options` VALUES (2607, 'woocommerce_ppec_paypal_settings', 'a:2:{s:16:"reroute_requests";b:0;s:5:"email";s:18:"congnd91@gmail.com";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2608, 'woocommerce_cheque_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2609, 'woocommerce_bacs_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2610, 'woocommerce_cod_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2618, 'wc_stripe_version', '4.0.7', 'yes') ; 
INSERT INTO `wp_options` VALUES (2620, 'woocommerce_setup_jetpack_opted_in', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2573, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3131, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1522137081;s:7:"checked";a:20:{s:19:"akismet/akismet.php";s:5:"3.0.0";s:35:"backupwordpress/backupwordpress.php";s:5:"2.6.2";s:23:"debug-bar/debug-bar.php";s:5:"0.8.1";s:39:"debug-bar-console/debug-bar-console.php";s:3:"0.3";s:23:"developer/developer.php";s:5:"1.2.5";s:9:"hello.php";s:3:"1.6";s:19:"jetpack/jetpack.php";s:5:"2.9.3";s:30:"lightbox-plus/lightboxplus.php";s:3:"2.6";s:49:"log-deprecated-notices/log-deprecated-notices.php";s:3:"0.2";s:33:"monster-widget/monster-widget.php";s:3:"0.3";s:35:"simply-show-ids/simply-show-ids.php";s:5:"1.3.3";s:27:"theme-check/theme-check.php";s:10:"20131213.1";s:27:"woocommerce/woocommerce.php";s:5:"3.3.4";s:91:"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php";s:5:"1.5.2";s:57:"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php";s:5:"4.0.7";s:41:"wordpress-importer/wordpress-importer.php";s:5:"0.6.1";s:35:"wordpress-reset/wordpress-reset.php";s:5:"1.3.3";s:28:"wp-example-content/magic.php";s:3:"1.2";s:31:"wp-migrate-db/wp-migrate-db.php";s:3:"0.5";s:43:"wp-native-dashboard/wp-native-dashboard.php";s:6:"1.3.12";}s:8:"response";a:11:{s:19:"akismet/akismet.php";O:8:"stdClass":11:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"4.0.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.4.0.3.zip";s:5:"icons";a:3:{s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:7:"default";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";}s:7:"banners";a:2:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";s:7:"default";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.4";s:13:"compatibility";O:8:"stdClass":0:{}}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":11:{s:2:"id";s:29:"w.org/plugins/backupwordpress";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.6.4";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.6.4.zip";s:5:"icons";a:3:{s:2:"1x";s:68:"https://ps.w.org/backupwordpress/assets/icon-128x128.png?rev=1105225";s:2:"2x";s:68:"https://ps.w.org/backupwordpress/assets/icon-256x256.jpg?rev=1105225";s:7:"default";s:68:"https://ps.w.org/backupwordpress/assets/icon-256x256.jpg?rev=1105225";}s:7:"banners";a:3:{s:2:"2x";s:70:"https://ps.w.org/backupwordpress/assets/banner-1544x500.jpg?rev=904756";s:2:"1x";s:69:"https://ps.w.org/backupwordpress/assets/banner-772x250.jpg?rev=904756";s:7:"default";s:70:"https://ps.w.org/backupwordpress/assets/banner-1544x500.jpg?rev=904756";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.2";s:13:"compatibility";O:8:"stdClass":0:{}}s:23:"debug-bar/debug-bar.php";O:8:"stdClass":12:{s:2:"id";s:23:"w.org/plugins/debug-bar";s:4:"slug";s:9:"debug-bar";s:6:"plugin";s:23:"debug-bar/debug-bar.php";s:11:"new_version";s:3:"0.9";s:3:"url";s:40:"https://wordpress.org/plugins/debug-bar/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/debug-bar.0.9.zip";s:5:"icons";a:0:{}s:7:"banners";a:3:{s:2:"2x";s:65:"https://ps.w.org/debug-bar/assets/banner-1544x500.png?rev=1365496";s:2:"1x";s:64:"https://ps.w.org/debug-bar/assets/banner-772x250.png?rev=1365496";s:7:"default";s:65:"https://ps.w.org/debug-bar/assets/banner-1544x500.png?rev=1365496";}s:11:"banners_rtl";a:0:{}s:14:"upgrade_notice";s:88:"<p>Added panel navigation to toolbar.
Improved localization support.
Security fixes.</p>";s:6:"tested";s:5:"4.8.5";s:13:"compatibility";O:8:"stdClass":0:{}}s:23:"developer/developer.php";O:8:"stdClass":11:{s:2:"id";s:23:"w.org/plugins/developer";s:4:"slug";s:9:"developer";s:6:"plugin";s:23:"developer/developer.php";s:11:"new_version";s:5:"1.2.6";s:3:"url";s:40:"https://wordpress.org/plugins/developer/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/developer.1.2.6.zip";s:5:"icons";a:0:{}s:7:"banners";a:3:{s:2:"2x";s:64:"https://ps.w.org/developer/assets/banner-1544x500.png?rev=596086";s:2:"1x";s:63:"https://ps.w.org/developer/assets/banner-772x250.png?rev=596086";s:7:"default";s:64:"https://ps.w.org/developer/assets/banner-1544x500.png?rev=596086";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:6:"4.5.12";s:13:"compatibility";O:8:"stdClass":0:{}}s:19:"jetpack/jetpack.php";O:8:"stdClass":11:{s:2:"id";s:21:"w.org/plugins/jetpack";s:4:"slug";s:7:"jetpack";s:6:"plugin";s:19:"jetpack/jetpack.php";s:11:"new_version";s:3:"5.9";s:3:"url";s:38:"https://wordpress.org/plugins/jetpack/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/jetpack.5.9.zip";s:5:"icons";a:4:{s:2:"1x";s:60:"https://ps.w.org/jetpack/assets/icon-128x128.png?rev=1791404";s:2:"2x";s:60:"https://ps.w.org/jetpack/assets/icon-256x256.png?rev=1791404";s:3:"svg";s:52:"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404";s:7:"default";s:52:"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404";}s:7:"banners";a:3:{s:2:"2x";s:63:"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404";s:2:"1x";s:62:"https://ps.w.org/jetpack/assets/banner-772x250.png?rev=1791404";s:7:"default";s:63:"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.4";s:13:"compatibility";O:8:"stdClass":0:{}}s:49:"log-deprecated-notices/log-deprecated-notices.php";O:8:"stdClass":12:{s:2:"id";s:36:"w.org/plugins/log-deprecated-notices";s:4:"slug";s:22:"log-deprecated-notices";s:6:"plugin";s:49:"log-deprecated-notices/log-deprecated-notices.php";s:11:"new_version";s:3:"0.4";s:3:"url";s:53:"https://wordpress.org/plugins/log-deprecated-notices/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/log-deprecated-notices.0.4.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}s:14:"upgrade_notice";s:39:"<p>Eliminate Deprecated Constructor</p>";s:6:"tested";s:9:"5.0-alpha";s:13:"compatibility";O:8:"stdClass":0:{}}s:27:"theme-check/theme-check.php";O:8:"stdClass":11:{s:2:"id";s:25:"w.org/plugins/theme-check";s:4:"slug";s:11:"theme-check";s:6:"plugin";s:27:"theme-check/theme-check.php";s:11:"new_version";s:10:"20160523.1";s:3:"url";s:42:"https://wordpress.org/plugins/theme-check/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/theme-check.20160523.1.zip";s:5:"icons";a:2:{s:2:"1x";s:63:"https://ps.w.org/theme-check/assets/icon-128x128.png?rev=972579";s:7:"default";s:63:"https://ps.w.org/theme-check/assets/icon-128x128.png?rev=972579";}s:7:"banners";a:3:{s:2:"2x";s:66:"https://ps.w.org/theme-check/assets/banner-1544x500.png?rev=904294";s:2:"1x";s:65:"https://ps.w.org/theme-check/assets/banner-772x250.png?rev=904294";s:7:"default";s:66:"https://ps.w.org/theme-check/assets/banner-1544x500.png?rev=904294";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:6:"4.5.12";s:13:"compatibility";O:8:"stdClass":0:{}}s:41:"wordpress-importer/wordpress-importer.php";O:8:"stdClass":11:{s:2:"id";s:32:"w.org/plugins/wordpress-importer";s:4:"slug";s:18:"wordpress-importer";s:6:"plugin";s:41:"wordpress-importer/wordpress-importer.php";s:11:"new_version";s:5:"0.6.4";s:3:"url";s:49:"https://wordpress.org/plugins/wordpress-importer/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.4.zip";s:5:"icons";a:0:{}s:7:"banners";a:2:{s:2:"1x";s:72:"https://ps.w.org/wordpress-importer/assets/banner-772x250.png?rev=547654";s:7:"default";s:72:"https://ps.w.org/wordpress-importer/assets/banner-772x250.png?rev=547654";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.4";s:13:"compatibility";O:8:"stdClass":0:{}}s:35:"wordpress-reset/wordpress-reset.php";O:8:"stdClass":11:{s:2:"id";s:29:"w.org/plugins/wordpress-reset";s:4:"slug";s:15:"wordpress-reset";s:6:"plugin";s:35:"wordpress-reset/wordpress-reset.php";s:11:"new_version";s:3:"1.4";s:3:"url";s:46:"https://wordpress.org/plugins/wordpress-reset/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-reset.1.4.zip";s:5:"icons";a:2:{s:3:"svg";s:60:"https://ps.w.org/wordpress-reset/assets/icon.svg?rev=1330992";s:7:"default";s:60:"https://ps.w.org/wordpress-reset/assets/icon.svg?rev=1330992";}s:7:"banners";a:3:{s:2:"2x";s:71:"https://ps.w.org/wordpress-reset/assets/banner-1544x500.png?rev=1330994";s:2:"1x";s:70:"https://ps.w.org/wordpress-reset/assets/banner-772x250.png?rev=1330994";s:7:"default";s:71:"https://ps.w.org/wordpress-reset/assets/banner-1544x500.png?rev=1330994";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:6:"4.5.12";s:13:"compatibility";O:8:"stdClass":0:{}}s:28:"wp-example-content/magic.php";O:8:"stdClass":11:{s:2:"id";s:32:"w.org/plugins/wp-example-content";s:4:"slug";s:18:"wp-example-content";s:6:"plugin";s:28:"wp-example-content/magic.php";s:11:"new_version";s:3:"1.3";s:3:"url";s:49:"https://wordpress.org/plugins/wp-example-content/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/wp-example-content.1.3.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}s:6:"tested";s:6:"4.1.21";s:13:"compatibility";O:8:"stdClass":0:{}}s:31:"wp-migrate-db/wp-migrate-db.php";O:8:"stdClass":11:{s:2:"id";s:27:"w.org/plugins/wp-migrate-db";s:4:"slug";s:13:"wp-migrate-db";s:6:"plugin";s:31:"wp-migrate-db/wp-migrate-db.php";s:11:"new_version";s:5:"1.0.2";s:3:"url";s:44:"https://wordpress.org/plugins/wp-migrate-db/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wp-migrate-db.1.0.2.zip";s:5:"icons";a:3:{s:2:"1x";s:66:"https://ps.w.org/wp-migrate-db/assets/icon-128x128.jpg?rev=1809889";s:2:"2x";s:66:"https://ps.w.org/wp-migrate-db/assets/icon-256x256.jpg?rev=1809889";s:7:"default";s:66:"https://ps.w.org/wp-migrate-db/assets/icon-256x256.jpg?rev=1809889";}s:7:"banners";a:3:{s:2:"2x";s:69:"https://ps.w.org/wp-migrate-db/assets/banner-1544x500.jpg?rev=1809889";s:2:"1x";s:68:"https://ps.w.org/wp-migrate-db/assets/banner-772x250.jpg?rev=1809889";s:7:"default";s:69:"https://ps.w.org/wp-migrate-db/assets/banner-1544x500.jpg?rev=1809889";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.2";s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:8:{s:39:"debug-bar-console/debug-bar-console.php";O:8:"stdClass":9:{s:2:"id";s:31:"w.org/plugins/debug-bar-console";s:4:"slug";s:17:"debug-bar-console";s:6:"plugin";s:39:"debug-bar-console/debug-bar-console.php";s:11:"new_version";s:3:"0.3";s:3:"url";s:48:"https://wordpress.org/plugins/debug-bar-console/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/debug-bar-console.0.3.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}}s:9:"hello.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";s:5:"icons";a:3:{s:2:"1x";s:63:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907";s:2:"2x";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";s:7:"default";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";}s:7:"banners";a:2:{s:2:"1x";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";s:7:"default";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";}s:11:"banners_rtl";a:0:{}}s:33:"monster-widget/monster-widget.php";O:8:"stdClass":9:{s:2:"id";s:28:"w.org/plugins/monster-widget";s:4:"slug";s:14:"monster-widget";s:6:"plugin";s:33:"monster-widget/monster-widget.php";s:11:"new_version";s:3:"0.3";s:3:"url";s:45:"https://wordpress.org/plugins/monster-widget/";s:7:"package";s:57:"https://downloads.wordpress.org/plugin/monster-widget.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}}s:35:"simply-show-ids/simply-show-ids.php";O:8:"stdClass":9:{s:2:"id";s:29:"w.org/plugins/simply-show-ids";s:4:"slug";s:15:"simply-show-ids";s:6:"plugin";s:35:"simply-show-ids/simply-show-ids.php";s:11:"new_version";s:5:"1.3.3";s:3:"url";s:46:"https://wordpress.org/plugins/simply-show-ids/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/simply-show-ids.1.3.3.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}}s:27:"woocommerce/woocommerce.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/woocommerce";s:4:"slug";s:11:"woocommerce";s:6:"plugin";s:27:"woocommerce/woocommerce.php";s:11:"new_version";s:5:"3.3.4";s:3:"url";s:42:"https://wordpress.org/plugins/woocommerce/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/woocommerce.3.3.4.zip";s:5:"icons";a:3:{s:2:"1x";s:64:"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831";s:2:"2x";s:64:"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831";s:7:"default";s:64:"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831";}s:7:"banners";a:3:{s:2:"2x";s:67:"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184";s:2:"1x";s:66:"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184";s:7:"default";s:67:"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184";}s:11:"banners_rtl";a:0:{}}s:91:"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php";O:8:"stdClass":9:{s:2:"id";s:57:"w.org/plugins/woocommerce-gateway-paypal-express-checkout";s:4:"slug";s:43:"woocommerce-gateway-paypal-express-checkout";s:6:"plugin";s:91:"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php";s:11:"new_version";s:5:"1.5.2";s:3:"url";s:74:"https://wordpress.org/plugins/woocommerce-gateway-paypal-express-checkout/";s:7:"package";s:92:"https://downloads.wordpress.org/plugin/woocommerce-gateway-paypal-express-checkout.1.5.2.zip";s:5:"icons";a:3:{s:2:"1x";s:96:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-128x128.png?rev=1410389";s:2:"2x";s:96:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-256x256.png?rev=1410389";s:7:"default";s:96:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-256x256.png?rev=1410389";}s:7:"banners";a:3:{s:2:"2x";s:99:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-1544x500.png?rev=1410389";s:2:"1x";s:98:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-772x250.png?rev=1410389";s:7:"default";s:99:"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-1544x500.png?rev=1410389";}s:11:"banners_rtl";a:0:{}}s:57:"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php";O:8:"stdClass":9:{s:2:"id";s:40:"w.org/plugins/woocommerce-gateway-stripe";s:4:"slug";s:26:"woocommerce-gateway-stripe";s:6:"plugin";s:57:"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php";s:11:"new_version";s:5:"4.0.7";s:3:"url";s:57:"https://wordpress.org/plugins/woocommerce-gateway-stripe/";s:7:"package";s:75:"https://downloads.wordpress.org/plugin/woocommerce-gateway-stripe.4.0.7.zip";s:5:"icons";a:3:{s:2:"1x";s:79:"https://ps.w.org/woocommerce-gateway-stripe/assets/icon-128x128.png?rev=1799707";s:2:"2x";s:79:"https://ps.w.org/woocommerce-gateway-stripe/assets/icon-256x256.png?rev=1799707";s:7:"default";s:79:"https://ps.w.org/woocommerce-gateway-stripe/assets/icon-256x256.png?rev=1799707";}s:7:"banners";a:3:{s:2:"2x";s:82:"https://ps.w.org/woocommerce-gateway-stripe/assets/banner-1544x500.png?rev=1799707";s:2:"1x";s:81:"https://ps.w.org/woocommerce-gateway-stripe/assets/banner-772x250.png?rev=1799707";s:7:"default";s:82:"https://ps.w.org/woocommerce-gateway-stripe/assets/banner-1544x500.png?rev=1799707";}s:11:"banners_rtl";a:0:{}}s:43:"wp-native-dashboard/wp-native-dashboard.php";O:8:"stdClass":9:{s:2:"id";s:33:"w.org/plugins/wp-native-dashboard";s:4:"slug";s:19:"wp-native-dashboard";s:6:"plugin";s:43:"wp-native-dashboard/wp-native-dashboard.php";s:11:"new_version";s:6:"1.3.12";s:3:"url";s:50:"https://wordpress.org/plugins/wp-native-dashboard/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/wp-native-dashboard.1.3.12.zip";s:5:"icons";a:0:{}s:7:"banners";a:2:{s:2:"1x";s:73:"https://ps.w.org/wp-native-dashboard/assets/banner-772x250.png?rev=547483";s:7:"default";s:73:"https://ps.w.org/wp-native-dashboard/assets/banner-772x250.png?rev=547483";}s:11:"banners_rtl";a:0:{}}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2684, 'storefront_nux_dismissed', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2857, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1522079489', 'no') ; 
INSERT INTO `wp_options` VALUES (2858, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1522036289', 'no') ; 
INSERT INTO `wp_options` VALUES (2859, '_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b', '1522079489', 'no') ; 
INSERT INTO `wp_options` VALUES (2860, '_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/03/the-month-in-wordpress-february-2018/\'>The Month in WordPress: February 2018</a></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://buddypress.org/2018/03/10-years/\'>BuddyPress: 10 years</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\'>WPTavern: Noteworthy Changes Coming in WordPress 4.9.5</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wpweekly-episode-309-all-amped-up\'>WPTavern: WPWeekly Episode 309 – All AMPed Up</a></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (3057, 'woocommerce_tracker_ua', 'a:1:{i:0;s:115:"mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/65.0.3325.181 safari/537.36";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3116, '_transient_timeout_wc_term_counts', '1524647244', 'no') ; 
INSERT INTO `wp_options` VALUES (3117, '_transient_wc_term_counts', 'a:6:{i:240;s:1:"4";i:242;s:1:"7";i:243;s:1:"2";i:236;s:1:"1";i:239;s:1:"6";i:235;s:1:"5";}', 'no') ; 
INSERT INTO `wp_options` VALUES (3118, '_transient_timeout_wc_product_loope30d1522055192', '1524647195', 'no') ; 
INSERT INTO `wp_options` VALUES (3119, '_transient_wc_product_loope30d1522055192', 'O:8:"stdClass":5:{s:3:"ids";a:4:{i:0;i:1842;i:1;i:1841;i:2;i:1839;i:3;i:1838;}s:5:"total";i:4;s:11:"total_pages";i:1;s:8:"per_page";i:-1;s:12:"current_page";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (3120, '_transient_timeout_wc_product_loop89141522055192', '1524647195', 'no') ; 
INSERT INTO `wp_options` VALUES (3121, '_transient_wc_product_loop89141522055192', 'O:8:"stdClass":5:{s:3:"ids";a:7:{i:0;i:1858;i:1;i:1856;i:2;i:1855;i:3;i:1854;i:4;i:1853;i:5;i:1852;i:6;i:1850;}s:5:"total";i:7;s:11:"total_pages";i:1;s:8:"per_page";i:-1;s:12:"current_page";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (3122, 'mazpage_theme_options', 'a:1:{s:9:"site_logo";s:67:"http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/logo.png";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3123, '_transient_doing_cron', '1522137041.8196940422058105468750', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=2544 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (2211 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2306, 1850, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2305, 1850, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2304, 1850, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2303, 1850, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2302, 1850, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2301, 1850, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2300, 1850, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (298, 55, '_edit_lock', '1395151181:1') ; 
INSERT INTO `wp_postmeta` VALUES (2299, 1850, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2298, 1850, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2297, 1850, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2296, 1850, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2295, 1850, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2294, 1850, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2293, 1850, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (299, 121, '_wp_attached_file', '2008/09/acanthamoeba.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (2292, 1850, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2291, 1850, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2290, 1850, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2289, 1850, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2288, 1850, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2287, 1850, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2286, 1850, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (295, 53, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2285, 1850, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2284, 1850, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2283, 1850, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2282, 1849, '_edit_lock', '1522052220:1') ; 
INSERT INTO `wp_postmeta` VALUES (2281, 1849, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2280, 1849, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (294, 53, '_thumbnail_id', '119') ; 
INSERT INTO `wp_postmeta` VALUES (2279, 1849, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2278, 1849, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2277, 1849, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2276, 1849, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2275, 1849, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2274, 1849, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (293, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:17:"2008/09/Koala.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:17:"Koala-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:17:"Koala-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:17:"Koala-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:17:"Koala-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"Koala-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (292, 119, '_wp_attached_file', '2008/09/Koala.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (291, 53, '_edit_lock', '1395152117:1') ; 
INSERT INTO `wp_postmeta` VALUES (290, 24, '_wp_page_template', 'page-full-width.php') ; 
INSERT INTO `wp_postmeta` VALUES (2273, 1849, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2272, 1849, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2271, 1849, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2270, 1849, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2269, 1849, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2268, 1849, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2267, 1849, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2266, 1849, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2265, 1849, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2264, 1849, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2263, 1849, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2262, 1849, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (289, 24, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2261, 1849, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2260, 1849, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2259, 1849, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2258, 1849, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2257, 1849, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2256, 1849, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2255, 1849, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (288, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:44:"2008/09/978a9ee060efba987bd79e77e57fede1.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:44:"978a9ee060efba987bd79e77e57fede1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:44:"978a9ee060efba987bd79e77e57fede1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:44:"978a9ee060efba987bd79e77e57fede1-416x416.jpg";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:44:"978a9ee060efba987bd79e77e57fede1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:44:"978a9ee060efba987bd79e77e57fede1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (287, 117, '_wp_attached_file', '2008/09/978a9ee060efba987bd79e77e57fede1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (286, 24, '_edit_lock', '1395064962:1') ; 
INSERT INTO `wp_postmeta` VALUES (285, 96, '_edit_lock', '1394805992:1') ; 
INSERT INTO `wp_postmeta` VALUES (284, 20, '_edit_lock', '1394805891:1') ; 
INSERT INTO `wp_postmeta` VALUES (283, 2, '_edit_lock', '1396596732:1') ; 
INSERT INTO `wp_postmeta` VALUES (282, 30, '_edit_lock', '1394805864:1') ; 
INSERT INTO `wp_postmeta` VALUES (281, 15, '_edit_lock', '1394805852:1') ; 
INSERT INTO `wp_postmeta` VALUES (280, 13, '_edit_lock', '1394805840:1') ; 
INSERT INTO `wp_postmeta` VALUES (279, 18, '_edit_lock', '1394805826:1') ; 
INSERT INTO `wp_postmeta` VALUES (278, 94, '_edit_lock', '1396596714:1') ; 
INSERT INTO `wp_postmeta` VALUES (277, 98, '_edit_lock', '1394805803:1') ; 
INSERT INTO `wp_postmeta` VALUES (276, 22, '_edit_lock', '1394805788:1') ; 
INSERT INTO `wp_postmeta` VALUES (275, 101, '_edit_lock', '1396343708:1') ; 
INSERT INTO `wp_postmeta` VALUES (271, 28, '_edit_lock', '1394805651:1') ; 
INSERT INTO `wp_postmeta` VALUES (269, 112, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (268, 112, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (267, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (266, 112, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (265, 112, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (264, 112, '_menu_item_object_id', '101') ; 
INSERT INTO `wp_postmeta` VALUES (272, 99, '_edit_lock', '1394805710:1') ; 
INSERT INTO `wp_postmeta` VALUES (263, 112, '_menu_item_menu_item_parent', '111') ; 
INSERT INTO `wp_postmeta` VALUES (262, 112, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (273, 95, '_edit_lock', '1396443283:1') ; 
INSERT INTO `wp_postmeta` VALUES (260, 111, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (259, 111, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (258, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (257, 111, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (256, 111, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (255, 111, '_menu_item_object_id', '100') ; 
INSERT INTO `wp_postmeta` VALUES (254, 111, '_menu_item_menu_item_parent', '110') ; 
INSERT INTO `wp_postmeta` VALUES (253, 111, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (274, 100, '_edit_lock', '1394805764:1') ; 
INSERT INTO `wp_postmeta` VALUES (251, 110, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (250, 110, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (249, 110, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (248, 110, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (247, 110, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (246, 110, '_menu_item_object_id', '95') ; 
INSERT INTO `wp_postmeta` VALUES (245, 110, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (244, 110, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (2254, 1849, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2253, 1849, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2252, 1849, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2251, 1849, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2250, 1849, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2249, 1849, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2248, 1849, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (234, 97, '_edit_lock', '1392128796:1') ; 
INSERT INTO `wp_postmeta` VALUES (233, 26, '_edit_lock', '1396440469:1') ; 
INSERT INTO `wp_postmeta` VALUES (232, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:277;s:6:"height";i:182;s:4:"file";s:25:"2014/02/another-image.jpg";s:5:"sizes";a:2:{s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"another-image-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"another-image-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (231, 106, '_wp_attached_file', '2014/02/another-image.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (229, 102, '_edit_lock', '1396440457:1') ; 
INSERT INTO `wp_postmeta` VALUES (230, 93, '_edit_lock', '1403775975:1') ; 
INSERT INTO `wp_postmeta` VALUES (228, 102, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (300, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:24:"2008/09/acanthamoeba.jpg";s:5:"sizes";a:2:{s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:24:"acanthamoeba-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"acanthamoeba-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (301, 55, '_thumbnail_id', '121') ; 
INSERT INTO `wp_postmeta` VALUES (302, 55, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (305, 88, '_edit_lock', '1400059450:1') ; 
INSERT INTO `wp_postmeta` VALUES (306, 123, '_wp_attached_file', '2014/02/4508_1052588806268_1572224486_30132277_7137063_n.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (307, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:380;s:4:"file";s:60:"2014/02/4508_1052588806268_1572224486_30132277_7137063_n.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:60:"4508_1052588806268_1572224486_30132277_7137063_n-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:60:"4508_1052588806268_1572224486_30132277_7137063_n-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:60:"4508_1052588806268_1572224486_30132277_7137063_n-416x351.jpg";s:5:"width";i:416;s:6:"height";i:351;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:60:"4508_1052588806268_1572224486_30132277_7137063_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:60:"4508_1052588806268_1572224486_30132277_7137063_n-300x253.jpg";s:5:"width";i:300;s:6:"height";i:253;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (308, 88, '_thumbnail_id', '123') ; 
INSERT INTO `wp_postmeta` VALUES (309, 88, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (312, 90, '_edit_lock', '1403778269:1') ; 
INSERT INTO `wp_postmeta` VALUES (313, 125, '_wp_attached_file', '2014/02/220px-Pepper-heart.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (314, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:220;s:6:"height";i:165;s:4:"file";s:30:"2014/02/220px-Pepper-heart.jpg";s:5:"sizes";a:2:{s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:30:"220px-Pepper-heart-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"220px-Pepper-heart-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (315, 90, '_thumbnail_id', '125') ; 
INSERT INTO `wp_postmeta` VALUES (316, 90, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (319, 91, '_edit_lock', '1400141336:1') ; 
INSERT INTO `wp_postmeta` VALUES (320, 127, '_wp_attached_file', '2014/02/IMG_2579.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (321, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:480;s:4:"file";s:20:"2014/02/IMG_2579.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"IMG_2579-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"IMG_2579-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"IMG_2579-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"IMG_2579-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"IMG_2579-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (322, 91, '_thumbnail_id', '127') ; 
INSERT INTO `wp_postmeta` VALUES (323, 91, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (326, 92, '_edit_lock', '1403775996:1') ; 
INSERT INTO `wp_postmeta` VALUES (327, 89, '_edit_lock', '1400060100:1') ; 
INSERT INTO `wp_postmeta` VALUES (330, 1, '_edit_lock', '1395152174:1') ; 
INSERT INTO `wp_postmeta` VALUES (331, 130, '_wp_attached_file', '2012/10/4548422124_32bb76e36b.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (332, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:333;s:4:"file";s:33:"2012/10/4548422124_32bb76e36b.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:33:"4548422124_32bb76e36b-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:33:"4548422124_32bb76e36b-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:33:"4548422124_32bb76e36b-416x277.jpg";s:5:"width";i:416;s:6:"height";i:277;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:33:"4548422124_32bb76e36b-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"4548422124_32bb76e36b-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (333, 1, '_thumbnail_id', '130') ; 
INSERT INTO `wp_postmeta` VALUES (334, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1134, 1700, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1135, 1700, '_menu_item_object_id', '102') ; 
INSERT INTO `wp_postmeta` VALUES (1133, 1700, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (343, 135, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (344, 146, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (345, 155, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (346, 156, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (347, 172, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (348, 173, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (349, 174, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (350, 501, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (351, 611, '_wp_attached_file', '2011/01/canola2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (352, 611, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:19:"2011/01/canola2.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"canola2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"canola2-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"canola2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"canola2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"canola2-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (353, 611, '_wp_attachment_image_alt', 'canola') ; 
INSERT INTO `wp_postmeta` VALUES (354, 611, '_wp_attachment_image_alt', 'canola') ; 
INSERT INTO `wp_postmeta` VALUES (355, 611, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (356, 616, '_wp_attached_file', '2011/01/dsc20050727_091048_222.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (357, 616, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:34:"2011/01/dsc20050727_091048_222.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:34:"dsc20050727_091048_222-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:34:"dsc20050727_091048_222-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:34:"dsc20050727_091048_222-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:34:"dsc20050727_091048_222-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"dsc20050727_091048_222-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (358, 616, '_wp_attachment_image_alt', 'dsc20050727_091048_222') ; 
INSERT INTO `wp_postmeta` VALUES (359, 616, '_wp_attachment_image_alt', 'dsc20050727_091048_222') ; 
INSERT INTO `wp_postmeta` VALUES (360, 616, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (361, 617, '_wp_attached_file', '2011/01/dsc20050813_115856_52.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (362, 617, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:33:"2011/01/dsc20050813_115856_52.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:33:"dsc20050813_115856_52-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:33:"dsc20050813_115856_52-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:33:"dsc20050813_115856_52-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:33:"dsc20050813_115856_52-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"dsc20050813_115856_52-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (363, 617, '_wp_attachment_image_alt', 'dsc20050813_115856_52') ; 
INSERT INTO `wp_postmeta` VALUES (364, 617, '_wp_attachment_image_alt', 'dsc20050813_115856_52') ; 
INSERT INTO `wp_postmeta` VALUES (365, 617, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (366, 701, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (367, 703, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (368, 733, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (369, 754, '_wp_attached_file', '2011/07/100_5478.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (370, 754, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/100_5478.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"100_5478-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"100_5478-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"100_5478-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"100_5478-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"100_5478-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"100_5478-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (371, 754, '_wp_attachment_image_alt', 'Bell on Wharf') ; 
INSERT INTO `wp_postmeta` VALUES (372, 754, '_wp_attachment_image_alt', 'Bell on Wharf') ; 
INSERT INTO `wp_postmeta` VALUES (373, 754, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (374, 755, '_wp_attached_file', '2011/07/100_5540.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (375, 755, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/100_5540.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"100_5540-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"100_5540-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"100_5540-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"100_5540-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"100_5540-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"100_5540-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (376, 755, '_wp_attachment_image_alt', 'Golden Gate Bridge') ; 
INSERT INTO `wp_postmeta` VALUES (377, 755, '_wp_attachment_image_alt', 'Golden Gate Bridge') ; 
INSERT INTO `wp_postmeta` VALUES (378, 755, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (379, 756, '_wp_attached_file', '2011/07/cep00032.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (380, 756, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/cep00032.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"cep00032-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"cep00032-600x480.jpg";s:5:"width";i:600;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"cep00032-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"cep00032-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"cep00032-300x240.jpg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"cep00032-1024x819.jpg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (381, 756, '_wp_attachment_image_alt', 'Sunburst Over River') ; 
INSERT INTO `wp_postmeta` VALUES (382, 756, '_wp_attachment_image_alt', 'Sunburst Over River') ; 
INSERT INTO `wp_postmeta` VALUES (383, 756, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (384, 757, '_wp_attached_file', '2011/07/dcp_2082.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (385, 757, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:20:"2011/07/dcp_2082.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dcp_2082-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dcp_2082-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dcp_2082-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dcp_2082-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dcp_2082-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dcp_2082-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (386, 757, '_wp_attachment_image_alt', 'Boardwalk') ; 
INSERT INTO `wp_postmeta` VALUES (387, 757, '_wp_attachment_image_alt', 'Boardwalk') ; 
INSERT INTO `wp_postmeta` VALUES (388, 757, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (389, 758, '_wp_attached_file', '2011/07/dsc03149.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (390, 758, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1280;s:6:"height";i:960;s:4:"file";s:20:"2011/07/dsc03149.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dsc03149-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dsc03149-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dsc03149-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dsc03149-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dsc03149-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dsc03149-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (391, 758, '_wp_attachment_image_alt', 'Yachtsody in Blue') ; 
INSERT INTO `wp_postmeta` VALUES (392, 758, '_wp_attachment_image_alt', 'Yachtsody in Blue') ; 
INSERT INTO `wp_postmeta` VALUES (393, 758, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (394, 759, '_wp_attached_file', '2011/07/dsc04563.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (395, 759, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/dsc04563.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dsc04563-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dsc04563-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dsc04563-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dsc04563-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dsc04563-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dsc04563-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (396, 759, '_wp_attachment_image_alt', 'Rain Ripples') ; 
INSERT INTO `wp_postmeta` VALUES (397, 759, '_wp_attachment_image_alt', 'Rain Ripples') ; 
INSERT INTO `wp_postmeta` VALUES (398, 759, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (399, 760, '_wp_attached_file', '2011/07/dsc09114.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (400, 760, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/dsc09114.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dsc09114-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dsc09114-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dsc09114-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dsc09114-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dsc09114-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dsc09114-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (401, 760, '_wp_attachment_image_alt', 'Sydney Harbor Bridge') ; 
INSERT INTO `wp_postmeta` VALUES (402, 760, '_wp_attachment_image_alt', 'Sydney Harbor Bridge') ; 
INSERT INTO `wp_postmeta` VALUES (403, 760, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (404, 761, '_wp_attached_file', '2011/07/dsc20050102_192118_51.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (405, 761, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:33:"2011/07/dsc20050102_192118_51.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:33:"dsc20050102_192118_51-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:33:"dsc20050102_192118_51-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:33:"dsc20050102_192118_51-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:33:"dsc20050102_192118_51-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"dsc20050102_192118_51-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"dsc20050102_192118_51-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (406, 761, '_wp_attachment_image_alt', 'Wind Farm') ; 
INSERT INTO `wp_postmeta` VALUES (407, 761, '_wp_attachment_image_alt', 'Wind Farm') ; 
INSERT INTO `wp_postmeta` VALUES (408, 761, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (409, 762, '_wp_attached_file', '2011/07/dsc20051220_160808_102.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (410, 762, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:34:"2011/07/dsc20051220_160808_102.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:34:"dsc20051220_160808_102-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:34:"dsc20051220_160808_102-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:34:"dsc20051220_160808_102-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:34:"dsc20051220_160808_102-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"dsc20051220_160808_102-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:35:"dsc20051220_160808_102-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (411, 762, '_wp_attachment_image_alt', 'Antique Farm Machinery') ; 
INSERT INTO `wp_postmeta` VALUES (412, 762, '_wp_attachment_image_alt', 'Antique Farm Machinery') ; 
INSERT INTO `wp_postmeta` VALUES (413, 762, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (414, 763, '_wp_attached_file', '2011/07/dsc02085.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (415, 763, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/dsc02085.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dsc02085-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dsc02085-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dsc02085-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dsc02085-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dsc02085-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dsc02085-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (416, 763, '_wp_attachment_image_alt', 'Orange Iris') ; 
INSERT INTO `wp_postmeta` VALUES (417, 763, '_wp_attachment_image_alt', 'Orange Iris') ; 
INSERT INTO `wp_postmeta` VALUES (418, 763, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (419, 764, '_wp_attached_file', '2011/07/dsc20051220_173257_119.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (420, 764, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:34:"2011/07/dsc20051220_173257_119.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:34:"dsc20051220_173257_119-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:34:"dsc20051220_173257_119-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:34:"dsc20051220_173257_119-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:34:"dsc20051220_173257_119-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"dsc20051220_173257_119-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:35:"dsc20051220_173257_119-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (421, 764, '_wp_attachment_image_alt', 'Rusty Rail') ; 
INSERT INTO `wp_postmeta` VALUES (422, 764, '_wp_attachment_image_alt', 'Rusty Rail') ; 
INSERT INTO `wp_postmeta` VALUES (423, 764, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (424, 765, '_wp_attached_file', '2011/07/dscn3316.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (425, 765, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/dscn3316.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"dscn3316-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"dscn3316-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"dscn3316-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"dscn3316-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"dscn3316-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"dscn3316-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (426, 765, '_wp_attachment_image_alt', 'Sea and Rocks') ; 
INSERT INTO `wp_postmeta` VALUES (427, 765, '_wp_attachment_image_alt', 'Sea and Rocks') ; 
INSERT INTO `wp_postmeta` VALUES (428, 765, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (429, 766, '_wp_attached_file', '2011/07/michelle_049.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (430, 766, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:24:"2011/07/michelle_049.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:24:"michelle_049-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:24:"michelle_049-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:24:"michelle_049-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"michelle_049-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"michelle_049-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"michelle_049-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (431, 766, '_wp_attachment_image_alt', 'Big Sur') ; 
INSERT INTO `wp_postmeta` VALUES (432, 766, '_wp_attachment_image_alt', 'Big Sur') ; 
INSERT INTO `wp_postmeta` VALUES (433, 766, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (434, 767, '_wp_attached_file', '2011/07/windmill.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (435, 767, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:20:"2011/07/windmill.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"windmill-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"windmill-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"windmill-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"windmill-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"windmill-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"windmill-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (436, 767, '_wp_attachment_image_alt', 'Windmill') ; 
INSERT INTO `wp_postmeta` VALUES (437, 767, '_wp_attachment_image_alt', 'Windmill') ; 
INSERT INTO `wp_postmeta` VALUES (438, 767, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (439, 768, '_wp_attached_file', '2011/07/img_0513-1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (440, 768, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:533;s:4:"file";s:22:"2011/07/img_0513-1.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:22:"img_0513-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:22:"img_0513-1-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:22:"img_0513-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"img_0513-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"img_0513-1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:10:"Picasa 2.0";s:6:"camera";s:0:"";s:7:"caption";s:32:"Alas! I have found my Shangri-La";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:32:"Alas! I have found my Shangri-La";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (441, 768, '_wp_attachment_image_alt', 'Huatulco Coastline') ; 
INSERT INTO `wp_postmeta` VALUES (442, 768, '_wp_attachment_image_alt', 'Huatulco Coastline') ; 
INSERT INTO `wp_postmeta` VALUES (443, 768, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (444, 769, '_wp_attached_file', '2011/07/img_0747.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (445, 769, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:20:"2011/07/img_0747.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"img_0747-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"img_0747-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"img_0747-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"img_0747-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"img_0747-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"img_0747-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (446, 769, '_wp_attachment_image_alt', 'Brazil Beach') ; 
INSERT INTO `wp_postmeta` VALUES (447, 769, '_wp_attachment_image_alt', 'Brazil Beach') ; 
INSERT INTO `wp_postmeta` VALUES (448, 769, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (449, 770, '_wp_attached_file', '2011/07/img_0767.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (450, 770, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:533;s:4:"file";s:20:"2011/07/img_0767.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"img_0767-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"img_0767-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"img_0767-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"img_0767-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"img_0767-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:10:"Picasa 2.6";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (451, 770, '_wp_attachment_image_alt', 'Huatulco Coastline') ; 
INSERT INTO `wp_postmeta` VALUES (452, 770, '_wp_attachment_image_alt', 'Huatulco Coastline') ; 
INSERT INTO `wp_postmeta` VALUES (453, 770, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (454, 771, '_wp_attached_file', '2011/07/img_8399.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (455, 771, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:20:"2011/07/img_8399.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:20:"img_8399-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:20:"img_8399-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:20:"img_8399-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"img_8399-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"img_8399-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"img_8399-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (456, 771, '_wp_attachment_image_alt', 'Boat Barco Texture') ; 
INSERT INTO `wp_postmeta` VALUES (457, 771, '_wp_attachment_image_alt', 'Boat Barco Texture') ; 
INSERT INTO `wp_postmeta` VALUES (458, 771, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (459, 807, '_wp_attached_file', '2012/06/dsc20040724_152504_532.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (460, 807, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:34:"2012/06/dsc20040724_152504_532.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:34:"dsc20040724_152504_532-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (461, 807, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (462, 811, '_wp_attached_file', '2012/06/dsc20050604_133440_34211.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (463, 811, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:36:"2012/06/dsc20050604_133440_34211.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:36:"dsc20050604_133440_34211-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (464, 811, '_attachment_original_parent_id', '555') ; 
INSERT INTO `wp_postmeta` VALUES (465, 821, '_wp_attached_file', '2012/07/originaldixielandjazzbandwithalbernard-stlouisblues.mp3') ; 
INSERT INTO `wp_postmeta` VALUES (466, 821, '_wp_attachment_metadata', 'a:20:{s:10:"dataformat";s:3:"mp3";s:8:"channels";i:2;s:11:"sample_rate";i:44100;s:7:"bitrate";i:128000;s:11:"channelmode";s:12:"joint stereo";s:12:"bitrate_mode";s:3:"cbr";s:8:"lossless";b:0;s:15:"encoder_options";s:6:"CBR128";s:17:"compression_ratio";d:0.0907029478458049875921886950891348533332347869873046875;s:10:"fileformat";s:3:"mp3";s:8:"filesize";i:3043247;s:9:"mime_type";s:10:"audio/mpeg";s:6:"length";s:6:"190000";s:16:"length_formatted";s:4:"3:10";s:7:"comment";s:4:"None";s:4:"year";s:4:"1921";s:5:"title";s:22:"St. Louis Blues (1921)";s:6:"artist";s:44:"Original Dixieland Jazz Band with Al Bernard";s:5:"genre";s:12:"Acoustic Era";s:5:"album";s:12:"Victor-18772";}') ; 
INSERT INTO `wp_postmeta` VALUES (467, 827, '_wp_attached_file', '2012/07/manhattansummer.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (468, 827, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:27:"2012/07/manhattansummer.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"manhattansummer-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"manhattansummer-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"manhattansummer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"manhattansummer-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"manhattansummer-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (469, 967, '_wp_attached_file', '2013/03/image-alignment-580x300.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (470, 967, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:580;s:6:"height";i:300;s:4:"file";s:35:"2013/03/image-alignment-580x300.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:35:"image-alignment-580x300-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:35:"image-alignment-580x300-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:35:"image-alignment-580x300-416x215.jpg";s:5:"width";i:416;s:6:"height";i:215;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:35:"image-alignment-580x300-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"image-alignment-580x300-300x155.jpg";s:5:"width";i:300;s:6:"height";i:155;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (471, 967, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (472, 967, 'pre_import_post_id', '906') ; 
INSERT INTO `wp_postmeta` VALUES (473, 967, '_wp_attachment_image_alt', 'Image Alignment 580x300') ; 
INSERT INTO `wp_postmeta` VALUES (474, 967, '_attachment_original_parent_id', '903') ; 
INSERT INTO `wp_postmeta` VALUES (475, 968, '_wp_attached_file', '2013/03/image-alignment-150x150.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (476, 968, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:35:"2013/03/image-alignment-150x150.jpg";s:5:"sizes";a:1:{s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:35:"image-alignment-150x150-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (477, 968, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (478, 968, 'pre_import_post_id', '904') ; 
INSERT INTO `wp_postmeta` VALUES (479, 968, '_wp_attachment_image_alt', 'Image Alignment 150x150') ; 
INSERT INTO `wp_postmeta` VALUES (480, 968, '_attachment_original_parent_id', '903') ; 
INSERT INTO `wp_postmeta` VALUES (481, 1022, '_wp_attached_file', '2013/03/featured-image-horizontal.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (482, 1022, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:580;s:6:"height";i:300;s:4:"file";s:37:"2013/03/featured-image-horizontal.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:37:"featured-image-horizontal-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:37:"featured-image-horizontal-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:37:"featured-image-horizontal-416x215.jpg";s:5:"width";i:416;s:6:"height";i:215;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:37:"featured-image-horizontal-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"featured-image-horizontal-300x155.jpg";s:5:"width";i:300;s:6:"height";i:155;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (483, 1022, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (484, 1022, 'pre_import_post_id', '1022') ; 
INSERT INTO `wp_postmeta` VALUES (485, 1022, '_wp_attachment_image_alt', 'Horizontal Featured Image') ; 
INSERT INTO `wp_postmeta` VALUES (486, 1022, '_attachment_original_parent_id', '1011') ; 
INSERT INTO `wp_postmeta` VALUES (487, 1023, '_wp_attached_file', '2013/03/soworthloving-wallpaper.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (488, 1023, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1200;s:4:"file";s:35:"2013/03/soworthloving-wallpaper.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:35:"soworthloving-wallpaper-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:35:"soworthloving-wallpaper-600x375.jpg";s:5:"width";i:600;s:6:"height";i:375;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:35:"soworthloving-wallpaper-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:35:"soworthloving-wallpaper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"soworthloving-wallpaper-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:36:"soworthloving-wallpaper-1024x640.jpg";s:5:"width";i:1024;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (489, 1023, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (490, 1023, 'pre_import_post_id', '842') ; 
INSERT INTO `wp_postmeta` VALUES (491, 1023, '_wp_attachment_image_alt', 'I Am Worth Loving Wallpaper') ; 
INSERT INTO `wp_postmeta` VALUES (492, 1025, '_wp_attached_file', '2013/03/image-alignment-300x200.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (493, 1025, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:200;s:4:"file";s:35:"2013/03/image-alignment-300x200.jpg";s:5:"sizes";a:3:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:35:"image-alignment-300x200-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:35:"image-alignment-300x200-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:35:"image-alignment-300x200-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (494, 1025, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (495, 1025, 'pre_import_post_id', '905') ; 
INSERT INTO `wp_postmeta` VALUES (496, 1025, '_wp_attachment_image_alt', 'Image Alignment 300x200') ; 
INSERT INTO `wp_postmeta` VALUES (497, 1025, '_attachment_original_parent_id', '903') ; 
INSERT INTO `wp_postmeta` VALUES (498, 1027, '_wp_attached_file', '2013/03/featured-image-vertical.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (499, 1027, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:580;s:4:"file";s:35:"2013/03/featured-image-vertical.jpg";s:5:"sizes";a:4:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:35:"featured-image-vertical-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:35:"featured-image-vertical-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:35:"featured-image-vertical-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"featured-image-vertical-155x300.jpg";s:5:"width";i:155;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (500, 1027, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (501, 1027, 'pre_import_post_id', '1024') ; 
INSERT INTO `wp_postmeta` VALUES (502, 1027, '_wp_attachment_image_alt', 'Horizontal Featured Image') ; 
INSERT INTO `wp_postmeta` VALUES (503, 1027, '_attachment_original_parent_id', '1016') ; 
INSERT INTO `wp_postmeta` VALUES (504, 1029, '_wp_attached_file', '2013/03/image-alignment-1200x4002.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (505, 1029, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:400;s:4:"file";s:37:"2013/03/image-alignment-1200x4002.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:37:"image-alignment-1200x4002-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:37:"image-alignment-1200x4002-600x200.jpg";s:5:"width";i:600;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:37:"image-alignment-1200x4002-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:37:"image-alignment-1200x4002-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"image-alignment-1200x4002-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:38:"image-alignment-1200x4002-1024x341.jpg";s:5:"width";i:1024;s:6:"height";i:341;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (506, 1029, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (507, 1029, 'pre_import_post_id', '907') ; 
INSERT INTO `wp_postmeta` VALUES (508, 1029, '_wp_attachment_image_alt', 'Image Alignment 1200x4002') ; 
INSERT INTO `wp_postmeta` VALUES (509, 1029, '_attachment_original_parent_id', '903') ; 
INSERT INTO `wp_postmeta` VALUES (510, 1045, '_wp_attached_file', '2013/03/unicorn-wallpaper.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (511, 1045, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1200;s:4:"file";s:29:"2013/03/unicorn-wallpaper.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:29:"unicorn-wallpaper-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:29:"unicorn-wallpaper-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:29:"unicorn-wallpaper-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:29:"unicorn-wallpaper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"unicorn-wallpaper-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"unicorn-wallpaper-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (512, 1045, 'pre_import_post_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (513, 1045, 'pre_import_post_id', '967') ; 
INSERT INTO `wp_postmeta` VALUES (514, 1045, '_wp_attachment_image_alt', 'Unicorn Wallpaper') ; 
INSERT INTO `wp_postmeta` VALUES (515, 1045, '_attachment_original_parent_id', '568') ; 
INSERT INTO `wp_postmeta` VALUES (516, 1046, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (517, 1046, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (518, 1046, '_menu_item_object_id', '1046') ; 
INSERT INTO `wp_postmeta` VALUES (519, 1046, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (520, 1046, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (521, 1046, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (522, 1046, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (523, 1046, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (524, 1047, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (525, 1047, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (526, 1047, '_menu_item_object_id', '1047') ; 
INSERT INTO `wp_postmeta` VALUES (527, 1047, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (528, 1047, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (529, 1047, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (530, 1047, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (531, 1047, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (532, 1048, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (533, 1048, '_menu_item_menu_item_parent', '1047') ; 
INSERT INTO `wp_postmeta` VALUES (534, 1048, '_menu_item_object_id', '45') ; 
INSERT INTO `wp_postmeta` VALUES (535, 1048, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (536, 1048, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (537, 1048, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (538, 1048, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (539, 1048, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (540, 1049, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (541, 1049, '_menu_item_menu_item_parent', '1047') ; 
INSERT INTO `wp_postmeta` VALUES (542, 1049, '_menu_item_object_id', '54') ; 
INSERT INTO `wp_postmeta` VALUES (543, 1049, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (544, 1049, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (545, 1049, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (546, 1049, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (547, 1049, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (548, 1050, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (549, 1050, '_menu_item_menu_item_parent', '1047') ; 
INSERT INTO `wp_postmeta` VALUES (550, 1050, '_menu_item_object_id', '66') ; 
INSERT INTO `wp_postmeta` VALUES (551, 1050, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (552, 1050, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (553, 1050, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (554, 1050, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (555, 1050, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (556, 1051, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (557, 1051, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (558, 1051, '_menu_item_object_id', '1051') ; 
INSERT INTO `wp_postmeta` VALUES (559, 1051, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (560, 1051, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (561, 1051, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (562, 1051, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (563, 1051, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (564, 1052, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (565, 1052, '_menu_item_menu_item_parent', '1051') ; 
INSERT INTO `wp_postmeta` VALUES (566, 1052, '_menu_item_object_id', '1052') ; 
INSERT INTO `wp_postmeta` VALUES (567, 1052, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (568, 1052, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (569, 1052, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (570, 1052, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (571, 1052, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (572, 1053, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (573, 1053, '_menu_item_menu_item_parent', '1052') ; 
INSERT INTO `wp_postmeta` VALUES (574, 1053, '_menu_item_object_id', '1053') ; 
INSERT INTO `wp_postmeta` VALUES (575, 1053, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (576, 1053, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (577, 1053, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (578, 1053, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (579, 1053, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (580, 1054, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (581, 1054, '_menu_item_menu_item_parent', '1053') ; 
INSERT INTO `wp_postmeta` VALUES (582, 1054, '_menu_item_object_id', '1054') ; 
INSERT INTO `wp_postmeta` VALUES (583, 1054, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (584, 1054, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (585, 1054, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (586, 1054, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (587, 1054, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (588, 1055, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (589, 1055, '_menu_item_menu_item_parent', '1054') ; 
INSERT INTO `wp_postmeta` VALUES (590, 1055, '_menu_item_object_id', '1055') ; 
INSERT INTO `wp_postmeta` VALUES (591, 1055, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (592, 1055, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (593, 1055, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (594, 1055, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (595, 1055, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (596, 1056, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (597, 1056, '_menu_item_menu_item_parent', '1055') ; 
INSERT INTO `wp_postmeta` VALUES (598, 1056, '_menu_item_object_id', '1056') ; 
INSERT INTO `wp_postmeta` VALUES (599, 1056, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (600, 1056, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (601, 1056, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (602, 1056, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (603, 1056, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (604, 1057, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (605, 1057, '_menu_item_menu_item_parent', '1056') ; 
INSERT INTO `wp_postmeta` VALUES (606, 1057, '_menu_item_object_id', '1057') ; 
INSERT INTO `wp_postmeta` VALUES (607, 1057, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (608, 1057, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (609, 1057, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (610, 1057, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (611, 1057, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (612, 1058, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (613, 1058, '_menu_item_menu_item_parent', '1057') ; 
INSERT INTO `wp_postmeta` VALUES (614, 1058, '_menu_item_object_id', '1058') ; 
INSERT INTO `wp_postmeta` VALUES (615, 1058, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (616, 1058, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (617, 1058, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (618, 1058, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (619, 1058, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (620, 1059, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (621, 1059, '_menu_item_menu_item_parent', '1058') ; 
INSERT INTO `wp_postmeta` VALUES (622, 1059, '_menu_item_object_id', '1059') ; 
INSERT INTO `wp_postmeta` VALUES (623, 1059, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (624, 1059, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (625, 1059, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (626, 1059, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (627, 1059, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (628, 1060, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (629, 1060, '_menu_item_menu_item_parent', '1059') ; 
INSERT INTO `wp_postmeta` VALUES (630, 1060, '_menu_item_object_id', '1060') ; 
INSERT INTO `wp_postmeta` VALUES (631, 1060, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (632, 1060, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (633, 1060, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (634, 1060, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (635, 1060, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (636, 1061, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (637, 1061, '_menu_item_menu_item_parent', '1060') ; 
INSERT INTO `wp_postmeta` VALUES (638, 1061, '_menu_item_object_id', '1061') ; 
INSERT INTO `wp_postmeta` VALUES (639, 1061, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (640, 1061, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (641, 1061, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (642, 1061, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (643, 1061, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (644, 1062, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (645, 1062, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (646, 1062, '_menu_item_object_id', '1062') ; 
INSERT INTO `wp_postmeta` VALUES (647, 1062, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (648, 1062, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (649, 1062, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (650, 1062, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (651, 1062, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (652, 1063, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (653, 1063, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (654, 1063, '_menu_item_object_id', '1063') ; 
INSERT INTO `wp_postmeta` VALUES (655, 1063, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (656, 1063, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (657, 1063, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (658, 1063, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (659, 1063, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (660, 1064, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (661, 1064, '_menu_item_menu_item_parent', '1062') ; 
INSERT INTO `wp_postmeta` VALUES (662, 1064, '_menu_item_object_id', '1064') ; 
INSERT INTO `wp_postmeta` VALUES (663, 1064, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (664, 1064, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (665, 1064, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (666, 1064, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (667, 1064, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (668, 1065, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (669, 1065, '_menu_item_menu_item_parent', '1062') ; 
INSERT INTO `wp_postmeta` VALUES (670, 1065, '_menu_item_object_id', '1065') ; 
INSERT INTO `wp_postmeta` VALUES (671, 1065, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (672, 1065, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (673, 1065, '_menu_item_classes', 'a:1:{i:0;s:21:"custom-menu-css-class";}') ; 
INSERT INTO `wp_postmeta` VALUES (674, 1065, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (675, 1065, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (676, 1066, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (677, 1066, '_menu_item_menu_item_parent', '1062') ; 
INSERT INTO `wp_postmeta` VALUES (678, 1066, '_menu_item_object_id', '1066') ; 
INSERT INTO `wp_postmeta` VALUES (679, 1066, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (680, 1066, '_menu_item_target', '_blank') ; 
INSERT INTO `wp_postmeta` VALUES (681, 1066, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (682, 1066, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (683, 1066, '_menu_item_url', 'http://apple.com') ; 
INSERT INTO `wp_postmeta` VALUES (684, 1628, '_wp_attached_file', '2013/04/triforce-wallpaper.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (685, 1628, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1131;s:6:"height";i:707;s:4:"file";s:30:"2013/04/triforce-wallpaper.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:30:"triforce-wallpaper-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:30:"triforce-wallpaper-600x375.jpg";s:5:"width";i:600;s:6:"height";i:375;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:30:"triforce-wallpaper-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"triforce-wallpaper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"triforce-wallpaper-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"triforce-wallpaper-1024x640.jpg";s:5:"width";i:1024;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (686, 1629, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (687, 1629, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (688, 1629, '_menu_item_object_id', '1629') ; 
INSERT INTO `wp_postmeta` VALUES (689, 1629, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (690, 1629, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (691, 1629, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (692, 1629, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (693, 1629, '_menu_item_url', 'http://wpthemetestdata.wordpress.com/') ; 
INSERT INTO `wp_postmeta` VALUES (694, 1630, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (695, 1630, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (696, 1630, '_menu_item_object_id', '703') ; 
INSERT INTO `wp_postmeta` VALUES (697, 1630, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (698, 1630, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (699, 1630, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (700, 1630, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (701, 1630, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (702, 1631, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (703, 1631, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (704, 1631, '_menu_item_object_id', '135') ; 
INSERT INTO `wp_postmeta` VALUES (705, 1631, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (706, 1631, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (707, 1631, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (708, 1631, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (709, 1631, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (710, 1632, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (711, 1632, '_menu_item_menu_item_parent', '1631') ; 
INSERT INTO `wp_postmeta` VALUES (712, 1632, '_menu_item_object_id', '501') ; 
INSERT INTO `wp_postmeta` VALUES (713, 1632, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (714, 1632, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (715, 1632, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (716, 1632, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (717, 1632, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (718, 1633, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (719, 1633, '_menu_item_menu_item_parent', '1631') ; 
INSERT INTO `wp_postmeta` VALUES (720, 1633, '_menu_item_object_id', '155') ; 
INSERT INTO `wp_postmeta` VALUES (721, 1633, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (722, 1633, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (723, 1633, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (724, 1633, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (725, 1633, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (726, 1634, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (727, 1634, '_menu_item_menu_item_parent', '1631') ; 
INSERT INTO `wp_postmeta` VALUES (728, 1634, '_menu_item_object_id', '156') ; 
INSERT INTO `wp_postmeta` VALUES (729, 1634, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (730, 1634, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (731, 1634, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (732, 1634, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (733, 1634, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (734, 1635, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (735, 1635, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (736, 1635, '_menu_item_object_id', '146') ; 
INSERT INTO `wp_postmeta` VALUES (737, 1635, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (738, 1635, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (739, 1635, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (740, 1635, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (741, 1635, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (742, 1636, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (743, 1636, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (744, 1636, '_menu_item_object_id', '1636') ; 
INSERT INTO `wp_postmeta` VALUES (745, 1636, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (746, 1636, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (747, 1636, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (748, 1636, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (749, 1636, '_menu_item_url', 'http://wpthemetestdata.wordpress.com/') ; 
INSERT INTO `wp_postmeta` VALUES (750, 1637, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (751, 1637, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (752, 1637, '_menu_item_object_id', '703') ; 
INSERT INTO `wp_postmeta` VALUES (753, 1637, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (754, 1637, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (755, 1637, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (756, 1637, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (757, 1637, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (758, 1638, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (759, 1638, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (760, 1638, '_menu_item_object_id', '701') ; 
INSERT INTO `wp_postmeta` VALUES (761, 1638, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (762, 1638, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (763, 1638, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (764, 1638, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (765, 1638, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (766, 1639, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (767, 1639, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (768, 1639, '_menu_item_object_id', '135') ; 
INSERT INTO `wp_postmeta` VALUES (769, 1639, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (770, 1639, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (771, 1639, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (772, 1639, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (773, 1639, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (774, 1640, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (775, 1640, '_menu_item_menu_item_parent', '1639') ; 
INSERT INTO `wp_postmeta` VALUES (776, 1640, '_menu_item_object_id', '501') ; 
INSERT INTO `wp_postmeta` VALUES (777, 1640, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (778, 1640, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (779, 1640, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (780, 1640, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (781, 1640, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (782, 1641, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (783, 1641, '_menu_item_menu_item_parent', '1639') ; 
INSERT INTO `wp_postmeta` VALUES (784, 1641, '_menu_item_object_id', '155') ; 
INSERT INTO `wp_postmeta` VALUES (785, 1641, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (786, 1641, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (787, 1641, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (788, 1641, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (789, 1641, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (790, 1642, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (791, 1642, '_menu_item_menu_item_parent', '1639') ; 
INSERT INTO `wp_postmeta` VALUES (792, 1642, '_menu_item_object_id', '156') ; 
INSERT INTO `wp_postmeta` VALUES (793, 1642, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (794, 1642, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (795, 1642, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (796, 1642, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (797, 1642, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (798, 1643, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (799, 1643, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (800, 1643, '_menu_item_object_id', '174') ; 
INSERT INTO `wp_postmeta` VALUES (801, 1643, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (802, 1643, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (803, 1643, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (804, 1643, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (805, 1643, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (806, 1644, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (807, 1644, '_menu_item_menu_item_parent', '1643') ; 
INSERT INTO `wp_postmeta` VALUES (808, 1644, '_menu_item_object_id', '173') ; 
INSERT INTO `wp_postmeta` VALUES (809, 1644, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (810, 1644, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (811, 1644, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (812, 1644, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (813, 1644, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (814, 1645, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (815, 1645, '_menu_item_menu_item_parent', '1644') ; 
INSERT INTO `wp_postmeta` VALUES (816, 1645, '_menu_item_object_id', '172') ; 
INSERT INTO `wp_postmeta` VALUES (817, 1645, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (818, 1645, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (819, 1645, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (820, 1645, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (821, 1645, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (822, 1646, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (823, 1646, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (824, 1646, '_menu_item_object_id', '146') ; 
INSERT INTO `wp_postmeta` VALUES (825, 1646, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (826, 1646, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (827, 1646, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (828, 1646, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (829, 1646, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (830, 1647, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (831, 1647, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (832, 1647, '_menu_item_object_id', '733') ; 
INSERT INTO `wp_postmeta` VALUES (833, 1647, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (834, 1647, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (835, 1647, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (836, 1647, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (837, 1647, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (838, 1686, '_wp_attached_file', '2013/09/dsc20040724_152504_532.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (839, 1686, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:34:"2013/09/dsc20040724_152504_532.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:34:"dsc20040724_152504_532-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"dsc20040724_152504_532-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (840, 1687, '_wp_attached_file', '2013/09/dsc20050604_133440_34211.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (841, 1687, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:480;s:4:"file";s:36:"2013/09/dsc20050604_133440_34211.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:36:"dsc20050604_133440_34211-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:36:"dsc20050604_133440_34211-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (842, 358, '_wp_old_slug', '') ; 
INSERT INTO `wp_postmeta` VALUES (843, 358, '_wp_old_slug', 'post-format-standard-2') ; 
INSERT INTO `wp_postmeta` VALUES (844, 358, '_wp_old_slug', 'readability-test') ; 
INSERT INTO `wp_postmeta` VALUES (845, 358, '_wp_old_slug', 'markup-readability-test') ; 
INSERT INTO `wp_postmeta` VALUES (846, 555, '_wp_old_slug', 'post-format-gallery-2') ; 
INSERT INTO `wp_postmeta` VALUES (847, 555, '_thumbnail_id', '771') ; 
INSERT INTO `wp_postmeta` VALUES (848, 555, '_wp_old_slug', 'post-format-test-gallery') ; 
INSERT INTO `wp_postmeta` VALUES (849, 559, '_wp_old_slug', 'post-format-aside-2') ; 
INSERT INTO `wp_postmeta` VALUES (850, 559, '_wp_old_slug', 'post-format-test-aside') ; 
INSERT INTO `wp_postmeta` VALUES (851, 562, '_wp_old_slug', 'post-format-test-chat') ; 
INSERT INTO `wp_postmeta` VALUES (852, 565, '_wp_old_slug', 'post-format-test-link') ; 
INSERT INTO `wp_postmeta` VALUES (853, 568, '_wp_old_slug', 'post-format-test-image') ; 
INSERT INTO `wp_postmeta` VALUES (854, 568, '_wp_old_slug', 'post-format-test-image-linked') ; 
INSERT INTO `wp_postmeta` VALUES (855, 575, '_wp_old_slug', 'post-format-test-quote') ; 
INSERT INTO `wp_postmeta` VALUES (856, 579, '_wp_old_slug', 'post-format-test-status') ; 
INSERT INTO `wp_postmeta` VALUES (857, 582, '_wp_old_slug', 'post-format-test-video') ; 
INSERT INTO `wp_postmeta` VALUES (858, 582, '_oembed_29351fff85c1be1d1e9a965a0332a861', '<div class="embed-"><embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="604" height="339" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed></div>') ; 
INSERT INTO `wp_postmeta` VALUES (859, 582, '_oembed_9fcc86d7d9398ff736577f922307f64d', '<div class="embed-"><embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="808" height="454" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed></div>') ; 
INSERT INTO `wp_postmeta` VALUES (860, 582, '_oembed_366237792d32461d0052efb2edec37f5', '<div class="embed-"><embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="584" height="328" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed></div>') ; 
INSERT INTO `wp_postmeta` VALUES (861, 582, '_oembed_37fdfe862c13c46a93be2921279bf675', '<div class="embed-"><embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="599" height="336" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed></div>') ; 
INSERT INTO `wp_postmeta` VALUES (862, 587, 'enclosure', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/originaldixielandjazzbandwithalbernard-stlouisblues.mp3
3043247
audio/mpeg
') ; 
INSERT INTO `wp_postmeta` VALUES (863, 587, '_wp_old_slug', 'post-format-test-audio') ; 
INSERT INTO `wp_postmeta` VALUES (864, 735, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (865, 742, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (866, 744, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (867, 746, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (868, 748, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (869, 993, '_wp_old_slug', 'excerpt') ; 
INSERT INTO `wp_postmeta` VALUES (870, 993, '_wp_old_slug', 'template-excerpt') ; 
INSERT INTO `wp_postmeta` VALUES (871, 993, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (872, 993, 'original_post_id', '993') ; 
INSERT INTO `wp_postmeta` VALUES (873, 993, '_wp_old_slug', '993') ; 
INSERT INTO `wp_postmeta` VALUES (874, 996, '_wp_old_slug', 'more-tag') ; 
INSERT INTO `wp_postmeta` VALUES (875, 996, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (876, 996, 'original_post_id', '996') ; 
INSERT INTO `wp_postmeta` VALUES (877, 996, '_wp_old_slug', '996') ; 
INSERT INTO `wp_postmeta` VALUES (878, 1000, '_wp_old_slug', 'nested-and-mixed-lists') ; 
INSERT INTO `wp_postmeta` VALUES (879, 1000, '_wp_old_slug', 'html-nested-and-mixed-lists') ; 
INSERT INTO `wp_postmeta` VALUES (880, 1000, '_wp_old_slug', 'markup-nested-and-mixed-lists') ; 
INSERT INTO `wp_postmeta` VALUES (881, 1000, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (882, 1000, 'original_post_id', '1000') ; 
INSERT INTO `wp_postmeta` VALUES (883, 1000, '_wp_old_slug', '1000') ; 
INSERT INTO `wp_postmeta` VALUES (884, 1005, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (885, 1005, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (886, 1005, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (887, 1005, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (888, 1005, 'original_post_id', '1005') ; 
INSERT INTO `wp_postmeta` VALUES (889, 1005, '_wp_old_slug', '1005') ; 
INSERT INTO `wp_postmeta` VALUES (890, 1011, '_wp_old_slug', 'media-featured-image-horizontal') ; 
INSERT INTO `wp_postmeta` VALUES (891, 1011, '_wp_old_slug', 'featured-image-horizontal') ; 
INSERT INTO `wp_postmeta` VALUES (892, 1011, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (893, 1011, '_wp_old_slug', 'featured-image') ; 
INSERT INTO `wp_postmeta` VALUES (894, 1011, '_thumbnail_id', '1022') ; 
INSERT INTO `wp_postmeta` VALUES (895, 1011, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (896, 1011, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (897, 1011, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (898, 1011, 'original_post_id', '1011') ; 
INSERT INTO `wp_postmeta` VALUES (899, 1011, '_wp_old_slug', '1011') ; 
INSERT INTO `wp_postmeta` VALUES (900, 1016, '_wp_old_slug', 'media-featured-image-vertical') ; 
INSERT INTO `wp_postmeta` VALUES (901, 1016, '_wp_old_slug', 'featured-image-vertical') ; 
INSERT INTO `wp_postmeta` VALUES (902, 1016, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (903, 1016, '_thumbnail_id', '1027') ; 
INSERT INTO `wp_postmeta` VALUES (904, 1016, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (905, 1016, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (906, 1016, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (907, 1016, 'original_post_id', '1016') ; 
INSERT INTO `wp_postmeta` VALUES (908, 1016, '_wp_old_slug', '1016') ; 
INSERT INTO `wp_postmeta` VALUES (909, 1031, '_wp_old_slug', 'tiled-gallery') ; 
INSERT INTO `wp_postmeta` VALUES (910, 1031, '_wp_old_slug', 'media-tiled-gallery') ; 
INSERT INTO `wp_postmeta` VALUES (911, 1031, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (912, 1031, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (913, 1031, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (914, 1031, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (915, 1031, 'original_post_id', '1031') ; 
INSERT INTO `wp_postmeta` VALUES (916, 1031, '_wp_old_slug', '1031') ; 
INSERT INTO `wp_postmeta` VALUES (917, 1133, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (918, 1133, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (919, 1133, 'original_post_id', '1080') ; 
INSERT INTO `wp_postmeta` VALUES (920, 1133, '_wp_old_slug', '1080') ; 
INSERT INTO `wp_postmeta` VALUES (921, 1134, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (922, 1134, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (923, 1134, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (924, 1134, 'original_post_id', '1083') ; 
INSERT INTO `wp_postmeta` VALUES (925, 1134, '_wp_old_slug', '1083') ; 
INSERT INTO `wp_postmeta` VALUES (926, 1148, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (927, 1148, '_wp_old_slug', 'comment-test') ; 
INSERT INTO `wp_postmeta` VALUES (928, 1148, 'original_post_id', '149') ; 
INSERT INTO `wp_postmeta` VALUES (929, 1148, '_wp_old_slug', '149') ; 
INSERT INTO `wp_postmeta` VALUES (930, 1148, '_wp_old_slug', 'comments') ; 
INSERT INTO `wp_postmeta` VALUES (931, 1149, '_wp_old_slug', 'pingbacks-an-trackbacks') ; 
INSERT INTO `wp_postmeta` VALUES (932, 1149, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (933, 1149, '_wp_old_slug', 'many-trackbacks') ; 
INSERT INTO `wp_postmeta` VALUES (934, 1149, 'original_post_id', '151') ; 
INSERT INTO `wp_postmeta` VALUES (935, 1149, '_wp_old_slug', '151') ; 
INSERT INTO `wp_postmeta` VALUES (936, 1150, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (937, 1150, '_wp_old_slug', 'no-comments') ; 
INSERT INTO `wp_postmeta` VALUES (938, 1150, 'original_post_id', '152') ; 
INSERT INTO `wp_postmeta` VALUES (939, 1150, '_wp_old_slug', '152') ; 
INSERT INTO `wp_postmeta` VALUES (940, 1150, '_wp_old_slug', 'comments-disabled-2') ; 
INSERT INTO `wp_postmeta` VALUES (941, 1151, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (942, 1151, 'original_post_id', '167') ; 
INSERT INTO `wp_postmeta` VALUES (943, 1151, '_wp_old_slug', '167') ; 
INSERT INTO `wp_postmeta` VALUES (944, 1151, '_wp_old_slug', 'many-tags-2') ; 
INSERT INTO `wp_postmeta` VALUES (945, 1152, '_wp_old_slug', 'many-categories-2') ; 
INSERT INTO `wp_postmeta` VALUES (946, 1152, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (947, 1152, 'original_post_id', '168') ; 
INSERT INTO `wp_postmeta` VALUES (948, 1152, '_wp_old_slug', '168') ; 
INSERT INTO `wp_postmeta` VALUES (949, 1153, 'original_post_id', '418') ; 
INSERT INTO `wp_postmeta` VALUES (950, 1153, '_wp_old_slug', '418') ; 
INSERT INTO `wp_postmeta` VALUES (951, 1158, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (952, 1158, '_wp_old_slug', 'post-format-test-image') ; 
INSERT INTO `wp_postmeta` VALUES (953, 1158, '_wp_old_slug', 'post-format-test-image-linked') ; 
INSERT INTO `wp_postmeta` VALUES (954, 1158, 'original_post_id', '568') ; 
INSERT INTO `wp_postmeta` VALUES (955, 1158, '_wp_old_slug', '568') ; 
INSERT INTO `wp_postmeta` VALUES (956, 1161, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (957, 1161, '_wp_old_slug', 'post-format-test-video') ; 
INSERT INTO `wp_postmeta` VALUES (958, 1161, '_wp_old_slug', 'post-format-video') ; 
INSERT INTO `wp_postmeta` VALUES (959, 1161, 'original_post_id', '582') ; 
INSERT INTO `wp_postmeta` VALUES (960, 1161, '_wp_old_slug', '582') ; 
INSERT INTO `wp_postmeta` VALUES (961, 1163, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (962, 1163, '_wp_old_slug', 'post-format-test-image-attached') ; 
INSERT INTO `wp_postmeta` VALUES (963, 1163, 'original_post_id', '674') ; 
INSERT INTO `wp_postmeta` VALUES (964, 1163, '_wp_old_slug', '674') ; 
INSERT INTO `wp_postmeta` VALUES (965, 1163, '_thumbnail_id', '1628') ; 
INSERT INTO `wp_postmeta` VALUES (966, 1163, '_format_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (967, 1163, '_format_link_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (968, 1163, '_format_quote_source_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (969, 1163, '_format_quote_source_name', '') ; 
INSERT INTO `wp_postmeta` VALUES (970, 1163, '_format_image', '') ; 
INSERT INTO `wp_postmeta` VALUES (971, 1163, '_format_audio_embed', '') ; 
INSERT INTO `wp_postmeta` VALUES (972, 1163, '_format_video_embed', '') ; 
INSERT INTO `wp_postmeta` VALUES (973, 1164, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (974, 1164, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (975, 1164, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (976, 1164, 'original_post_id', '922') ; 
INSERT INTO `wp_postmeta` VALUES (977, 1164, '_wp_old_slug', '922') ; 
INSERT INTO `wp_postmeta` VALUES (978, 1168, '_wp_old_slug', 'password-protected') ; 
INSERT INTO `wp_postmeta` VALUES (979, 1168, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (980, 1168, '_wp_old_slug', 'test-with-secret-password') ; 
INSERT INTO `wp_postmeta` VALUES (981, 1168, 'original_post_id', '131') ; 
INSERT INTO `wp_postmeta` VALUES (982, 1168, '_wp_old_slug', '131') ; 
INSERT INTO `wp_postmeta` VALUES (983, 1169, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (984, 1169, '_wp_old_slug', '14') ; 
INSERT INTO `wp_postmeta` VALUES (985, 1169, 'original_post_id', '133') ; 
INSERT INTO `wp_postmeta` VALUES (986, 1169, '_wp_old_slug', '133') ; 
INSERT INTO `wp_postmeta` VALUES (987, 1169, '_wp_old_slug', 'no-title-2') ; 
INSERT INTO `wp_postmeta` VALUES (988, 1170, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (989, 1170, '_wp_old_slug', 'this-post-has-no-body') ; 
INSERT INTO `wp_postmeta` VALUES (990, 1170, 'original_post_id', '134') ; 
INSERT INTO `wp_postmeta` VALUES (991, 1170, '_wp_old_slug', '134') ; 
INSERT INTO `wp_postmeta` VALUES (992, 1170, '_wp_old_slug', 'no-content') ; 
INSERT INTO `wp_postmeta` VALUES (993, 1171, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (994, 1171, '_wp_old_slug', 'layout-test') ; 
INSERT INTO `wp_postmeta` VALUES (995, 1171, 'original_post_id', '188') ; 
INSERT INTO `wp_postmeta` VALUES (996, 1171, '_wp_old_slug', '188') ; 
INSERT INTO `wp_postmeta` VALUES (997, 1171, '_wp_old_slug', 'paginated') ; 
INSERT INTO `wp_postmeta` VALUES (998, 1173, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (999, 1173, 'original_post_id', '861') ; 
INSERT INTO `wp_postmeta` VALUES (1000, 1173, '_wp_old_slug', '861') ; 
INSERT INTO `wp_postmeta` VALUES (1001, 1173, '_wp_old_slug', 'title-with-markup') ; 
INSERT INTO `wp_postmeta` VALUES (1002, 1174, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1003, 1174, 'original_post_id', '867') ; 
INSERT INTO `wp_postmeta` VALUES (1004, 1174, '_wp_old_slug', '867') ; 
INSERT INTO `wp_postmeta` VALUES (1005, 1175, '_wp_old_slug', 'edge-case-non-breaking-text') ; 
INSERT INTO `wp_postmeta` VALUES (1006, 1175, '_wp_old_slug', 'non-breaking-text') ; 
INSERT INTO `wp_postmeta` VALUES (1007, 1175, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1008, 1175, '_wp_old_slug', 'non-breaking-tex') ; 
INSERT INTO `wp_postmeta` VALUES (1009, 1175, 'original_post_id', '877') ; 
INSERT INTO `wp_postmeta` VALUES (1010, 1175, '_wp_old_slug', '877') ; 
INSERT INTO `wp_postmeta` VALUES (1011, 1176, '_wp_old_slug', 'text-alignment') ; 
INSERT INTO `wp_postmeta` VALUES (1012, 1176, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1013, 1176, 'original_post_id', '895') ; 
INSERT INTO `wp_postmeta` VALUES (1014, 1176, '_wp_old_slug', '895') ; 
INSERT INTO `wp_postmeta` VALUES (1015, 1177, '_thumbnail_id', '1023') ; 
INSERT INTO `wp_postmeta` VALUES (1016, 1177, '_wp_old_slug', 'image-alignment') ; 
INSERT INTO `wp_postmeta` VALUES (1017, 1177, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1018, 1177, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (1019, 1177, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (1020, 1177, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (1021, 1177, 'original_post_id', '903') ; 
INSERT INTO `wp_postmeta` VALUES (1022, 1177, '_wp_old_slug', '903') ; 
INSERT INTO `wp_postmeta` VALUES (1023, 1178, '_wp_old_slug', 'markup-and-formatting') ; 
INSERT INTO `wp_postmeta` VALUES (1024, 1178, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1025, 1178, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (1026, 1178, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (1027, 1178, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (1028, 1178, 'original_post_id', '919') ; 
INSERT INTO `wp_postmeta` VALUES (1029, 1178, '_wp_old_slug', '919') ; 
INSERT INTO `wp_postmeta` VALUES (1030, 1179, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1031, 1179, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (1032, 1179, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (1033, 1179, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (1034, 1179, '_wp_old_slug', 'twitter-embeds') ; 
INSERT INTO `wp_postmeta` VALUES (1035, 1179, 'original_post_id', '1027') ; 
INSERT INTO `wp_postmeta` VALUES (1036, 1179, '_wp_old_slug', '1027') ; 
INSERT INTO `wp_postmeta` VALUES (1037, 1241, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1038, 1241, 'standard_seo_post_level_layout', '') ; 
INSERT INTO `wp_postmeta` VALUES (1039, 1241, 'standard_link_url_field', '') ; 
INSERT INTO `wp_postmeta` VALUES (1040, 1241, 'standard_seo_post_meta_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (1041, 1241, 'original_post_id', '1241') ; 
INSERT INTO `wp_postmeta` VALUES (1042, 1241, '_wp_old_slug', '1241') ; 
INSERT INTO `wp_postmeta` VALUES (1043, 1241, '_wp_old_slug', 'sticky') ; 
INSERT INTO `wp_postmeta` VALUES (1044, 1446, '_publicize_pending', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1045, 1688, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1046, 1688, '_menu_item_menu_item_parent', '1046') ; 
INSERT INTO `wp_postmeta` VALUES (1047, 1688, '_menu_item_object_id', '1133') ; 
INSERT INTO `wp_postmeta` VALUES (1048, 1688, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1049, 1688, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1050, 1688, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1051, 1688, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1052, 1688, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1053, 1689, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1054, 1689, '_menu_item_menu_item_parent', '1046') ; 
INSERT INTO `wp_postmeta` VALUES (1055, 1689, '_menu_item_object_id', '1134') ; 
INSERT INTO `wp_postmeta` VALUES (1056, 1689, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1057, 1689, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1058, 1689, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1059, 1689, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1060, 1689, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1061, 1690, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1062, 1690, '_menu_item_menu_item_parent', '1046') ; 
INSERT INTO `wp_postmeta` VALUES (1063, 1690, '_menu_item_object_id', '1133') ; 
INSERT INTO `wp_postmeta` VALUES (1064, 1690, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1065, 1690, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1066, 1690, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1067, 1690, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1068, 1690, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1069, 1691, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1070, 1691, '_menu_item_menu_item_parent', '1046') ; 
INSERT INTO `wp_postmeta` VALUES (1071, 1691, '_menu_item_object_id', '1134') ; 
INSERT INTO `wp_postmeta` VALUES (1072, 1691, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1073, 1691, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1074, 1691, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1075, 1691, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1076, 1691, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1077, 1692, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1078, 1692, '_menu_item_menu_item_parent', '1639') ; 
INSERT INTO `wp_postmeta` VALUES (1079, 1692, '_menu_item_object_id', '1133') ; 
INSERT INTO `wp_postmeta` VALUES (1080, 1692, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1081, 1692, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1082, 1692, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1083, 1692, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1084, 1692, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1085, 1693, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1086, 1693, '_menu_item_menu_item_parent', '1639') ; 
INSERT INTO `wp_postmeta` VALUES (1087, 1693, '_menu_item_object_id', '1134') ; 
INSERT INTO `wp_postmeta` VALUES (1088, 1693, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1089, 1693, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1090, 1693, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1091, 1693, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1092, 1693, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1093, 1694, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1094, 1694, '_menu_item_menu_item_parent', '1644') ; 
INSERT INTO `wp_postmeta` VALUES (1095, 1694, '_menu_item_object_id', '746') ; 
INSERT INTO `wp_postmeta` VALUES (1096, 1694, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1097, 1694, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1098, 1694, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1099, 1694, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1100, 1694, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1101, 1695, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1102, 1695, '_menu_item_menu_item_parent', '1644') ; 
INSERT INTO `wp_postmeta` VALUES (1103, 1695, '_menu_item_object_id', '748') ; 
INSERT INTO `wp_postmeta` VALUES (1104, 1695, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1105, 1695, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1106, 1695, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1107, 1695, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1108, 1695, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1109, 1696, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1110, 1696, '_menu_item_menu_item_parent', '1643') ; 
INSERT INTO `wp_postmeta` VALUES (1111, 1696, '_menu_item_object_id', '742') ; 
INSERT INTO `wp_postmeta` VALUES (1112, 1696, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1113, 1696, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1114, 1696, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1115, 1696, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1116, 1696, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1117, 1697, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1118, 1697, '_menu_item_menu_item_parent', '1643') ; 
INSERT INTO `wp_postmeta` VALUES (1119, 1697, '_menu_item_object_id', '744') ; 
INSERT INTO `wp_postmeta` VALUES (1120, 1697, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1121, 1697, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1122, 1697, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1123, 1697, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1124, 1697, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1125, 1698, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1126, 1698, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1127, 1698, '_menu_item_object_id', '735') ; 
INSERT INTO `wp_postmeta` VALUES (1128, 1698, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1129, 1698, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1130, 1698, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1131, 1698, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1132, 1698, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1136, 1700, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1137, 1700, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1138, 1700, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1139, 1700, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1140, 1700, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1162, 1703, '_menu_item_object_id', '102') ; 
INSERT INTO `wp_postmeta` VALUES (1142, 1701, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1143, 1701, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1144, 1701, '_menu_item_object_id', '97') ; 
INSERT INTO `wp_postmeta` VALUES (1145, 1701, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1146, 1701, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1147, 1701, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1148, 1701, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1149, 1701, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1161, 1703, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1151, 1702, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1152, 1702, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1153, 1702, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (1154, 1702, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1155, 1702, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1156, 1702, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1157, 1702, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1158, 1702, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1160, 1703, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1163, 1703, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1164, 1703, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1165, 1703, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1166, 1703, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1167, 1703, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1169, 1704, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1170, 1704, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1171, 1704, '_menu_item_object_id', '99') ; 
INSERT INTO `wp_postmeta` VALUES (1172, 1704, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1173, 1704, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1174, 1704, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1175, 1704, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1176, 1704, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1178, 1705, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1179, 1705, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1180, 1705, '_menu_item_object_id', '98') ; 
INSERT INTO `wp_postmeta` VALUES (1181, 1705, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1182, 1705, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1183, 1705, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1184, 1705, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1185, 1705, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1187, 1706, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1188, 1706, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1189, 1706, '_menu_item_object_id', '97') ; 
INSERT INTO `wp_postmeta` VALUES (1190, 1706, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1191, 1706, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1192, 1706, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1193, 1706, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1194, 1706, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1196, 1707, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1197, 1707, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1198, 1707, '_menu_item_object_id', '96') ; 
INSERT INTO `wp_postmeta` VALUES (1199, 1707, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1200, 1707, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1201, 1707, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1202, 1707, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1203, 1707, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1205, 1708, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1206, 1708, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1207, 1708, '_menu_item_object_id', '95') ; 
INSERT INTO `wp_postmeta` VALUES (1208, 1708, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1209, 1708, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1210, 1708, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1211, 1708, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1212, 1708, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1306, 1179, '_oembed_38df591fe2f3cc025fdd1c3adc0901a9', '<blockquote class="twitter-tweet" width="500"><p>Really cool to read through and find so much awesomeness added to WordPress 3.6 while I was gone. I should take three weeks off more often.</p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/319508408669708289">April 3, 2013</a></blockquote><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>') ; 
INSERT INTO `wp_postmeta` VALUES (1214, 1709, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1215, 1709, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1216, 1709, '_menu_item_object_id', '100') ; 
INSERT INTO `wp_postmeta` VALUES (1217, 1709, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1218, 1709, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1219, 1709, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1220, 1709, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1221, 1709, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1223, 1710, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1224, 1710, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1225, 1710, '_menu_item_object_id', '101') ; 
INSERT INTO `wp_postmeta` VALUES (1226, 1710, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1227, 1710, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1228, 1710, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1229, 1710, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1230, 1710, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1303, 89, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1232, 1711, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1233, 1711, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1234, 1711, '_menu_item_object_id', '94') ; 
INSERT INTO `wp_postmeta` VALUES (1235, 1711, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1236, 1711, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1237, 1711, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1238, 1711, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1239, 1711, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1298, 2, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1241, 1712, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1242, 1712, '_menu_item_menu_item_parent', '1711') ; 
INSERT INTO `wp_postmeta` VALUES (1243, 1712, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (1244, 1712, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1245, 1712, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1246, 1712, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1247, 1712, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1248, 1712, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1250, 1713, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1251, 1713, '_menu_item_menu_item_parent', '1711') ; 
INSERT INTO `wp_postmeta` VALUES (1252, 1713, '_menu_item_object_id', '1134') ; 
INSERT INTO `wp_postmeta` VALUES (1253, 1713, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1254, 1713, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1255, 1713, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1256, 1713, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1257, 1713, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1259, 1714, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1260, 1714, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1261, 1714, '_menu_item_object_id', '1133') ; 
INSERT INTO `wp_postmeta` VALUES (1262, 1714, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1263, 1714, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1264, 1714, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1265, 1714, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1266, 1714, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1297, 1153, '_edit_lock', '1396530266:1') ; 
INSERT INTO `wp_postmeta` VALUES (1268, 1715, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1269, 1715, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1270, 1715, '_menu_item_object_id', '748') ; 
INSERT INTO `wp_postmeta` VALUES (1271, 1715, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1272, 1715, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1273, 1715, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1274, 1715, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1275, 1715, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1296, 94, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1277, 1716, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1278, 1716, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1279, 1716, '_menu_item_object_id', '746') ; 
INSERT INTO `wp_postmeta` VALUES (1280, 1716, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1281, 1716, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1282, 1716, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1283, 1716, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1284, 1716, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1295, 94, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1286, 1717, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1287, 1717, '_menu_item_menu_item_parent', '1716') ; 
INSERT INTO `wp_postmeta` VALUES (1288, 1717, '_menu_item_object_id', '744') ; 
INSERT INTO `wp_postmeta` VALUES (1289, 1717, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1290, 1717, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1291, 1717, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1292, 1717, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1293, 1717, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1307, 582, '_oembed_4321638fc1a6fee26443f7fe8a70a871', '<embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="500" height="281" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed>') ; 
INSERT INTO `wp_postmeta` VALUES (1308, 1161, '_oembed_2623dffe63fb9ef18382763ccbabf867', '<iframe width="500" height="281" src="http://www.youtube.com/embed/nwe-H6l4beM?feature=oembed" frameborder="0" allowfullscreen></iframe>') ; 
INSERT INTO `wp_postmeta` VALUES (1309, 555, '_edit_lock', '1400059184:1') ; 
INSERT INTO `wp_postmeta` VALUES (1310, 1178, '_edit_lock', '1400068355:1') ; 
INSERT INTO `wp_postmeta` VALUES (1311, 1178, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1336, 1737, '_wp_attached_file', '2014/04/Chrysanthemum.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1337, 1737, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1338, 1737, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:25:"2014/04/Chrysanthemum.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"Chrysanthemum-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"Chrysanthemum-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"Chrysanthemum-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"Chrysanthemum-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Chrysanthemum-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:6:"Corbis";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:32:"© Corbis.  All Rights Reserved.";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1339, 1737, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1340, 1738, '_wp_attached_file', '2014/04/Chrysanthemum1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1341, 1738, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1342, 1738, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:26:"2014/04/Chrysanthemum1.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:26:"Chrysanthemum1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:26:"Chrysanthemum1-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:26:"Chrysanthemum1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:26:"Chrysanthemum1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Chrysanthemum1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:6:"Corbis";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:32:"© Corbis.  All Rights Reserved.";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1343, 1738, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1344, 1739, '_wp_attached_file', '2014/04/cropped-Penguins.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1345, 1739, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1346, 1739, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:868;s:6:"height";i:225;s:4:"file";s:28:"2014/04/cropped-Penguins.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:28:"cropped-Penguins-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:28:"cropped-Penguins-600x156.jpg";s:5:"width";i:600;s:6:"height";i:156;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:28:"cropped-Penguins-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:28:"cropped-Penguins-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"cropped-Penguins-300x77.jpg";s:5:"width";i:300;s:6:"height";i:77;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1347, 1739, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1348, 1740, '_wp_attached_file', '2014/04/DSC0014.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1349, 1740, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1350, 1740, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2592;s:6:"height";i:3872;s:4:"file";s:19:"2014/04/DSC0014.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"DSC0014-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"DSC0014-600x896.jpg";s:5:"width";i:600;s:6:"height";i:896;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"DSC0014-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"DSC0014-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"DSC0014-300x448.jpg";s:5:"width";i:300;s:6:"height";i:448;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"DSC0014-1024x1529.jpg";s:5:"width";i:1024;s:6:"height";i:1529;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1351, 1740, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1352, 1741, '_wp_attached_file', '2014/04/DSC0024.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1353, 1741, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1354, 1741, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3872;s:6:"height";i:2592;s:4:"file";s:19:"2014/04/DSC0024.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"DSC0024-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"DSC0024-600x402.jpg";s:5:"width";i:600;s:6:"height";i:402;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"DSC0024-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"DSC0024-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"DSC0024-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"DSC0024-1024x685.jpg";s:5:"width";i:1024;s:6:"height";i:685;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1355, 1741, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1356, 1742, '_wp_attached_file', '2014/04/cropped-DSC_0093.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1357, 1742, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1358, 1742, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:900;s:6:"height";i:300;s:4:"file";s:28:"2014/04/cropped-DSC_0093.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:28:"cropped-DSC_0093-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:28:"cropped-DSC_0093-600x200.jpg";s:5:"width";i:600;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:28:"cropped-DSC_0093-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:28:"cropped-DSC_0093-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"cropped-DSC_0093-300x100.jpg";s:5:"width";i:300;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1359, 1742, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1360, 1743, '_wp_attached_file', '2014/04/sizedBlue%20Morpho%20Morpho%20peleides5335.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1361, 1743, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1362, 1744, '_wp_attached_file', '2014/04/cropped-ladybug-pictures.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1363, 1744, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1364, 1744, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:300;s:4:"file";s:36:"2014/04/cropped-ladybug-pictures.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:36:"cropped-ladybug-pictures-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:36:"cropped-ladybug-pictures-600x188.jpg";s:5:"width";i:600;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:36:"cropped-ladybug-pictures-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:36:"cropped-ladybug-pictures-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"cropped-ladybug-pictures-300x93.jpg";s:5:"width";i:300;s:6:"height";i:93;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1365, 1744, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1366, 1745, '_wp_attached_file', '2014/04/cropped-TG4ZZF2h.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1367, 1745, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1368, 1745, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:300;s:4:"file";s:28:"2014/04/cropped-TG4ZZF2h.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:28:"cropped-TG4ZZF2h-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:28:"cropped-TG4ZZF2h-600x188.jpg";s:5:"width";i:600;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:28:"cropped-TG4ZZF2h-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:28:"cropped-TG4ZZF2h-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"cropped-TG4ZZF2h-300x93.jpg";s:5:"width";i:300;s:6:"height";i:93;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1369, 1745, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1370, 582, '_oembed_a422923038c5bdea6c15f0a50a09279b', '<embed src="http://v.wordpress.com/hrPKeL5t" type="application/x-shockwave-flash" width="654" height="367" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed>') ; 
INSERT INTO `wp_postmeta` VALUES (1371, 1161, '_oembed_b72c20d925d54b727a71d5e3c92367e2', '<iframe width="654" height="368" src="http://www.youtube.com/embed/nwe-H6l4beM?feature=oembed" frameborder="0" allowfullscreen></iframe>') ; 
INSERT INTO `wp_postmeta` VALUES (1372, 587, '_edit_lock', '1397804499:1') ; 
INSERT INTO `wp_postmeta` VALUES (1373, 582, '_edit_lock', '1397804532:1') ; 
INSERT INTO `wp_postmeta` VALUES (1374, 1179, '_oembed_20222320dbbfa82408460cf499f7d049', '<blockquote class="twitter-tweet" width="550"><p>Really cool to read through and find so much awesomeness added to WordPress 3.6 while I was gone. I should take three weeks off more often.</p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/319508408669708289">April 3, 2013</a></blockquote><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>') ; 
INSERT INTO `wp_postmeta` VALUES (1375, 1747, '_wp_attached_file', '2014/04/cropped-bro2.jpg.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1376, 1747, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1377, 1747, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:300;s:4:"file";s:28:"2014/04/cropped-bro2.jpg.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:28:"cropped-bro2.jpg-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:28:"cropped-bro2.jpg-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:28:"cropped-bro2.jpg-600x188.jpg";s:5:"width";i:600;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:28:"cropped-bro2.jpg-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"cropped-bro2.jpg-300x93.jpg";s:5:"width";i:300;s:6:"height";i:93;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1378, 1747, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1379, 1748, '_wp_attached_file', '2014/04/cropped-header.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1380, 1748, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1381, 1748, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:300;s:4:"file";s:26:"2014/04/cropped-header.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:26:"cropped-header-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:26:"cropped-header-600x150.jpg";s:5:"width";i:600;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:26:"cropped-header-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:26:"cropped-header-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"cropped-header-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"cropped-header-1024x256.jpg";s:5:"width";i:1024;s:6:"height";i:256;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1382, 1748, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1383, 1750, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1384, 1750, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1385, 1750, '_menu_item_object_id', '703') ; 
INSERT INTO `wp_postmeta` VALUES (1386, 1750, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1387, 1750, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1388, 1750, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1389, 1750, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1390, 1750, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1392, 1168, '_edit_lock', '1400143826:1') ; 
INSERT INTO `wp_postmeta` VALUES (1393, 701, '_edit_lock', '1399542168:1') ; 
INSERT INTO `wp_postmeta` VALUES (1394, 1148, '_edit_lock', '1400059213:1') ; 
INSERT INTO `wp_postmeta` VALUES (1395, 1158, '_edit_lock', '1399557525:1') ; 
INSERT INTO `wp_postmeta` VALUES (1396, 1158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1400, 1756, '_edit_lock', '1399992840:1') ; 
INSERT INTO `wp_postmeta` VALUES (1451, 1773, '_edit_lock', '1403876127:1') ; 
INSERT INTO `wp_postmeta` VALUES (1401, 1756, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1402, 1758, '_edit_lock', '1400055936:1') ; 
INSERT INTO `wp_postmeta` VALUES (1403, 1758, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1449, 1765, '_wp_attachment_custom_header_last_used_purple-modena', '1424257481') ; 
INSERT INTO `wp_postmeta` VALUES (1406, 1177, '_edit_lock', '1400059088:1') ; 
INSERT INTO `wp_postmeta` VALUES (1407, 1173, '_edit_lock', '1400059103:1') ; 
INSERT INTO `wp_postmeta` VALUES (1408, 996, '_edit_lock', '1400059114:1') ; 
INSERT INTO `wp_postmeta` VALUES (1409, 993, '_edit_lock', '1400059124:1') ; 
INSERT INTO `wp_postmeta` VALUES (1410, 1241, '_edit_lock', '1405332906:1') ; 
INSERT INTO `wp_postmeta` VALUES (1411, 1016, '_edit_lock', '1400059154:1') ; 
INSERT INTO `wp_postmeta` VALUES (1412, 1179, '_edit_lock', '1400059221:1') ; 
INSERT INTO `wp_postmeta` VALUES (1413, 1163, '_edit_lock', '1400059231:1') ; 
INSERT INTO `wp_postmeta` VALUES (1414, 568, '_edit_lock', '1400059298:1') ; 
INSERT INTO `wp_postmeta` VALUES (1415, 575, '_edit_lock', '1400059316:1') ; 
INSERT INTO `wp_postmeta` VALUES (1416, 1152, '_edit_lock', '1400059325:1') ; 
INSERT INTO `wp_postmeta` VALUES (1417, 1000, '_edit_lock', '1400059332:1') ; 
INSERT INTO `wp_postmeta` VALUES (1418, 35, '_edit_lock', '1400059345:1') ; 
INSERT INTO `wp_postmeta` VALUES (1419, 5, '_edit_lock', '1400059356:1') ; 
INSERT INTO `wp_postmeta` VALUES (1420, 1761, '_wp_attached_file', '2014/05/Chrysanthemum.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1421, 1761, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1422, 1761, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:25:"2014/05/Chrysanthemum.jpg";s:5:"sizes";a:5:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"Chrysanthemum-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"Chrysanthemum-600x450.jpg";s:5:"width";i:600;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"Chrysanthemum-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"Chrysanthemum-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Chrysanthemum-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:6:"Corbis";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:32:"© Corbis.  All Rights Reserved.";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1423, 1761, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1424, 1762, '_wp_attached_file', '2014/05/cropped-574902_10151411832829813_1669317567_n.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1425, 1762, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1426, 1762, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:300;s:4:"file";s:57:"2014/05/cropped-574902_10151411832829813_1669317567_n.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:57:"cropped-574902_10151411832829813_1669317567_n-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:57:"cropped-574902_10151411832829813_1669317567_n-600x150.jpg";s:5:"width";i:600;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:57:"cropped-574902_10151411832829813_1669317567_n-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:57:"cropped-574902_10151411832829813_1669317567_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"cropped-574902_10151411832829813_1669317567_n-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:58:"cropped-574902_10151411832829813_1669317567_n-1024x256.jpg";s:5:"width";i:1024;s:6:"height";i:256;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1427, 1762, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1428, 1763, '_wp_attached_file', '2014/05/cropped-735675_10151340077434490_1914316469_o.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1429, 1763, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1430, 1763, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:300;s:4:"file";s:57:"2014/05/cropped-735675_10151340077434490_1914316469_o.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:57:"cropped-735675_10151340077434490_1914316469_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:57:"cropped-735675_10151340077434490_1914316469_o-600x150.jpg";s:5:"width";i:600;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:57:"cropped-735675_10151340077434490_1914316469_o-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:57:"cropped-735675_10151340077434490_1914316469_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"cropped-735675_10151340077434490_1914316469_o-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:58:"cropped-735675_10151340077434490_1914316469_o-1024x256.jpg";s:5:"width";i:1024;s:6:"height";i:256;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1431, 1763, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1432, 1764, '_wp_attached_file', '2014/05/cropped-966963_10151622422320600_2088357858_o.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1433, 1764, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1434, 1764, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:300;s:4:"file";s:57:"2014/05/cropped-966963_10151622422320600_2088357858_o.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:57:"cropped-966963_10151622422320600_2088357858_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:57:"cropped-966963_10151622422320600_2088357858_o-600x150.jpg";s:5:"width";i:600;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:57:"cropped-966963_10151622422320600_2088357858_o-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:57:"cropped-966963_10151622422320600_2088357858_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"cropped-966963_10151622422320600_2088357858_o-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:58:"cropped-966963_10151622422320600_2088357858_o-1024x256.jpg";s:5:"width";i:1024;s:6:"height";i:256;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1435, 1764, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1436, 1765, '_wp_attached_file', '2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1437, 1765, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1438, 1765, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:300;s:4:"file";s:67:"2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:67:"cropped-1979900_10152288225475210_8872398524763230616_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:67:"cropped-1979900_10152288225475210_8872398524763230616_o-600x150.jpg";s:5:"width";i:600;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:67:"cropped-1979900_10152288225475210_8872398524763230616_o-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:67:"cropped-1979900_10152288225475210_8872398524763230616_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:66:"cropped-1979900_10152288225475210_8872398524763230616_o-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:68:"cropped-1979900_10152288225475210_8872398524763230616_o-1024x256.jpg";s:5:"width";i:1024;s:6:"height";i:256;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1439, 1765, '_wp_attachment_is_custom_header', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1442, 1168, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1452, 1773, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1453, 1774, '_edit_lock', '1403879446:1') ; 
INSERT INTO `wp_postmeta` VALUES (1454, 1774, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1455, 1775, '_edit_lock', '1403875896:1') ; 
INSERT INTO `wp_postmeta` VALUES (1456, 1775, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1457, 1773, '_thumbnail_id', '130') ; 
INSERT INTO `wp_postmeta` VALUES (1458, 1774, '_thumbnail_id', '811') ; 
INSERT INTO `wp_postmeta` VALUES (1459, 1775, '_thumbnail_id', '770') ; 
INSERT INTO `wp_postmeta` VALUES (1471, 1179, '_oembed_532a7f544f811dd510ac4572c70dd8fc', '<blockquote class="twitter-tweet" width="550"><p>Really cool to read through and find so much awesomeness added to WordPress 3.6 while I was gone. I should take three weeks off more often.</p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/319508408669708289">April 3, 2013</a></blockquote><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>') ; 
INSERT INTO `wp_postmeta` VALUES (1463, 93, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1466, 92, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1469, 1775, 'product_price', '2$') ; 
INSERT INTO `wp_postmeta` VALUES (1470, 1773, 'product_price', '15$') ; 
INSERT INTO `wp_postmeta` VALUES (1472, 1782, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"function";s:10:"deprecated";s:23:"add_custom_background()";s:11:"replacement";s:47:"add_theme_support( \'custom-background\', $args )";s:7:"version";s:3:"3.4";s:4:"hook";N;s:7:"in_file";s:51:"wp-content/themes/modelun/library/siteframework.php";s:7:"on_line";i:69;}') ; 
INSERT INTO `wp_postmeta` VALUES (1473, 1782, '_deprecated_log_type', 'function') ; 
INSERT INTO `wp_postmeta` VALUES (1474, 1782, '_deprecated_log_deprecated', 'add_custom_background()') ; 
INSERT INTO `wp_postmeta` VALUES (1475, 1782, '_deprecated_log_replacement', 'add_theme_support( \'custom-background\', $args )') ; 
INSERT INTO `wp_postmeta` VALUES (1476, 1782, '_deprecated_log_version', '3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1477, 1782, '_deprecated_log_hook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1478, 1782, '_deprecated_log_in_file', 'wp-content/themes/modelun/library/siteframework.php') ; 
INSERT INTO `wp_postmeta` VALUES (1479, 1782, '_deprecated_log_on_line', '69') ; 
INSERT INTO `wp_postmeta` VALUES (1480, 1783, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"function";s:10:"deprecated";s:16:"get_theme_data()";s:11:"replacement";s:14:"wp_get_theme()";s:7:"version";s:3:"3.4";s:4:"hook";N;s:7:"in_file";s:43:"wp-content/themes/modelun/theme-options.php";s:7:"on_line";i:56;}') ; 
INSERT INTO `wp_postmeta` VALUES (1481, 1783, '_deprecated_log_type', 'function') ; 
INSERT INTO `wp_postmeta` VALUES (1482, 1783, '_deprecated_log_deprecated', 'get_theme_data()') ; 
INSERT INTO `wp_postmeta` VALUES (1483, 1783, '_deprecated_log_replacement', 'wp_get_theme()') ; 
INSERT INTO `wp_postmeta` VALUES (1484, 1783, '_deprecated_log_version', '3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1485, 1783, '_deprecated_log_hook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1486, 1783, '_deprecated_log_in_file', 'wp-content/themes/modelun/theme-options.php') ; 
INSERT INTO `wp_postmeta` VALUES (1487, 1783, '_deprecated_log_on_line', '56') ; 
INSERT INTO `wp_postmeta` VALUES (1488, 1784, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"function";s:10:"deprecated";s:16:"get_theme_data()";s:11:"replacement";s:14:"wp_get_theme()";s:7:"version";s:3:"3.4";s:4:"hook";N;s:7:"in_file";s:55:"wp-content/themes/modelun/admin/inc/customfunctions.php";s:7:"on_line";i:105;}') ; 
INSERT INTO `wp_postmeta` VALUES (1489, 1784, '_deprecated_log_type', 'function') ; 
INSERT INTO `wp_postmeta` VALUES (1490, 1784, '_deprecated_log_deprecated', 'get_theme_data()') ; 
INSERT INTO `wp_postmeta` VALUES (1491, 1784, '_deprecated_log_replacement', 'wp_get_theme()') ; 
INSERT INTO `wp_postmeta` VALUES (1492, 1784, '_deprecated_log_version', '3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1493, 1784, '_deprecated_log_hook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1494, 1784, '_deprecated_log_in_file', 'wp-content/themes/modelun/admin/inc/customfunctions.php') ; 
INSERT INTO `wp_postmeta` VALUES (1495, 1784, '_deprecated_log_on_line', '105') ; 
INSERT INTO `wp_postmeta` VALUES (1496, 1785, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"argument";s:10:"deprecated";s:10:"WP_Query()";s:7:"message";s:68:""caller_get_posts" is deprecated. Use "ignore_sticky_posts" instead.";s:4:"menu";N;s:7:"version";s:3:"3.1";s:7:"in_file";s:21:"wp-includes/query.php";s:7:"on_line";i:3636;}') ; 
INSERT INTO `wp_postmeta` VALUES (1497, 1785, '_deprecated_log_type', 'argument') ; 
INSERT INTO `wp_postmeta` VALUES (1498, 1785, '_deprecated_log_deprecated', 'WP_Query()') ; 
INSERT INTO `wp_postmeta` VALUES (1499, 1785, '_deprecated_log_message', '"caller_get_posts" is deprecated. Use "ignore_sticky_posts" instead.') ; 
INSERT INTO `wp_postmeta` VALUES (1500, 1785, '_deprecated_log_menu', '') ; 
INSERT INTO `wp_postmeta` VALUES (1501, 1785, '_deprecated_log_version', '3.1') ; 
INSERT INTO `wp_postmeta` VALUES (1502, 1785, '_deprecated_log_in_file', 'wp-includes/query.php') ; 
INSERT INTO `wp_postmeta` VALUES (1503, 1785, '_deprecated_log_on_line', '3636') ; 
INSERT INTO `wp_postmeta` VALUES (1504, 1794, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"function";s:10:"deprecated";s:16:"get_theme_data()";s:11:"replacement";s:14:"wp_get_theme()";s:7:"version";s:3:"3.4";s:4:"hook";N;s:7:"in_file";s:53:"wp-content/themes/modelun/admin/options-framework.php";s:7:"on_line";i:192;}') ; 
INSERT INTO `wp_postmeta` VALUES (1505, 1794, '_deprecated_log_type', 'function') ; 
INSERT INTO `wp_postmeta` VALUES (1506, 1794, '_deprecated_log_deprecated', 'get_theme_data()') ; 
INSERT INTO `wp_postmeta` VALUES (1507, 1794, '_deprecated_log_replacement', 'wp_get_theme()') ; 
INSERT INTO `wp_postmeta` VALUES (1508, 1794, '_deprecated_log_version', '3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1509, 1794, '_deprecated_log_hook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1510, 1794, '_deprecated_log_in_file', 'wp-content/themes/modelun/admin/options-framework.php') ; 
INSERT INTO `wp_postmeta` VALUES (1511, 1794, '_deprecated_log_on_line', '192') ; 
INSERT INTO `wp_postmeta` VALUES (1512, 1797, '_wp_attached_file', '2015/02/10688275_1528986380691254_4638960547305208_o.png') ; 
INSERT INTO `wp_postmeta` VALUES (1513, 1797, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1514, 1797, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1325;s:6:"height";i:2048;s:4:"file";s:56:"2015/02/10688275_1528986380691254_4638960547305208_o.png";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:56:"10688275_1528986380691254_4638960547305208_o-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:56:"10688275_1528986380691254_4638960547305208_o-600x927.png";s:5:"width";i:600;s:6:"height";i:927;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:56:"10688275_1528986380691254_4638960547305208_o-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:56:"10688275_1528986380691254_4638960547305208_o-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:56:"10688275_1528986380691254_4638960547305208_o-300x463.png";s:5:"width";i:300;s:6:"height";i:463;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:58:"10688275_1528986380691254_4638960547305208_o-1024x1582.png";s:5:"width";i:1024;s:6:"height";i:1582;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1515, 1797, '_wp_attachment_is_custom_background', 'purple-modena') ; 
INSERT INTO `wp_postmeta` VALUES (1516, 1801, '_deprecated_log_meta', 'a:7:{s:4:"type";s:8:"function";s:10:"deprecated";s:13:"like_escape()";s:11:"replacement";s:16:"wpdb::esc_like()";s:7:"version";s:5:"4.0.0";s:4:"hook";N;s:7:"in_file";s:25:"wp-includes/functions.php";s:7:"on_line";i:3826;}') ; 
INSERT INTO `wp_postmeta` VALUES (1517, 1801, '_deprecated_log_type', 'function') ; 
INSERT INTO `wp_postmeta` VALUES (1518, 1801, '_deprecated_log_deprecated', 'like_escape()') ; 
INSERT INTO `wp_postmeta` VALUES (1519, 1801, '_deprecated_log_replacement', 'wpdb::esc_like()') ; 
INSERT INTO `wp_postmeta` VALUES (1520, 1801, '_deprecated_log_version', '4.0.0') ; 
INSERT INTO `wp_postmeta` VALUES (1521, 1801, '_deprecated_log_hook', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1522, 1801, '_deprecated_log_in_file', 'wp-includes/functions.php') ; 
INSERT INTO `wp_postmeta` VALUES (1523, 1801, '_deprecated_log_on_line', '3826') ; 
INSERT INTO `wp_postmeta` VALUES (1524, 1806, '_wp_attached_file', '2018/03/beanie.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1525, 1806, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:18:"2018/03/beanie.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:18:"beanie-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:18:"beanie-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:18:"beanie-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"beanie-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"beanie-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"beanie-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1526, 1806, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1527, 1806, '_customize_draft_post_name', 'beanie-image') ; 
INSERT INTO `wp_postmeta` VALUES (1528, 1807, '_wp_attached_file', '2018/03/belt.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1529, 1807, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:16:"2018/03/belt.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:16:"belt-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:16:"belt-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:16:"belt-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"belt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"belt-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:16:"belt-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1530, 1807, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1531, 1807, '_customize_draft_post_name', 'belt-image') ; 
INSERT INTO `wp_postmeta` VALUES (1532, 1808, '_wp_attached_file', '2018/03/cap.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1533, 1808, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:15:"2018/03/cap.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:15:"cap-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:15:"cap-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:15:"cap-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:15:"cap-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"cap-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"cap-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1534, 1808, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1535, 1808, '_customize_draft_post_name', 'cap-image') ; 
INSERT INTO `wp_postmeta` VALUES (1536, 1809, '_wp_attached_file', '2018/03/hoodie-with-logo.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1537, 1809, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:28:"2018/03/hoodie-with-logo.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:28:"hoodie-with-logo-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:28:"hoodie-with-logo-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:28:"hoodie-with-logo-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:28:"hoodie-with-logo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"hoodie-with-logo-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"hoodie-with-logo-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1538, 1809, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1539, 1809, '_customize_draft_post_name', 'hoodie-with-logo-image') ; 
INSERT INTO `wp_postmeta` VALUES (1540, 1810, '_wp_attached_file', '2018/03/hoodie-with-pocket.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1541, 1810, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:30:"2018/03/hoodie-with-pocket.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:30:"hoodie-with-pocket-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:30:"hoodie-with-pocket-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:30:"hoodie-with-pocket-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"hoodie-with-pocket-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"hoodie-with-pocket-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"hoodie-with-pocket-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1542, 1810, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1543, 1810, '_customize_draft_post_name', 'hoodie-with-pocket-image') ; 
INSERT INTO `wp_postmeta` VALUES (1544, 1811, '_wp_attached_file', '2018/03/hoodie-with-zipper.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1545, 1811, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:800;s:4:"file";s:30:"2018/03/hoodie-with-zipper.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:30:"hoodie-with-zipper-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:30:"hoodie-with-zipper-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:30:"hoodie-with-zipper-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"hoodie-with-zipper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"hoodie-with-zipper-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"hoodie-with-zipper-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1546, 1811, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1547, 1811, '_customize_draft_post_name', 'hoodie-with-zipper-image') ; 
INSERT INTO `wp_postmeta` VALUES (1548, 1812, '_wp_attached_file', '2018/03/hoodie.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1549, 1812, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:18:"2018/03/hoodie.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:18:"hoodie-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:18:"hoodie-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:18:"hoodie-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"hoodie-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"hoodie-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"hoodie-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1550, 1812, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1551, 1812, '_customize_draft_post_name', 'hoodie-image') ; 
INSERT INTO `wp_postmeta` VALUES (1552, 1813, '_wp_attached_file', '2018/03/long-sleeve-tee.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1553, 1813, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:27:"2018/03/long-sleeve-tee.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"long-sleeve-tee-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"long-sleeve-tee-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"long-sleeve-tee-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"long-sleeve-tee-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"long-sleeve-tee-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"long-sleeve-tee-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1554, 1813, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1555, 1813, '_customize_draft_post_name', 'long-sleeve-tee-image') ; 
INSERT INTO `wp_postmeta` VALUES (1556, 1814, '_wp_attached_file', '2018/03/polo.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1557, 1814, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:800;s:4:"file";s:16:"2018/03/polo.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:16:"polo-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:16:"polo-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:16:"polo-600x599.jpg";s:5:"width";i:600;s:6:"height";i:599;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"polo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"polo-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:16:"polo-768x767.jpg";s:5:"width";i:768;s:6:"height";i:767;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1558, 1814, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1559, 1814, '_customize_draft_post_name', 'polo-image') ; 
INSERT INTO `wp_postmeta` VALUES (1560, 1815, '_wp_attached_file', '2018/03/sunglasses.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1561, 1815, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:22:"2018/03/sunglasses.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:22:"sunglasses-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:22:"sunglasses-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:22:"sunglasses-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"sunglasses-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"sunglasses-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"sunglasses-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1562, 1815, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1563, 1815, '_customize_draft_post_name', 'sunglasses-image') ; 
INSERT INTO `wp_postmeta` VALUES (1564, 1816, '_wp_attached_file', '2018/03/tshirt.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1565, 1816, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:18:"2018/03/tshirt.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:18:"tshirt-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:18:"tshirt-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:18:"tshirt-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"tshirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"tshirt-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"tshirt-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1566, 1816, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1567, 1816, '_customize_draft_post_name', 'tshirt-image') ; 
INSERT INTO `wp_postmeta` VALUES (1568, 1817, '_wp_attached_file', '2018/03/vneck-tee.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1569, 1817, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:800;s:4:"file";s:21:"2018/03/vneck-tee.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:21:"vneck-tee-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:21:"vneck-tee-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:21:"vneck-tee-600x599.jpg";s:5:"width";i:600;s:6:"height";i:599;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"vneck-tee-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"vneck-tee-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"vneck-tee-768x767.jpg";s:5:"width";i:768;s:6:"height";i:767;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1570, 1817, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1571, 1817, '_customize_draft_post_name', 'vneck-tee-image') ; 
INSERT INTO `wp_postmeta` VALUES (1572, 1818, '_wp_attached_file', '2018/03/hero.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1573, 1818, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3795;s:6:"height";i:2355;s:4:"file";s:16:"2018/03/hero.jpg";s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:16:"hero-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:16:"hero-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:16:"hero-600x372.jpg";s:5:"width";i:600;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"hero-300x186.jpg";s:5:"width";i:300;s:6:"height";i:186;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:16:"hero-768x477.jpg";s:5:"width";i:768;s:6:"height";i:477;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:17:"hero-1024x635.jpg";s:5:"width";i:1024;s:6:"height";i:635;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1574, 1818, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1575, 1818, '_customize_draft_post_name', 'hero-image') ; 
INSERT INTO `wp_postmeta` VALUES (1576, 1819, '_wp_attached_file', '2018/03/accessories.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1577, 1819, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:23:"2018/03/accessories.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:23:"accessories-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:23:"accessories-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:23:"accessories-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:23:"accessories-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"accessories-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"accessories-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1578, 1819, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1579, 1819, '_customize_draft_post_name', 'accessories-image') ; 
INSERT INTO `wp_postmeta` VALUES (1580, 1820, '_wp_attached_file', '2018/03/tshirts.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1581, 1820, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:19:"2018/03/tshirts.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"tshirts-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"tshirts-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"tshirts-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"tshirts-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"tshirts-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"tshirts-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1582, 1820, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1583, 1820, '_customize_draft_post_name', 'tshirts-image') ; 
INSERT INTO `wp_postmeta` VALUES (1584, 1821, '_wp_attached_file', '2018/03/hoodies.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1585, 1821, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:800;s:4:"file";s:19:"2018/03/hoodies.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"hoodies-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"hoodies-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"hoodies-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"hoodies-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"hoodies-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"hoodies-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (1586, 1821, '_starter_content_theme', 'storefront') ; 
INSERT INTO `wp_postmeta` VALUES (1587, 1821, '_customize_draft_post_name', 'hoodies-image') ; 
INSERT INTO `wp_postmeta` VALUES (1588, 1822, '_thumbnail_id', '1806') ; 
INSERT INTO `wp_postmeta` VALUES (1589, 1822, '_customize_draft_post_name', 'beanie') ; 
INSERT INTO `wp_postmeta` VALUES (1590, 1822, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1591, 1823, '_thumbnail_id', '1807') ; 
INSERT INTO `wp_postmeta` VALUES (1592, 1823, '_customize_draft_post_name', 'belt') ; 
INSERT INTO `wp_postmeta` VALUES (1593, 1823, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1594, 1824, '_thumbnail_id', '1808') ; 
INSERT INTO `wp_postmeta` VALUES (1595, 1824, '_customize_draft_post_name', 'cap') ; 
INSERT INTO `wp_postmeta` VALUES (1596, 1824, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1597, 1825, '_thumbnail_id', '1815') ; 
INSERT INTO `wp_postmeta` VALUES (1598, 1825, '_customize_draft_post_name', 'sunglasses') ; 
INSERT INTO `wp_postmeta` VALUES (1599, 1825, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1600, 1826, '_thumbnail_id', '1809') ; 
INSERT INTO `wp_postmeta` VALUES (1601, 1826, '_customize_draft_post_name', 'hoodie-with-logo') ; 
INSERT INTO `wp_postmeta` VALUES (1602, 1826, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1603, 1827, '_thumbnail_id', '1810') ; 
INSERT INTO `wp_postmeta` VALUES (1604, 1827, '_customize_draft_post_name', 'hoodie-with-pocket') ; 
INSERT INTO `wp_postmeta` VALUES (1605, 1827, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1606, 1828, '_thumbnail_id', '1811') ; 
INSERT INTO `wp_postmeta` VALUES (1607, 1828, '_customize_draft_post_name', 'hoodie-with-zipper') ; 
INSERT INTO `wp_postmeta` VALUES (1608, 1828, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1609, 1829, '_thumbnail_id', '1812') ; 
INSERT INTO `wp_postmeta` VALUES (1610, 1829, '_customize_draft_post_name', 'hoodie') ; 
INSERT INTO `wp_postmeta` VALUES (1611, 1829, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1612, 1830, '_thumbnail_id', '1813') ; 
INSERT INTO `wp_postmeta` VALUES (1613, 1830, '_customize_draft_post_name', 'long-sleeve-tee') ; 
INSERT INTO `wp_postmeta` VALUES (1614, 1830, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1615, 1831, '_thumbnail_id', '1814') ; 
INSERT INTO `wp_postmeta` VALUES (1616, 1831, '_customize_draft_post_name', 'polo') ; 
INSERT INTO `wp_postmeta` VALUES (1617, 1831, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1618, 1832, '_thumbnail_id', '1816') ; 
INSERT INTO `wp_postmeta` VALUES (1619, 1832, '_customize_draft_post_name', 'tshirt') ; 
INSERT INTO `wp_postmeta` VALUES (1620, 1832, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1621, 1833, '_thumbnail_id', '1817') ; 
INSERT INTO `wp_postmeta` VALUES (1622, 1833, '_customize_draft_post_name', 'vneck-tee') ; 
INSERT INTO `wp_postmeta` VALUES (1623, 1833, '_customize_changeset_uuid', '4e337dbc-093e-41f5-adf9-185e718bf6f1') ; 
INSERT INTO `wp_postmeta` VALUES (1624, 1822, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1625, 1822, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1626, 1822, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1627, 1822, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1628, 1822, '_regular_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (1629, 1822, '_sale_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1630, 1822, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1631, 1822, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1632, 1822, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1633, 1822, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1634, 1822, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1635, 1822, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1636, 1822, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1637, 1822, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1638, 1822, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1639, 1822, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1640, 1822, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1641, 1822, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1642, 1822, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1643, 1822, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1644, 1822, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1645, 1822, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1646, 1822, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1647, 1822, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1648, 1822, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1649, 1822, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1650, 1822, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1651, 1822, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1652, 1822, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1653, 1822, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1654, 1822, '_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1655, 1823, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1656, 1823, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1657, 1823, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1658, 1823, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1659, 1823, '_regular_price', '65') ; 
INSERT INTO `wp_postmeta` VALUES (1660, 1823, '_sale_price', '55') ; 
INSERT INTO `wp_postmeta` VALUES (1661, 1823, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1662, 1823, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1663, 1823, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1664, 1823, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1665, 1823, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1666, 1823, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1667, 1823, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1668, 1823, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1669, 1823, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1670, 1823, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1671, 1823, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1672, 1823, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1673, 1823, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1674, 1823, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1675, 1823, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1676, 1823, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1677, 1823, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1678, 1823, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1679, 1823, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1680, 1823, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1681, 1823, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1682, 1823, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1683, 1823, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1684, 1823, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1685, 1823, '_price', '55') ; 
INSERT INTO `wp_postmeta` VALUES (1686, 1824, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1687, 1824, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1688, 1824, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1689, 1824, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1690, 1824, '_regular_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1691, 1824, '_sale_price', '16') ; 
INSERT INTO `wp_postmeta` VALUES (1692, 1824, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1693, 1824, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1694, 1824, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1695, 1824, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1696, 1824, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1697, 1824, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1698, 1824, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1699, 1824, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1700, 1824, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1701, 1824, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1702, 1824, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1703, 1824, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1704, 1824, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1705, 1824, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1706, 1824, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1707, 1824, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1708, 1824, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1709, 1824, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1710, 1824, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1711, 1824, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1712, 1824, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1713, 1824, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1714, 1824, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1715, 1824, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1716, 1824, '_price', '16') ; 
INSERT INTO `wp_postmeta` VALUES (1717, 1825, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1718, 1825, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1719, 1825, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1720, 1825, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1721, 1825, '_regular_price', '90') ; 
INSERT INTO `wp_postmeta` VALUES (1722, 1825, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1723, 1825, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1724, 1825, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1725, 1825, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1726, 1825, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1727, 1825, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1728, 1825, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1729, 1825, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1730, 1825, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1731, 1825, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1732, 1825, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1733, 1825, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1734, 1825, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1735, 1825, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1736, 1825, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1737, 1825, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1738, 1825, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1739, 1825, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1740, 1825, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1741, 1825, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1742, 1825, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1743, 1825, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1744, 1825, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1745, 1825, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1746, 1825, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1747, 1825, '_price', '90') ; 
INSERT INTO `wp_postmeta` VALUES (1748, 1826, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1749, 1826, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1750, 1826, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1751, 1826, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1752, 1826, '_regular_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1753, 1826, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1754, 1826, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1755, 1826, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1756, 1826, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1757, 1826, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1758, 1826, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1759, 1826, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1760, 1826, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1761, 1826, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1762, 1826, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1763, 1826, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1764, 1826, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1765, 1826, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1766, 1826, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1767, 1826, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1768, 1826, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1769, 1826, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1770, 1826, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1771, 1826, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1772, 1826, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1773, 1826, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1774, 1826, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1775, 1826, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1776, 1826, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1777, 1826, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1778, 1826, '_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1779, 1827, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1780, 1827, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1781, 1827, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1782, 1827, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1783, 1827, '_regular_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1784, 1827, '_sale_price', '35') ; 
INSERT INTO `wp_postmeta` VALUES (1785, 1827, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1786, 1827, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1787, 1827, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1788, 1827, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1789, 1827, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1790, 1827, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1791, 1827, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1792, 1827, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1793, 1827, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1794, 1827, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1795, 1827, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1796, 1827, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1797, 1827, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1798, 1827, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1799, 1827, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1800, 1827, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1801, 1827, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1802, 1827, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1803, 1827, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1804, 1827, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1805, 1827, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1806, 1827, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1807, 1827, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1808, 1827, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1809, 1827, '_price', '35') ; 
INSERT INTO `wp_postmeta` VALUES (1810, 1828, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1811, 1828, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1812, 1828, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1813, 1828, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1814, 1828, '_regular_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1815, 1828, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1816, 1828, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1817, 1828, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1818, 1828, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1819, 1828, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1820, 1828, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1821, 1828, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1822, 1828, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1823, 1828, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1824, 1828, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1825, 1828, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1826, 1828, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1827, 1828, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1828, 1828, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1829, 1828, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1830, 1828, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1831, 1828, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1832, 1828, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1833, 1828, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1834, 1828, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1835, 1828, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1836, 1828, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1837, 1828, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1838, 1828, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1839, 1828, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1840, 1828, '_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1841, 1829, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1842, 1829, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1843, 1829, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1844, 1829, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1845, 1829, '_regular_price', '45') ; 
INSERT INTO `wp_postmeta` VALUES (1846, 1829, '_sale_price', '42') ; 
INSERT INTO `wp_postmeta` VALUES (1847, 1829, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1848, 1829, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1849, 1829, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1850, 1829, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1851, 1829, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1852, 1829, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1853, 1829, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1854, 1829, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1855, 1829, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1856, 1829, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1857, 1829, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1858, 1829, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1859, 1829, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1860, 1829, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1861, 1829, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1862, 1829, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1863, 1829, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1864, 1829, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1865, 1829, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1866, 1829, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1867, 1829, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1868, 1829, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1869, 1829, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1870, 1829, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1871, 1829, '_price', '42') ; 
INSERT INTO `wp_postmeta` VALUES (1872, 1830, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1873, 1830, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1874, 1830, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1875, 1830, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1876, 1830, '_regular_price', '25') ; 
INSERT INTO `wp_postmeta` VALUES (1877, 1830, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1878, 1830, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1879, 1830, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1880, 1830, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1881, 1830, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1882, 1830, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1883, 1830, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1884, 1830, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1885, 1830, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1886, 1830, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1887, 1830, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1888, 1830, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1889, 1830, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1890, 1830, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1891, 1830, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1892, 1830, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1893, 1830, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1894, 1830, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1895, 1830, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1896, 1830, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1897, 1830, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1898, 1830, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1899, 1830, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1900, 1830, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1901, 1830, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1902, 1830, '_price', '25') ; 
INSERT INTO `wp_postmeta` VALUES (1903, 1831, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1904, 1831, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1905, 1831, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1906, 1831, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1907, 1831, '_regular_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (1908, 1831, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1909, 1831, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1910, 1831, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1911, 1831, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1912, 1831, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1913, 1831, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1914, 1831, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1915, 1831, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1916, 1831, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1917, 1831, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1918, 1831, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1919, 1831, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1920, 1831, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1921, 1831, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1922, 1831, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1923, 1831, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1924, 1831, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1925, 1831, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1926, 1831, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1927, 1831, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1928, 1831, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1929, 1831, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1930, 1831, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1931, 1831, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1932, 1831, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1933, 1831, '_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (1934, 1832, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1935, 1832, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1936, 1832, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1937, 1832, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1938, 1832, '_regular_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1939, 1832, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1940, 1832, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1941, 1832, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1942, 1832, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1943, 1832, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1944, 1832, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1945, 1832, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1946, 1832, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1947, 1832, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1948, 1832, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1949, 1832, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1950, 1832, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1951, 1832, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1952, 1832, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1953, 1832, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1954, 1832, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1955, 1832, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1956, 1832, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1957, 1832, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1958, 1832, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1959, 1832, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1960, 1832, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1961, 1832, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1962, 1832, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1963, 1832, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1964, 1832, '_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1965, 1833, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1966, 1833, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1967, 1833, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1968, 1833, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (1969, 1833, '_regular_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1970, 1833, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (1971, 1833, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (1972, 1833, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (1973, 1833, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1974, 1833, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (1975, 1833, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (1976, 1833, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1977, 1833, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1978, 1833, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1979, 1833, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (1980, 1833, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (1981, 1833, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (1982, 1833, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (1983, 1833, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1984, 1833, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1985, 1833, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (1986, 1833, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1987, 1833, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1988, 1833, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (1989, 1833, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (1990, 1833, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1991, 1833, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (1992, 1833, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (1993, 1833, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (1994, 1833, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (1995, 1833, '_price', '18') ; 
INSERT INTO `wp_postmeta` VALUES (1996, 1835, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1997, 1835, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (1998, 1835, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1999, 1836, '_wp_attached_file', '2018/03/1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (2000, 1836, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:13:"2018/03/1.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:13:"1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:9:"thumbnail";a:4:{s:4:"file";s:13:"1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:13:"1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:13:"1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:5:{s:4:"file";s:13:"1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:14:"shop_thumbnail";a:4:{s:4:"file";s:13:"1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (2001, 1835, '_edit_lock', '1522035512:1') ; 
INSERT INTO `wp_postmeta` VALUES (2002, 1835, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2003, 1835, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2004, 1835, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2005, 1835, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2006, 1835, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2007, 1835, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2008, 1835, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2009, 1835, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2010, 1835, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2011, 1835, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2012, 1835, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2013, 1835, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2014, 1835, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2015, 1835, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2016, 1835, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2017, 1835, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2018, 1835, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2019, 1835, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2020, 1835, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2021, 1835, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2022, 1835, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2023, 1835, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2024, 1835, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2025, 1835, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2026, 1835, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2027, 1835, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2028, 1835, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2029, 1835, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2030, 1835, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2031, 1837, '_wp_attached_file', '2018/03/1-1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (2032, 1837, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:15:"2018/03/1-1.jpg";s:5:"sizes";a:6:{s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:15:"1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:9:"thumbnail";a:4:{s:4:"file";s:15:"1-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:15:"1-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:5:{s:4:"file";s:15:"1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"1-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (2033, 1835, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2034, 1838, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2035, 1838, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2036, 1838, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2037, 1838, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2038, 1838, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2039, 1838, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2040, 1838, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2041, 1838, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2042, 1838, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2043, 1838, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2044, 1838, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2045, 1838, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2046, 1838, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2047, 1838, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2048, 1838, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2049, 1838, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2050, 1838, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2051, 1838, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2052, 1838, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2053, 1838, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2054, 1838, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2055, 1838, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2056, 1838, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2057, 1838, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2058, 1838, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2059, 1838, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2060, 1838, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2061, 1838, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2062, 1838, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2063, 1838, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2064, 1838, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2065, 1838, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2066, 1838, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2067, 1838, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2068, 1838, '_edit_lock', '1522052216:1') ; 
INSERT INTO `wp_postmeta` VALUES (2069, 1838, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2070, 1839, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2071, 1839, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2072, 1839, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2073, 1839, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2074, 1839, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2075, 1839, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2076, 1839, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2077, 1839, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2078, 1839, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2079, 1839, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2080, 1839, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2081, 1839, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2082, 1839, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2083, 1839, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2084, 1839, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2085, 1839, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2086, 1839, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2087, 1839, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2088, 1839, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2089, 1839, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2090, 1839, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2091, 1839, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2092, 1839, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2093, 1839, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2094, 1839, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2095, 1839, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2096, 1839, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2097, 1839, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2098, 1839, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2099, 1839, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2100, 1839, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2101, 1839, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2102, 1839, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2103, 1839, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2104, 1839, '_edit_lock', '1522052207:1') ; 
INSERT INTO `wp_postmeta` VALUES (2105, 1839, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2106, 1840, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2107, 1840, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2108, 1840, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2109, 1840, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2110, 1840, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2111, 1840, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2112, 1840, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2113, 1840, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2114, 1840, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2115, 1840, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2116, 1840, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2117, 1840, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2118, 1840, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2119, 1840, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2120, 1840, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2121, 1840, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2122, 1840, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2123, 1840, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2124, 1840, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2125, 1840, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2126, 1840, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2127, 1840, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2128, 1840, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2129, 1840, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2130, 1840, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2131, 1840, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2132, 1840, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2133, 1840, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2134, 1840, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2135, 1840, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2136, 1840, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2137, 1840, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2138, 1840, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2139, 1840, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2140, 1840, '_edit_lock', '1522035425:1') ; 
INSERT INTO `wp_postmeta` VALUES (2141, 1840, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2142, 1841, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2143, 1841, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2144, 1841, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2145, 1841, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2146, 1841, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2147, 1841, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2148, 1841, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2149, 1841, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2150, 1841, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2151, 1841, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2152, 1841, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2153, 1841, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2154, 1841, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2155, 1841, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2156, 1841, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2157, 1841, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2158, 1841, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2159, 1841, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2160, 1841, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2161, 1841, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2162, 1841, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2163, 1841, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2164, 1841, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2165, 1841, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2166, 1841, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2167, 1841, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2168, 1841, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2169, 1841, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2170, 1841, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2171, 1841, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2172, 1841, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2173, 1841, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2174, 1841, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2175, 1841, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2176, 1841, '_edit_lock', '1522049832:1') ; 
INSERT INTO `wp_postmeta` VALUES (2177, 1841, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2178, 1842, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2179, 1842, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2180, 1842, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2181, 1842, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2182, 1842, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2183, 1842, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2184, 1842, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2185, 1842, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2186, 1842, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2187, 1842, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2188, 1842, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2189, 1842, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2190, 1842, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2191, 1842, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2192, 1842, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2193, 1842, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2194, 1842, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2195, 1842, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2196, 1842, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2197, 1842, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2198, 1842, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2199, 1842, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2200, 1842, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2201, 1842, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2202, 1842, '_thumbnail_id', '1837') ; 
INSERT INTO `wp_postmeta` VALUES (2203, 1842, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2204, 1842, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2205, 1842, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2206, 1842, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2207, 1842, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2208, 1842, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2209, 1842, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2210, 1842, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2211, 1842, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2212, 1842, '_edit_lock', '1522052155:1') ; 
INSERT INTO `wp_postmeta` VALUES (2213, 1842, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2214, 1843, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2215, 1843, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2216, 1843, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2217, 1843, '_edit_lock', '1522040152:1') ; 
INSERT INTO `wp_postmeta` VALUES (2218, 1844, '_edit_lock', '1522043628:1') ; 
INSERT INTO `wp_postmeta` VALUES (2219, 1844, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2220, 1844, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2221, 1846, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (2222, 1846, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2223, 1846, '_menu_item_object_id', '240') ; 
INSERT INTO `wp_postmeta` VALUES (2224, 1846, '_menu_item_object', 'product_cat') ; 
INSERT INTO `wp_postmeta` VALUES (2225, 1846, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (2226, 1846, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (2227, 1846, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (2228, 1846, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (2309, 1850, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2230, 1847, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (2231, 1847, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2232, 1847, '_menu_item_object_id', '242') ; 
INSERT INTO `wp_postmeta` VALUES (2233, 1847, '_menu_item_object', 'product_cat') ; 
INSERT INTO `wp_postmeta` VALUES (2234, 1847, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (2235, 1847, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (2236, 1847, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (2237, 1847, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (2308, 1850, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2239, 1848, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (2240, 1848, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2241, 1848, '_menu_item_object_id', '241') ; 
INSERT INTO `wp_postmeta` VALUES (2242, 1848, '_menu_item_object', 'product_cat') ; 
INSERT INTO `wp_postmeta` VALUES (2243, 1848, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (2244, 1848, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (2245, 1848, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (2246, 1848, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (2307, 1850, '_thumbnail_id', '1851') ; 
INSERT INTO `wp_postmeta` VALUES (2310, 1850, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2311, 1850, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2312, 1850, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2313, 1850, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2314, 1850, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2315, 1850, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2316, 1850, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2317, 1850, '_edit_lock', '1522052159:1') ; 
INSERT INTO `wp_postmeta` VALUES (2318, 1851, '_wp_attached_file', '2018/03/2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (2319, 1851, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:220;s:6:"height";i:220;s:4:"file";s:13:"2018/03/2.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:13:"mazpage_small";a:4:{s:4:"file";s:11:"2-80x60.jpg";s:5:"width";i:80;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:13:"2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:13:"2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (2320, 1850, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2321, 1852, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2322, 1852, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2323, 1852, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2324, 1852, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2325, 1852, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2326, 1852, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2327, 1852, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2328, 1852, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2329, 1852, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2330, 1852, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2331, 1852, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2332, 1852, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2333, 1852, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2334, 1852, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2335, 1852, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2336, 1852, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2337, 1852, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2338, 1852, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2339, 1852, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2340, 1852, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2341, 1852, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2342, 1852, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2343, 1852, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2344, 1852, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2345, 1852, '_thumbnail_id', '1851') ; 
INSERT INTO `wp_postmeta` VALUES (2346, 1852, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2347, 1852, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2348, 1852, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2349, 1852, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2350, 1852, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2351, 1852, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2352, 1852, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2353, 1852, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2354, 1852, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2355, 1852, '_edit_lock', '1522052211:1') ; 
INSERT INTO `wp_postmeta` VALUES (2356, 1852, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2357, 1853, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2358, 1853, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2359, 1853, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2360, 1853, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2361, 1853, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2362, 1853, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2363, 1853, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2364, 1853, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2365, 1853, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2366, 1853, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2367, 1853, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2368, 1853, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2369, 1853, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2370, 1853, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2371, 1853, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2372, 1853, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2373, 1853, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2374, 1853, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2375, 1853, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2376, 1853, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2377, 1853, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2378, 1853, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2379, 1853, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2380, 1853, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2381, 1853, '_thumbnail_id', '1851') ; 
INSERT INTO `wp_postmeta` VALUES (2382, 1853, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2383, 1853, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2384, 1853, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2385, 1853, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2386, 1853, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2387, 1853, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2388, 1853, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2389, 1853, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2390, 1853, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2391, 1853, '_edit_lock', '1522052241:1') ; 
INSERT INTO `wp_postmeta` VALUES (2392, 1853, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2393, 1854, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2394, 1854, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2395, 1854, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2396, 1854, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2397, 1854, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2398, 1854, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2399, 1854, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2400, 1854, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2401, 1854, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2402, 1854, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2403, 1854, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2404, 1854, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2405, 1854, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2406, 1854, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2407, 1854, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2408, 1854, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2409, 1854, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2410, 1854, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2411, 1854, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2412, 1854, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2413, 1854, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2414, 1854, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2415, 1854, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2416, 1854, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2417, 1854, '_thumbnail_id', '1851') ; 
INSERT INTO `wp_postmeta` VALUES (2418, 1854, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2419, 1854, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2420, 1854, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2421, 1854, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2422, 1854, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2423, 1854, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2424, 1854, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2425, 1854, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2426, 1854, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2427, 1854, '_edit_lock', '1522052265:1') ; 
INSERT INTO `wp_postmeta` VALUES (2428, 1854, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2429, 1855, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2430, 1855, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2431, 1855, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2432, 1855, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2433, 1855, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2434, 1855, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2435, 1855, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2436, 1855, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2437, 1855, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2438, 1855, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2439, 1855, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2440, 1855, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2441, 1855, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2442, 1855, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2443, 1855, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2444, 1855, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2445, 1855, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2446, 1855, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2447, 1855, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2448, 1855, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2449, 1855, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2450, 1855, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (2451, 1855, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2452, 1855, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2453, 1855, '_thumbnail_id', '1851') ; 
INSERT INTO `wp_postmeta` VALUES (2454, 1855, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2455, 1855, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2456, 1855, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2457, 1855, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2458, 1855, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2459, 1855, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2460, 1855, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2461, 1855, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2462, 1855, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2463, 1855, '_edit_lock', '1522052287:1') ; 
INSERT INTO `wp_postmeta` VALUES (2464, 1855, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2465, 1856, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2466, 1856, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2467, 1856, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2468, 1856, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2469, 1856, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2470, 1856, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2471, 1856, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2472, 1856, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2473, 1856, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2474, 1856, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2475, 1856, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2476, 1856, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2477, 1856, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2478, 1856, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2479, 1856, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2480, 1856, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2481, 1856, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2482, 1856, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2483, 1856, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2484, 1856, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2485, 1856, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2486, 1856, '_product_image_gallery', '1857') ; 
INSERT INTO `wp_postmeta` VALUES (2487, 1856, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2488, 1856, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2490, 1856, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2491, 1856, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2492, 1856, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2493, 1856, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2494, 1856, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2495, 1856, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2496, 1856, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2497, 1856, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2498, 1856, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2499, 1856, '_edit_lock', '1522053413:1') ; 
INSERT INTO `wp_postmeta` VALUES (2500, 1857, '_wp_attached_file', '2018/03/slider1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (2501, 1857, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1160;s:6:"height";i:423;s:4:"file";s:19:"2018/03/slider1.jpg";s:5:"sizes";a:13:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"slider1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"slider1-300x109.jpg";s:5:"width";i:300;s:6:"height";i:109;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"slider1-768x280.jpg";s:5:"width";i:768;s:6:"height";i:280;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"slider1-1024x373.jpg";s:5:"width";i:1024;s:6:"height";i:373;s:9:"mime-type";s:10:"image/jpeg";}s:17:"mazpage_landscape";a:4:{s:4:"file";s:20:"slider1-1000x423.jpg";s:5:"width";i:1000;s:6:"height";i:423;s:9:"mime-type";s:10:"image/jpeg";}s:13:"mazpage_small";a:4:{s:4:"file";s:17:"slider1-80x60.jpg";s:5:"width";i:80;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:14:"mazpage_nocrop";a:4:{s:4:"file";s:20:"slider1-1000x365.jpg";s:5:"width";i:1000;s:6:"height";i:365;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:19:"slider1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:19:"slider1-600x219.jpg";s:5:"width";i:600;s:6:"height";i:219;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:19:"slider1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"slider1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"slider1-600x219.jpg";s:5:"width";i:600;s:6:"height";i:219;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"slider1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (2502, 1856, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2503, 1858, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (2504, 1858, '_regular_price', '150000') ; 
INSERT INTO `wp_postmeta` VALUES (2505, 1858, '_sale_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2506, 1858, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (2507, 1858, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (2508, 1858, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2509, 1858, '_tax_status', 'taxable') ; 
INSERT INTO `wp_postmeta` VALUES (2510, 1858, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (2511, 1858, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2512, 1858, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2513, 1858, '_sold_individually', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2514, 1858, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (2515, 1858, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (2516, 1858, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (2517, 1858, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (2518, 1858, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2519, 1858, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2520, 1858, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (2521, 1858, '_default_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2522, 1858, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2523, 1858, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (2524, 1858, '_product_image_gallery', '1857') ; 
INSERT INTO `wp_postmeta` VALUES (2525, 1858, '_download_limit', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2526, 1858, '_download_expiry', '-1') ; 
INSERT INTO `wp_postmeta` VALUES (2527, 1858, '_stock', NULL) ; 
INSERT INTO `wp_postmeta` VALUES (2528, 1858, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (2529, 1858, '_wc_average_rating', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2530, 1858, '_wc_rating_count', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2531, 1858, '_wc_review_count', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2532, 1858, '_downloadable_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2533, 1858, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (2534, 1858, '_product_version', '3.3.4') ; 
INSERT INTO `wp_postmeta` VALUES (2535, 1858, '_price', '10000') ; 
INSERT INTO `wp_postmeta` VALUES (2536, 1858, '_edit_lock', '1522055096:1') ; 
INSERT INTO `wp_postmeta` VALUES (2537, 1858, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2538, 1858, '_thumbnail_id', '1857') ; 
INSERT INTO `wp_postmeta` VALUES (2539, 1859, '_wp_attached_file', '2018/03/logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (2540, 1859, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:305;s:6:"height";i:56;s:4:"file";s:16:"2018/03/logo.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"logo-150x56.png";s:5:"width";i:150;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"logo-300x55.png";s:5:"width";i:300;s:6:"height";i:55;s:9:"mime-type";s:9:"image/png";}s:13:"mazpage_small";a:4:{s:4:"file";s:14:"logo-80x56.png";s:5:"width";i:80;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:15:"logo-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:15:"logo-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:15:"logo-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"logo-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ; 
INSERT INTO `wp_postmeta` VALUES (2541, 1834, '_customize_restore_dismissed', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2542, 1860, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (2543, 1860, '_wp_trash_meta_time', '1522055265') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=1861 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (379 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2012-10-02 22:12:12', '2012-10-02 22:12:12', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-03-18 14:16:12', '2014-03-18 14:16:12', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2012-10-02 22:12:12', '2012-10-02 22:12:12', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickies to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://127.0.0.1:4001/wordpress/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-04-04 07:32:10', '2014-04-04 07:32:10', '', 94, 'http://127.0.0.1:4001/wordpress/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2008-08-02 19:52:26', '2008-08-03 00:52:26', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'publish', 'open', 'open', '', 'a-simple-post-with-text', '', '', '2008-08-02 19:52:26', '2008-08-03 00:52:26', '', 0, 'http://dev.danphilibin.com/wordpress/?p=22', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2008-09-02 19:52:17', '2008-09-03 00:52:17', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision', '', '', '2008-09-02 19:52:17', '2008-09-03 00:52:17', '', 5, 'http://dev.danphilibin.com/wordpress/?p=23', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2008-09-02 19:52:26', '2008-09-03 00:52:26', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision-2', '', '', '2008-09-02 19:52:26', '2008-09-03 00:52:26', '', 5, 'http://dev.danphilibin.com/wordpress/?p=52', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2008-09-11 15:12:39', '2008-09-11 20:12:39', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision', '', '', '2008-09-11 15:12:39', '2008-09-11 20:12:39', '', 26, 'http://dev.danphilibin.com/wordpress/?p=26', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2008-09-11 15:13:16', '2008-09-11 20:13:16', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision-2', '', '', '2008-09-11 15:13:16', '2008-09-11 20:13:16', '', 26, 'http://dev.danphilibin.com/wordpress/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2008-09-11 15:17:23', '2008-09-11 20:17:23', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="rigLorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-autosave', '', '', '2008-09-11 15:17:23', '2008-09-11 20:17:23', '', 26, 'http://dev.danphilibin.com/wordpress/?p=28', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2008-09-11 15:17:32', '2008-09-11 20:17:32', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision-3', '', '', '2008-09-11 15:17:32', '2008-09-11 20:17:32', '', 26, 'http://dev.danphilibin.com/wordpress/?p=49', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2008-09-11 19:19:53', '2008-09-12 00:19:53', '', 'Our Company', '', 'inherit', 'open', 'open', '', '30-revision', '', '', '2008-09-11 19:19:53', '2008-09-12 00:19:53', '', 13, 'http://dev.danphilibin.com/wordpress/?p=31', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2008-09-11 19:20:11', '2008-09-12 00:20:11', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Company', '', 'publish', 'open', 'open', '', 'our-company', '', '', '2008-09-11 19:20:11', '2008-09-12 00:20:11', '', 26, 'http://dev.danphilibin.com/wordpress/?page_id=30', 0, 'page', '', 1) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2008-09-11 19:20:21', '2008-09-12 00:20:21', '', 'Job Opportunities', '', 'inherit', 'open', 'open', '', '32-revision', '', '', '2008-09-11 19:20:21', '2008-09-12 00:20:21', '', 15, 'http://dev.danphilibin.com/wordpress/?p=33', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2008-09-11 19:20:29', '2008-09-12 00:20:29', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Staff', '', 'publish', 'open', 'open', '', 'our-staff', '', '', '2008-09-11 19:20:29', '2008-09-12 00:20:29', '', 26, 'http://dev.danphilibin.com/wordpress/?page_id=32', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2008-09-11 19:20:39', '2008-09-12 00:20:39', '', 'Company History', '', 'inherit', 'open', 'open', '', '34-revision', '', '', '2008-09-11 19:20:39', '2008-09-12 00:20:39', '', 18, 'http://dev.danphilibin.com/wordpress/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2008-09-11 19:20:42', '2008-09-12 00:20:42', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Company History', '', 'inherit', 'open', 'open', '', '34-revision-2', '', '', '2008-09-11 19:20:42', '2008-09-12 00:20:42', '', 18, 'http://dev.danphilibin.com/wordpress/?p=38', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2008-09-11 19:20:42', '2008-09-12 00:20:42', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'History', '', 'publish', 'open', 'open', '', 'company-history', '', '', '2008-09-11 19:20:42', '2008-09-12 00:20:42', '', 26, 'http://dev.danphilibin.com/wordpress/?page_id=34', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2008-09-11 19:20:49', '2008-09-12 00:20:49', '', 'Support', '', 'inherit', 'open', 'open', '', '36-revision', '', '', '2008-09-11 19:20:49', '2008-09-12 00:20:49', '', 20, 'http://dev.danphilibin.com/wordpress/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2008-09-11 19:20:52', '2008-09-12 00:20:52', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Support', '', 'publish', 'open', 'open', '', 'support', '', '', '2008-09-11 19:20:52', '2008-09-12 00:20:52', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=36', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2008-09-11 19:22:00', '2008-09-12 00:22:00', '', 'Links', '', 'inherit', 'open', 'open', '', '39-revision', '', '', '2008-09-11 19:22:00', '2008-09-12 00:22:00', '', 22, 'http://dev.danphilibin.com/wordpress/?p=40', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2008-09-11 19:22:03', '2008-09-12 00:22:03', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Links', '', 'publish', 'open', 'open', '', 'links', '', '', '2008-09-11 19:22:03', '2008-09-12 00:22:03', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=39', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2008-09-11 19:22:17', '2008-09-12 00:22:17', '', 'Contact Us', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2008-09-11 19:22:17', '2008-09-12 00:22:17', '', 24, 'http://dev.danphilibin.com/wordpress/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2008-09-11 19:22:18', '2008-09-12 00:22:18', 'This is a full-width page. It doesn\'t look very nice but I had to try.

<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/978a9ee060efba987bd79e77e57fede1.jpg"><img class="aligncenter size-full wp-image-117" alt="978a9ee060efba987bd79e77e57fede1" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/978a9ee060efba987bd79e77e57fede1.jpg" width="500" height="500" /></a>', 'Contact Us', '', 'publish', 'open', 'open', '', 'contact-us', '', '', '2014-03-17 14:02:41', '2014-03-17 14:02:41', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=41', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2008-09-11 19:23:57', '2008-09-12 00:23:57', '', 'News', '', 'inherit', 'open', 'open', '', '43-revision', '', '', '2008-09-11 19:23:57', '2008-09-12 00:23:57', '', 26, 'http://dev.danphilibin.com/wordpress/?p=44', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2008-09-11 19:24:01', '2008-09-12 00:24:01', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'News', '', 'publish', 'open', 'open', '', 'news', '', '', '2008-09-11 19:24:01', '2008-09-12 00:24:01', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=43', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2008-09-11 19:24:20', '2008-09-12 00:24:20', '', 'Our Location', '', 'inherit', 'open', 'open', '', '45-revision', '', '', '2008-09-11 19:24:20', '2008-09-12 00:24:20', '', 28, 'http://dev.danphilibin.com/wordpress/?p=46', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2008-09-11 19:24:31', '2008-09-12 00:24:31', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.', 'Our Location', '', 'publish', 'open', 'open', '', 'our-location', '', '', '2008-09-11 19:24:31', '2008-09-12 00:24:31', '', 24, 'http://dev.danphilibin.com/wordpress/?page_id=45', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2008-09-11 19:24:52', '2008-09-12 00:24:52', '', 'Employment Opportunities', '', 'inherit', 'open', 'open', '', '47-revision', '', '', '2008-09-11 19:24:52', '2008-09-12 00:24:52', '', 30, 'http://dev.danphilibin.com/wordpress/?p=48', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2008-09-11 19:24:58', '2008-09-12 00:24:58', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Employment Opportunities', '', 'publish', 'open', 'open', '', 'employment-opportunities', '', '', '2008-09-11 19:24:58', '2008-09-12 00:24:58', '', 15, 'http://dev.danphilibin.com/wordpress/?page_id=47', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2008-09-11 22:13:41', '2008-09-12 03:13:41', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>', 'A Post With an Unordered List', '', 'inherit', 'open', 'open', '', '50-revision', '', '', '2008-09-11 22:13:41', '2008-09-12 03:13:41', '', 32, 'http://dev.danphilibin.com/wordpress/?p=51', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2008-09-11 22:14:00', '2008-09-12 03:14:00', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>', 'A Post With an Unordered List', '', 'publish', 'open', 'open', '', 'a-post-with-an-unordered-list', '', '', '2008-09-11 22:14:00', '2008-09-12 03:14:00', '', 0, 'http://dev.danphilibin.com/wordpress/?p=50', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2008-09-11 22:14:45', '2008-09-12 03:14:45', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision-3', '', '', '2008-09-11 22:14:45', '2008-09-12 03:14:45', '', 5, 'http://dev.danphilibin.com/wordpress/?p=65', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2008-09-11 22:15:57', '2008-09-12 03:15:57', '', 'A Post With a Right-Aligned Image', '', 'inherit', 'open', 'open', '', '53-revision', '', '', '2008-09-11 22:15:57', '2008-09-12 03:15:57', '', 35, 'http://dev.danphilibin.com/wordpress/?p=54', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2008-09-11 22:19:25', '2008-09-12 03:19:25', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.  <!--more-->

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Right-Aligned Image', '', 'publish', 'open', 'open', '', 'a-post-with-a-right-aligned-image', '', '', '2008-09-11 22:19:25', '2008-09-12 03:19:25', '', 0, 'http://dev.danphilibin.com/wordpress/?p=53', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2008-09-11 22:19:48', '2008-09-12 03:19:48', '', 'A Post With an Ordered List', '', 'inherit', 'open', 'open', '', '55-revision', '', '', '2008-09-11 22:19:48', '2008-09-12 03:19:48', '', 37, 'http://dev.danphilibin.com/wordpress/?p=56', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2008-09-11 22:20:17', '2008-09-12 03:20:17', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With an Ordered List', '', 'publish', 'open', 'open', '', 'a-post-with-an-ordered-list', '', '', '2008-09-11 22:20:17', '2008-09-12 03:20:17', '', 0, 'http://dev.danphilibin.com/wordpress/?p=55', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2008-09-11 22:20:32', '2008-09-12 03:20:32', '', 'Another Text-Only Post', '', 'inherit', 'open', 'open', '', '57-revision', '', '', '2008-09-11 22:20:32', '2008-09-12 03:20:32', '', 39, 'http://dev.danphilibin.com/wordpress/?p=58', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2008-09-11 22:20:39', '2008-09-12 03:20:39', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'Another Text-Only Post', '', 'publish', 'open', 'open', '', 'another-text-only-post', '', '', '2008-09-11 22:20:39', '2008-09-12 03:20:39', '', 0, 'http://dev.danphilibin.com/wordpress/?p=57', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2008-09-11 22:22:54', '2008-09-12 03:22:54', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Left-Aligned Image', '', 'inherit', 'open', 'open', '', '59-revision', '', '', '2008-09-11 22:22:54', '2008-09-12 03:22:54', '', 41, 'http://dev.danphilibin.com/wordpress/?p=60', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2008-09-11 22:23:11', '2008-09-12 03:23:11', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Left-Aligned Image', '', 'publish', 'open', 'open', '', 'a-post-with-a-left-aligned-image', '', '', '2008-09-11 22:23:11', '2008-09-12 03:23:11', '', 0, 'http://dev.danphilibin.com/wordpress/?p=59', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2008-09-11 22:23:36', '2008-09-12 03:23:36', '', 'Quotes Time!', '', 'inherit', 'open', 'open', '', '61-revision', '', '', '2008-09-11 22:23:36', '2008-09-12 03:23:36', '', 43, 'http://dev.danphilibin.com/wordpress/?p=62', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2008-09-11 22:24:01', '2008-09-12 03:24:01', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>', 'Quotes Time!', '', 'publish', 'open', 'open', '', 'quotes-time', '', '', '2008-09-11 22:24:01', '2008-09-12 03:24:01', '', 0, 'http://dev.danphilibin.com/wordpress/?p=61', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2008-09-11 22:25:19', '2008-09-12 03:25:19', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '63-revision', '', '', '2008-09-11 22:25:19', '2008-09-12 03:25:19', '', 45, 'http://dev.danphilibin.com/wordpress/?p=64', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2008-09-11 22:25:45', '2008-09-12 03:25:45', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat. <!--more-->

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'publish', 'open', 'open', '', 'a-post-with-everything-in-it', '', '', '2008-09-11 22:25:45', '2008-09-12 03:25:45', '', 0, 'http://dev.danphilibin.com/wordpress/?p=63', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2008-09-11 22:25:45', '2008-09-12 03:25:45', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

<h3>Image with no alignment</h3>

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo"  />

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '44-revision', '', '', '2008-09-11 22:25:45', '2008-09-12 03:25:45', '', 45, 'http://dev.wpcoder.com/dan/wordpress/2008/09/44-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world-2', '', '', '2014-03-18 14:15:15', '2014-03-18 14:15:15', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=1', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2008-09-17 16:53:25', '2008-09-17 21:53:25', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2008-09-17 17:08:29', '2008-09-17 22:08:29', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Text Post', '', 'inherit', 'open', 'open', '', '45-revision-v1', '', '', '2008-09-17 17:08:29', '2008-09-17 22:08:29', '', 55, 'http://dev.wpcoder.com/dan/wordpress/2008/09/45-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2008-09-17 17:08:48', '2008-09-17 22:08:48', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Text Post', '', 'publish', 'open', 'open', '', 'a-simple-text-post', '', '', '2014-03-18 13:59:39', '2014-03-18 13:59:39', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=45', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2008-09-17 17:09:10', '2008-09-17 22:09:10', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '4-autosave', '', '', '2008-09-17 17:09:10', '2008-09-17 22:09:10', '', 5, 'http://dev.wpcoder.com/dan/wordpress/2008/09/4-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2008-09-17 17:09:14', '2008-09-17 22:09:14', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With an Ordered List', '', 'inherit', 'open', 'open', '', '36-autosave', '', '', '2008-09-17 17:09:14', '2008-09-17 22:09:14', '', 37, 'http://dev.wpcoder.com/dan/wordpress/2008/09/36-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2008-09-17 17:09:16', '2008-09-17 22:09:16', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.
<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '44-autosave', '', '', '2008-09-17 17:09:16', '2008-09-17 22:09:16', '', 45, 'http://dev.wpcoder.com/dan/wordpress/2008/09/44-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2008-09-17 17:09:38', '2008-09-17 22:09:38', '', 'An Ordered List Post', '', 'inherit', 'open', 'open', '', '50-revision-2', '', '', '2008-09-17 17:09:38', '2008-09-17 22:09:38', '', 50, 'http://dev.wpcoder.com/dan/wordpress/2008/09/50-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2008-09-17 17:09:41', '2008-09-17 22:09:41', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'An Ordered List Post', '', 'publish', 'open', 'open', '', 'an-ordered-list-post', '', '', '2008-09-17 17:09:41', '2008-09-17 22:09:41', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=50', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2008-09-17 17:10:16', '2008-09-17 22:10:16', '', 'Another Post with Everything In It', '', 'inherit', 'open', 'open', '', '53-revision-2', '', '', '2008-09-17 17:10:16', '2008-09-17 22:10:16', '', 57, 'http://dev.wpcoder.com/dan/wordpress/2008/09/53-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2008-09-17 17:10:52', '2008-09-17 22:10:52', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat. <!--more-->

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'Another Post with Everything In It', '', 'publish', 'open', 'open', '', 'another-post-with-everything-in-it', '', '', '2008-09-17 17:10:52', '2008-09-17 22:10:52', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=53', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2008-09-17 17:10:52', '2008-09-17 22:10:52', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, convallis quis, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

 Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.

Quote Source
Level 1 Heading
Level 2 Heading
Level 3 Heading
Level 4 Heading
Level 5 Heading
Level 6 Heading
An Unordered List

    * Vestibulum in mauris semper tortor interdum ultrices.
    * Sed vel lorem et justo laoreet bibendum. Donec dictum.
    * Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.
    * Praesent volutpat eros quis enim blandit tincidunt.
    * Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.

Image with no alignment

WordPress Logo

<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
An Ordered List

   1. Vestibulum in mauris semper tortor interdum ultrices.
   2. Sed vel lorem et justo laoreet bibendum. Donec dictum.
   3. Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.
   4. Praesent volutpat eros quis enim blandit tincidunt.
   5. Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.
', 'Another Post with Everything In It', '', 'inherit', 'open', 'open', '', '53-revision-2-2', '', '', '2008-09-17 17:10:52', '2008-09-17 22:10:52', '', 57, 'http://dev.wpcoder.com/dan/wordpress/2008/09/53-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1850, 1, '2018-03-26 11:17:02', '2018-03-26 08:17:02', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'rubic go thong minh', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'rubic-go-thong-minh', '', '', '2018-03-26 11:18:16', '2018-03-26 08:18:16', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1850', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1765, 1, '2014-05-15 07:20:04', '2014-05-15 07:20:04', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg', 'cropped-1979900_10152288225475210_8872398524763230616_o.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-1979900_10152288225475210_8872398524763230616_o-jpg', '', '', '2014-05-15 07:20:04', '2014-05-15 07:20:04', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-1979900_10152288225475210_8872398524763230616_o.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<img alt="" src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" />

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Image Post', '', 'publish', 'open', 'open', '', 'image-post', '', '', '2014-04-04 13:43:44', '2014-04-04 13:43:44', '', 0, 'http://127.0.0.1:4001/wordpress/image-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<ul>
	<li>First Item</li>
	<li>Second Item</li>
	<li>Third Item</li>
	<li>Fourth Item</li>
	<li>Fifth Item</li>
</ul>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<ol>
	<li>First Item</li>
	<li>Second Item</li>
	<li>Third Item</li>
	<li>Fourth Item</li>
	<li>Fifth Item</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'UL and OL Post', '', 'publish', 'open', 'open', '', 'ul-and-ol-post', '', '', '2014-06-26 09:45:54', '2014-06-26 09:45:54', '', 0, 'http://127.0.0.1:4001/wordpress/ul-and-ol-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Blockquote Post', '', 'publish', 'open', 'open', '', 'blockquote-post', '', '', '2014-05-15 08:08:51', '2014-05-15 08:08:51', '', 0, 'http://127.0.0.1:4001/wordpress/blockquote-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Post', '', 'publish', 'open', 'open', '', 'multiple-paragraph-post', '', '', '2014-04-04 13:39:28', '2014-04-04 13:39:28', '', 0, 'http://127.0.0.1:4001/wordpress/multiple-paragraph-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Post', '', 'publish', 'open', 'open', '', 'links-post', '', '', '2014-06-26 09:46:31', '2014-06-26 09:46:31', '', 0, 'http://127.0.0.1:4001/wordpress/links-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Post', '', 'publish', 'open', 'open', '', 'headers-post', '', '', '2014-06-26 09:46:12', '2014-06-26 09:46:12', '', 0, 'http://127.0.0.1:4001/wordpress/headers-post/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Page', '', 'publish', 'open', 'open', '', 'multiple-paragraph-page', '', '', '2014-04-01 08:53:19', '2014-04-01 08:53:19', '', 0, 'http://127.0.0.1:4001/wordpress/multiple-paragraph-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><img src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" /><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Image Page', '', 'publish', 'open', 'open', '', 'image-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 0, 'http://127.0.0.1:4001/wordpress/image-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ul><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ul><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ol><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ol><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'UL and OL Page', '', 'publish', 'open', 'open', '', 'ul-and-ol-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 0, 'http://127.0.0.1:4001/wordpress/ul-and-ol-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Blockquote Page', '', 'publish', 'open', 'open', '', 'blockquote-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 0, 'http://127.0.0.1:4001/wordpress/blockquote-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Page', '', 'publish', 'open', 'open', '', 'links-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 0, 'http://127.0.0.1:4001/wordpress/links-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Page', '', 'publish', 'open', 'open', '', 'headers-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 0, 'http://127.0.0.1:4001/wordpress/headers-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Child Page', '', 'publish', 'open', 'open', '', 'child-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 95, 'http://127.0.0.1:4001/wordpress/image-page/child-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-02-10 15:13:02', '2014-02-10 15:13:02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Grandchild Page', '', 'publish', 'open', 'open', '', 'grandchild-page', '', '', '2014-02-10 15:13:02', '2014-02-10 15:13:02', '', 100, 'http://127.0.0.1:4001/wordpress/image-page/child-page/grandchild-page/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-02-11 10:33:30', '2014-02-11 10:33:30', '[caption id="attachment_106" align="alignleft" width="150"]<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image.jpg"><br /><img class="size-thumbnail wp-image-106  " alt="another-image" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image-150x150.jpg" width="150" height="150" /></a> I am a caption[/caption]

Аз съм малко съдържанийце.', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-02-27 10:50:08', '2014-02-27 10:50:08', '', 0, 'http://127.0.0.1:4001/wordpress/?page_id=102', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-02-11 10:33:30', '2014-02-11 10:33:30', '', 'Home', '', 'inherit', 'open', 'open', '', '102-revision-v1', '', '', '2014-02-11 10:33:30', '2014-02-11 10:33:30', '', 102, 'http://127.0.0.1:4001/wordpress/102-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-02-11 10:57:35', '2014-02-11 10:57:35', 'Аз съм малко съдържанийце.', 'Home', '', 'inherit', 'open', 'open', '', '102-revision-v1', '', '', '2014-02-11 10:57:35', '2014-02-11 10:57:35', '', 102, 'http://127.0.0.1:4001/wordpress/102-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-02-11 10:43:15', '2014-02-11 10:43:15', 'This is the content of the post. On an archive page it might be an excerpt of the post or you might include the entire content.', 'Home', '', 'inherit', 'open', 'open', '', '102-revision-v1', '', '', '2014-02-11 10:43:15', '2014-02-11 10:43:15', '', 102, 'http://127.0.0.1:4001/wordpress/102-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-02-11 11:03:19', '2014-02-11 11:03:19', '', 'another-image', '', 'inherit', 'open', 'open', '', 'another-image', '', '', '2014-02-11 11:03:19', '2014-02-11 11:03:19', '', 102, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-02-27 10:51:14', '2014-02-27 10:51:14', '[caption id="attachment_106" align="alignleft" width="150"]<img class="size-thumbnail wp-image-106  " alt="another-image" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image-150x150.jpg" width="150" height="150" /> I am a caption[/caption]

Аз съм малко съдържанийце.', 'Home', '', 'inherit', 'open', 'open', '', '102-autosave-v1', '', '', '2014-02-27 10:51:14', '2014-02-27 10:51:14', '', 102, 'http://127.0.0.1:4001/wordpress/102-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-02-11 11:04:09', '2014-02-11 11:04:09', 'Аз съм малко съдържанийце.

[caption id="attachment_106" align="alignleft" width="150"]<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image.jpg"><img class="size-thumbnail wp-image-106 " alt="another-image" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image-150x150.jpg" width="150" height="150" /></a> I am a caption[/caption]', 'Home', '', 'inherit', 'open', 'open', '', '102-revision-v1', '', '', '2014-02-11 11:04:09', '2014-02-11 11:04:09', '', 102, 'http://127.0.0.1:4001/wordpress/102-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-02-11 14:30:31', '2014-02-11 14:30:31', ' ', '', '', 'publish', 'open', 'open', '', '110', '', '', '2014-02-11 14:32:00', '2014-02-11 14:32:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=110', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-02-11 14:30:31', '2014-02-11 14:30:31', ' ', '', '', 'publish', 'open', 'open', '', '111', '', '', '2014-02-11 14:32:00', '2014-02-11 14:32:00', '', 95, 'http://127.0.0.1:4001/wordpress/?p=111', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-02-11 14:30:31', '2014-02-11 14:30:31', ' ', '', '', 'publish', 'open', 'open', '', '112', '', '', '2014-02-11 14:32:00', '2014-02-11 14:32:00', '', 100, 'http://127.0.0.1:4001/wordpress/?p=112', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-02-27 10:50:08', '2014-02-27 10:50:08', '[caption id="attachment_106" align="alignleft" width="150"]<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image.jpg"><br /><img class="size-thumbnail wp-image-106  " alt="another-image" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/another-image-150x150.jpg" width="150" height="150" /></a> I am a caption[/caption]

Аз съм малко съдържанийце.', 'Home', '', 'inherit', 'open', 'open', '', '102-revision-v1', '', '', '2014-02-27 10:50:08', '2014-02-27 10:50:08', '', 102, 'http://127.0.0.1:4001/wordpress/102-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-03-17 14:00:47', '2014-03-17 14:00:47', 'This is a full-width page. It doesn\'t look very nice but I had to try.

&nbsp;', 'Contact Us', '', 'inherit', 'open', 'open', '', '24-autosave-v1', '', '', '2014-03-17 14:00:47', '2014-03-17 14:00:47', '', 24, 'http://127.0.0.1:4001/wordpress/24-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-03-17 14:00:55', '2014-03-17 14:00:55', '', '978a9ee060efba987bd79e77e57fede1', '', 'inherit', 'open', 'open', '', '978a9ee060efba987bd79e77e57fede1', '', '', '2014-03-17 14:00:55', '2014-03-17 14:00:55', '', 24, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/978a9ee060efba987bd79e77e57fede1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-03-17 14:01:34', '2014-03-17 14:01:34', 'This is a full-width page. It doesn\'t look very nice but I had to try.

<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/978a9ee060efba987bd79e77e57fede1.jpg"><img class="aligncenter size-full wp-image-117" alt="978a9ee060efba987bd79e77e57fede1" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/978a9ee060efba987bd79e77e57fede1.jpg" width="500" height="500" /></a>', 'Contact Us', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-03-17 14:01:34', '2014-03-17 14:01:34', '', 24, 'http://127.0.0.1:4001/wordpress/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-03-18 13:58:39', '2014-03-18 13:58:39', '', 'Koala', 'I am a koala', 'inherit', 'open', 'open', '', 'koala', '', '', '2014-03-18 13:58:39', '2014-03-18 13:58:39', '', 53, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/Koala.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-03-18 13:58:55', '2014-03-18 13:58:55', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '53-revision-v1', '', '', '2014-03-18 13:58:55', '2014-03-18 13:58:55', '', 53, 'http://127.0.0.1:4001/wordpress/53-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-03-18 13:59:33', '2014-03-18 13:59:33', '', 'acanthamoeba', '', 'inherit', 'open', 'open', '', 'acanthamoeba', '', '', '2014-03-18 13:59:33', '2014-03-18 13:59:33', '', 55, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2008/09/acanthamoeba.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2008-09-17 17:08:48', '2008-09-17 22:08:48', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Text Post', '', 'inherit', 'open', 'open', '', '55-revision-v1', '', '', '2008-09-17 17:08:48', '2008-09-17 22:08:48', '', 55, 'http://127.0.0.1:4001/wordpress/55-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-03-18 14:00:03', '2014-03-18 14:00:03', '', '4508_1052588806268_1572224486_30132277_7137063_n', '', 'inherit', 'open', 'open', '', '4508_1052588806268_1572224486_30132277_7137063_n', '', '', '2014-03-18 14:00:03', '2014-03-18 14:00:03', '', 88, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/4508_1052588806268_1572224486_30132277_7137063_n.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-03-18 14:00:07', '2014-03-18 14:00:07', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Post', '', 'inherit', 'open', 'open', '', '88-revision-v1', '', '', '2014-03-18 14:00:07', '2014-03-18 14:00:07', '', 88, 'http://127.0.0.1:4001/wordpress/88-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-03-18 14:00:39', '2014-03-18 14:00:39', '', '220px-Pepper-heart', '', 'inherit', 'open', 'open', '', '220px-pepper-heart', '', '', '2014-03-18 14:00:39', '2014-03-18 14:00:39', '', 90, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/220px-Pepper-heart.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-03-18 14:00:43', '2014-03-18 14:00:43', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<ul>
	<li>First Item</li>
	<li>Second Item</li>
	<li>Third Item</li>
	<li>Fourth Item</li>
	<li>Fifth Item</li>
</ul>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<ol>
	<li>First Item</li>
	<li>Second Item</li>
	<li>Third Item</li>
	<li>Fourth Item</li>
	<li>Fifth Item</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'UL and OL Post', '', 'inherit', 'open', 'open', '', '90-revision-v1', '', '', '2014-03-18 14:00:43', '2014-03-18 14:00:43', '', 90, 'http://127.0.0.1:4001/wordpress/90-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-03-18 14:01:05', '2014-03-18 14:01:05', '', 'IMG_2579', '', 'inherit', 'open', 'open', '', 'img_2579', '', '', '2014-03-18 14:01:05', '2014-03-18 14:01:05', '', 91, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/IMG_2579.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-03-18 14:01:10', '2014-03-18 14:01:10', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Blockquote Post', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-03-18 14:01:10', '2014-03-18 14:01:10', '', 91, 'http://127.0.0.1:4001/wordpress/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1762, 1, '2014-05-14 13:42:56', '2014-05-14 13:42:56', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-574902_10151411832829813_1669317567_n.jpg', 'cropped-574902_10151411832829813_1669317567_n.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-574902_10151411832829813_1669317567_n-jpg', '', '', '2014-05-14 13:42:56', '2014-05-14 13:42:56', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-574902_10151411832829813_1669317567_n.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-03-18 14:16:07', '2014-03-18 14:16:07', '', '4548422124_32bb76e36b', '', 'inherit', 'open', 'open', '', '4548422124_32bb76e36b', '', '', '2014-03-18 14:16:07', '2014-03-18 14:16:07', '', 1, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/10/4548422124_32bb76e36b.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-03-18 14:16:12', '2014-03-18 14:16:12', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-03-18 14:16:12', '2014-03-18 14:16:12', '', 1, 'http://127.0.0.1:4001/wordpress/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-03-18 15:03:39', '2014-03-18 15:03:39', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Blockquote Post', '', 'inherit', 'open', 'open', '', '91-autosave-v1', '', '', '2014-03-18 15:03:39', '2014-03-18 15:03:39', '', 91, 'http://127.0.0.1:4001/wordpress/91-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-03-18 15:03:41', '2014-03-18 15:03:41', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Blockquote Post', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-03-18 15:03:41', '2014-03-18 15:03:41', '', 91, 'http://127.0.0.1:4001/wordpress/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2010-07-25 19:40:01', '2010-07-26 02:40:01', 'This site is using the standard WordPress Theme Unit Test Data for content. The Theme Unit Test is a series of posts and pages that match up with a checklist on the WordPress codex. You can use the data and checklist together to test your theme.

<h2>WordPress Theme Development Resources</h2>

<ol>
	<li>See <a href="http://codex.wordpress.org/Theme_Development">Theme Development</a> for <a href="http://codex.wordpress.org/Theme_Development#Code_Standards">code standards</a>, examples of best practices, and <a href="http://codex.wordpress.org/Theme_Development#Resources_and_References">resources for Theme development</a>.</li>
	<li>See <a href="http://codex.wordpress.org/Theme_Unit_Test">Theme Unit Test</a> for a robust test suite for your Theme and get the latest version of the test data you see here.</li>
	<li>See <a href="http://codex.wordpress.org/Theme_Review">Theme Review</a> for a guide to submitting your Theme to the <a href="http://wordpress.org/extend/themes/">Themes Directory</a>.</li>
</ol>', 'About The Tests', '', 'publish', 'closed', 'closed', '', 'about-2', '', '', '2010-07-25 19:40:01', '2010-07-26 02:40:01', '', 0, 'http://wpthemetestdata.wordpress.com/about/', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2007-09-04 09:52:50', '2007-09-04 16:52:50', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec mollis. Quisque convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravida id, odio. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna. Praesent sit amet ligula id orci venenatis auctor. Phasellus porttitor, metus non tincidunt dapibus, orci pede pretium neque, sit amet adipiscing ipsum lectus et libero. Aenean bibendum. Curabitur mattis quam id urna. Vivamus dui. Donec nonummy lacinia lorem. Cras risus arcu, sodales ac, ultrices ac, mollis quis, justo. Sed a libero. Quisque risus erat, posuere at, tristique non, lacinia quis, eros.

Cras volutpat, lacus quis semper pharetra, nisi enim dignissim est, et sollicitudin quam ipsum vel mi. Sed commodo urna ac urna. Nullam eu tortor. Curabitur sodales scelerisque magna. Donec ultricies tristique pede. Nullam libero. Nam sollicitudin felis vel metus. Nullam posuere molestie metus. Nullam molestie, nunc id suscipit rhoncus, felis mi vulputate lacus, a ultrices tortor dolor eget augue. Aenean ultricies felis ut turpis. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse placerat tellus ac nulla. Proin adipiscing sem ac risus. Maecenas nisi. Cras semper.

Praesent interdum mollis neque. In egestas nulla eget pede. Integer eu purus sed diam dictum scelerisque. Morbi cursus velit et felis. Maecenas faucibus aliquet erat. In aliquet rhoncus tellus. Integer auctor nibh a nunc fringilla tempus. Cras turpis urna, dignissim vel, suscipit pulvinar, rutrum quis, sem. Ut lobortis convallis dui. Sed nonummy orci a justo. Morbi nec diam eget eros eleifend tincidunt.

Curabitur non elit. Pellentesque iaculis, nisl non aliquet adipiscing, purus urna aliquet orci, sed sodales pede neque at massa. Pellentesque laoreet, enim eget varius mollis, sapien erat suscipit metus, sit amet iaculis nulla sapien id felis. Aliquam erat volutpat. Nam congue nulla a ligula. Morbi tempor hendrerit erat. Curabitur augue. Vestibulum nulla est, commodo et, fringilla quis, bibendum eget, ipsum. Suspendisse pulvinar iaculis ante. Mauris dignissim ante quis nisi. Aliquam ante mi, aliquam et, pellentesque ac, dapibus et, enim. In vulputate justo vel magna. Phasellus imperdiet justo. Proin odio orci, dapibus id, porta a, pellentesque id, erat. Aliquam erat volutpat. Mauris nonummy varius libero. Sed dolor ipsum, tempor non, aliquet et, pulvinar quis, dui. Pellentesque mauris diam, lobortis id, varius varius, facilisis at, nulla.

Cras pede. Nullam id velit sit amet turpis tincidunt sagittis. Nunc malesuada. Nunc consequat scelerisque odio. Donec eu leo. Nunc pellentesque felis sed odio. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vivamus lobortis metus in lectus. Cras mollis quam eget sapien. Pellentesque non lorem sit amet sem lacinia euismod.

Nulla eget diam eget leo imperdiet consequat. Morbi nunc magna, pellentesque eu, porta at, ultricies ut, neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In tincidunt. Praesent ut orci id eros congue ultrices. Mauris non neque. Donec nulla ante, molestie sit amet, fermentum nec, blandit sit amet, purus. Fusce eget diam eu odio iaculis mollis. Phasellus consectetuer pede quis nisi. Proin non sem ut elit pulvinar faucibus. In a turpis nec augue fringilla elementum.

Nullam felis. Donec in nulla. Suspendisse sodales, turpis in suscipit ullamcorper, enim nunc sagittis risus, eu auctor velit tortor ut turpis. Mauris id augue at neque aliquam eleifend. Sed eget augue. Nunc faucibus ligula sed massa. Etiam non nulla. Etiam accumsan ullamcorper nisl. In pharetra massa at nunc. Nunc elementum. Duis sodales enim nec libero. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent dapibus eros sodales urna. Duis magna nisi, lobortis quis, tincidunt rutrum, posuere non, ipsum.

Aliquam convallis neque vitae diam. In diam. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis fermentum arcu in tortor. Sed nibh leo, rhoncus eu, fermentum et, scelerisque ac, massa. Cras id turpis. Etiam commodo sem luctus lorem. Morbi at mi. In rutrum. Aenean luctus pede euismod tortor. Phasellus dictum. Cras neque justo, venenatis sit amet, tristique et, vulputate in, dui. Etiam sed mi gravida sapien imperdiet dictum. Aliquam gravida orci a tortor. Donec tempor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus risus ante, pellentesque vitae, luctus eget, scelerisque sed, libero. Donec massa.

Donec libero mauris, volutpat at, convallis vel, laoreet euismod, augue. In accumsan malesuada risus. Mauris metus magna, condimentum in, nonummy non, ornare eu, velit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin posuere. Proin rhoncus rutrum lorem. Phasellus dignissim massa non libero volutpat tincidunt. In hac habitasse platea dictumst. Phasellus eget eros. Nulla in nulla. Vivamus quis mauris. Maecenas pharetra rhoncus tellus. Sed sit amet lacus.

Quisque interdum felis a tellus. Aliquam sed diam ac velit aliquam rutrum. Morbi commodo, risus a pulvinar adipiscing, tortor pede posuere risus, ac ornare tellus massa nec lectus. Vivamus mollis metus ac sapien. Nam sed est a libero ullamcorper dapibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean a erat ac nibh accumsan volutpat. Phasellus pulvinar consequat turpis. Curabitur ante metus, tempus ut, consequat eu, sollicitudin sit amet, justo. Duis ut libero.

Հայերեն

Lorem Ipsum-ը տպագրության և տպագրական արդյունաբերության համար նախատեսված մոդելային տեքստ է: Սկսած 1500-ականներից` Lorem Ipsum-ը հանդիսացել է տպագրական արդյունաբերության ստանդարտ մոդելային տեքստ, ինչը մի անհայտ տպագրիչի կողմից տարբեր տառատեսակների օրինակների գիրք ստեղծելու ջանքերի արդյունք է: Այս տեքստը ոչ միայն կարողացել է գոյատևել հինգ դարաշրջան, այլև ներառվել է էլեկտրոնային տպագրության մեջ` մնալով էապես անփոփոխ: Այն հայտնի է դարձել 1960-ականներին Lorem Ipsum բովանդակող Letraset էջերի թողարկման արդյունքում, իսկ ավելի ուշ համակարգչային տպագրության այնպիսի ծրագրերի թողարկման հետևանքով, ինչպիսին է Aldus PageMaker-ը, որը ներառում է Lorem Ipsum-ի տարատեսակներ:

Български

Lorem Ipsum е елементарен примерен текст, използван в печатарската и типографската индустрия. Lorem Ipsum е индустриален стандарт от около 1500 година, когато неизвестен печатар взема няколко печатарски букви и ги разбърква, за да напечата с тях книга с примерни шрифтове. Този начин не само е оцелял повече от 5 века, но е навлязъл и в публикуването на електронни издания като е запазен почти без промяна. Популяризиран е през 60те години на 20ти век със издаването на Letraset листи, съдържащи Lorem Ipsum пасажи, популярен е и в наши дни във софтуер за печатни издания като Aldus PageMaker, който включва различни версии на Lorem Ipsum.

Català

Lorem Ipsum és un text de farciment usat per la indústria de la tipografia i la impremta. Lorem Ipsum ha estat el text estàndard de la indústria des de l\'any 1500, quan un impressor desconegut va fer servir una galerada de text i la va mesclar per crear un llibre de mostres tipogràfiques. No només ha sobreviscut cinc segles, sinó que ha fet el salt cap a la creació de tipus de lletra electrònics, romanent essencialment sense canvis. Es va popularitzar l\'any 1960 amb el llançament de fulls Letraset que contenien passatges de Lorem Ipsum, i més recentment amb programari d\'autoedició com Aldus Pagemaker que inclou versions de Lorem Ipsum.

Hrvatski

Lorem Ipsum je jednostavno probni tekst koji se koristi u tiskarskoj i slovoslagarskoj industriji. Lorem Ipsum postoji kao industrijski standard još od 16-og stoljeća, kada je nepoznati tiskar uzeo tiskarsku galiju slova i posložio ih da bi napravio knjigu s uzorkom tiska. Taj je tekst ne samo preživio pet stoljeća, već se i vinuo u svijet elektronskog slovoslagarstva, ostajući u suštini nepromijenjen. Postao je popularan tijekom 1960-ih s pojavom Letraset listova s odlomcima Lorem Ipsum-a, a u skorije vrijeme sa software-om za stolno izdavaštvo kao što je Aldus PageMaker koji također sadrži varijante Lorem Ipsum-a.

Česky

Lorem Ipsum je demonstrativní výplňový text používaný v tiskařském a knihařském průmyslu. Lorem Ipsum je považováno za standard v této oblasti už od začátku 16. století, kdy dnes neznámý tiskař vzal kusy textu a na jejich základě vytvořil speciální vzorovou knihu. Jeho odkaz nevydržel pouze pět století, on přežil i nástup elektronické sazby v podstatě beze změny. Nejvíce popularizováno bylo Lorem Ipsum v šedesátých letech 20. století, kdy byly vydávány speciální vzorníky s jeho pasážemi a později pak díky počítačovým DTP programům jako Aldus PageMaker.

Româna

Lorem Ipsum este pur şi simplu o machetă pentru text a industriei tipografice. Lorem Ipsum a fost macheta standard a industriei încă din secolul al XVI-lea, când un tipograf anonim a luat o planşetă de litere şi le-a amestecat pentru a crea o carte demonstrativă pentru literele respective. Nu doar că a supravieţuit timp de cinci secole, dar şi a facut saltul în tipografia electronică practic neschimbată. A fost popularizată în anii \'60 odată cu ieşirea colilor Letraset care conţineau pasaje Lorem Ipsum, iar mai recent, prin programele de publicare pentru calculator, ca Aldus PageMaker care includeau versiuni de Lorem Ipsum.

Српски

Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се. Популаризован је шездесетих година двадесетог века заједно са листовима летерсета који су садржали Lorem Ipsum пасусе, а данас са софтверским пакетом за прелом као што је Aldus PageMaker који је садржао Lorem Ipsum верзије.', 'Lorem Ipsum', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum', '', '', '2007-09-04 09:52:50', '2007-09-04 16:52:50', '', 0, 'http://wpthemetestdata.wordpress.com/lorem-ipsum/', 7, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2007-09-04 10:47:47', '2007-09-04 17:47:47', 'Repository-hosted Themes are required to support display of comments on static Pages as well as on single blog Posts.  This static Page has comments, and these comments should be displayed.
If the Theme includes a custom option to prevent static Pages from displaying comments, such option must be disabled (i.e. so that static Pages display comments) by default.
Also, verify that this Page does not display taxonomy information (e.g. categories or tags) or time-stamp information (Page publish date/time).', 'Page with comments', '', 'publish', 'open', 'closed', '', 'page-with-comments', '', '', '2007-09-04 10:47:47', '2007-09-04 17:47:47', '', 135, 'http://wpthemetestdata.wordpress.com/page-with-comments/', 3, 'page', '', 21) ; 
INSERT INTO `wp_posts` VALUES (156, 1, '2007-09-04 10:48:10', '2007-09-04 17:48:10', 'This static Page is set not to allow comments. Verify that the Page does not display a comment list, comment reply links, or comment reply form.
Also, verify that the Page does not display a "comments are closed" type message. Such messages are not suitable for static Pages, and should only be used on blog Posts.', 'Page with comments disabled', '', 'publish', 'closed', 'closed', '', 'page-with-comments-disabled', '', '', '2007-09-04 10:48:10', '2007-09-04 17:48:10', '', 135, 'http://wpthemetestdata.wordpress.com/page-with-comments-disabled/', 4, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2007-12-11 16:23:16', '2007-12-11 06:23:16', 'Level 3 of the reverse hierarchy test.', 'Level 3', '', 'publish', 'closed', 'closed', '', 'level-3', '', '', '2007-12-11 16:23:16', '2007-12-11 06:23:16', '', 173, 'http://wpthemetestdata.wordpress.com/level-3/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2007-12-11 16:23:33', '2007-12-11 06:23:33', 'Level 2 of the reverse hierarchy test.', 'Level 2', '', 'publish', 'closed', 'closed', '', 'level-2', '', '', '2007-12-11 16:23:33', '2007-12-11 06:23:33', '', 174, 'http://wpthemetestdata.wordpress.com/level-2/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2007-12-11 16:25:40', '2007-12-11 23:25:40', 'Level 1 of the reverse hierarchy test.  This is to make sure the importer correctly assigns parents and children even when the children come first in the export file.', 'Level 1', '', 'publish', 'closed', 'closed', '', 'level-1', '', '', '2007-12-11 16:25:40', '2007-12-11 23:25:40', '', 0, 'http://wpthemetestdata.wordpress.com/level-1/', 5, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (501, 1, '2010-08-01 09:42:26', '2010-08-01 16:42:26', 'The last item in this page\'s content is a floated image. Make sure any elements after it are clearing properly.

<img class="alignleft size-thumbnail wp-image-827" title="Camera" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/manhattansummer.jpg?w=150" alt="" width="150" height="112" />', 'Clearing Floats', '', 'publish', 'closed', 'closed', '', 'clearing-floats', '', '', '2010-08-01 09:42:26', '2010-08-01 16:42:26', '', 135, 'http://wpthemetestdata.wordpress.com/', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (611, 1, '2011-01-10 06:17:54', '2011-01-10 13:17:54', '', 'canola2', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec mollis. Quisque convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravida id, odio. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna.', 'inherit', 'open', 'closed', '', 'canola2', '', '', '2011-01-10 06:17:54', '2011-01-10 13:17:54', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/01/canola2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (616, 1, '2011-01-10 06:20:37', '2011-01-10 13:20:37', '', 'dsc20050727_091048_222', '', 'inherit', 'open', 'closed', '', 'dsc20050727_091048_222', '', '', '2011-01-10 06:20:37', '2011-01-10 13:20:37', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/01/dsc20050727_091048_222.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (617, 1, '2011-01-10 06:20:57', '2011-01-10 13:20:57', '', 'dsc20050813_115856_52', '', 'inherit', 'open', 'closed', '', 'dsc20050813_115856_52', '', '', '2011-01-10 06:20:57', '2011-01-10 13:20:57', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/01/dsc20050813_115856_52.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (701, 1, '2011-05-20 18:49:43', '2011-05-21 01:49:43', 'Use this static Page to test the Theme\'s handling of the Front Page template file. 

This is the Front Page content. Use this static Page to test the Front Page output of the Theme. The Theme should properly handle both Blog Posts Index as Front Page and static Page as Front Page.

If the site is set to display the Blog Posts Index as the Front Page, then this text should not be visible. If the site is set to display a static Page as the Front Page, then this text may or may not be visible. If the Theme does not include a front-page.php template file, then this text should appear on the Front Page when set to display a static Page. If the Theme does include a front-page.php template file, then this text may or may not appear.', 'Front Page', '', 'publish', 'open', 'closed', '', 'front-page', '', '', '2011-05-20 18:49:43', '2011-05-21 01:49:43', '', 0, 'http://wpthemetestdata.wordpress.com/?page_id=701', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (703, 1, '2011-05-20 18:51:43', '2011-05-21 01:51:43', 'Use this static Page to test the Theme\'s handling of the Blog Posts Index page. If the site is set to display a static Page on the Front Page, and this Page is set to display the Blog Posts Index, then this text should not appear.', 'Blog', '', 'publish', 'open', 'closed', '', 'blog', '', '', '2011-05-20 18:51:43', '2011-05-21 01:51:43', '', 0, 'http://wpthemetestdata.wordpress.com/?page_id=703', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (733, 1, '2011-06-23 18:38:52', '2011-06-24 01:38:52', 'Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Aenean lacinia bibendum nulla sed consectetur. Etiam porta sem malesuada magna mollis euismod. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.', 'Page A', '', 'publish', 'open', 'closed', '', 'page-a', '', '', '2011-06-23 18:38:52', '2011-06-24 01:38:52', '', 0, 'http://wpthemetestdata.wordpress.com/?page_id=733', 10, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (754, 1, '2011-07-15 14:34:50', '2011-07-15 21:34:50', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/100_5540.JPG.html', 'Bell on Wharf', 'Bell on wharf in San Francisco', 'inherit', 'open', 'closed', '', '100_5478', '', '', '2011-07-15 14:34:50', '2011-07-15 21:34:50', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/100_5478.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (755, 1, '2011-07-15 14:35:55', '2011-07-15 21:35:55', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/100_5478.JPG.html', 'Golden Gate Bridge', 'Golden Gate Bridge', 'inherit', 'open', 'closed', '', '100_5540', '', '', '2011-07-15 14:35:55', '2011-07-15 21:35:55', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/100_5540.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (756, 1, '2011-07-15 14:41:24', '2011-07-15 21:41:24', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/CEP00032.jpg.html', 'Sunburst Over River', 'Sunburst over the Clinch River, Southwest Virginia.', 'inherit', 'open', 'closed', '', 'cep00032', '', '', '2011-07-15 14:41:24', '2011-07-15 21:41:24', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/cep00032.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (757, 1, '2011-07-15 14:41:27', '2011-07-15 21:41:27', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/DCP_2082.jpg.html', 'Boardwalk', 'Boardwalk at Westport, WA', 'inherit', 'open', 'closed', '', 'dcp_2082', '', '', '2011-07-15 14:41:27', '2011-07-15 21:41:27', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dcp_2082.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (758, 1, '2011-07-15 14:41:33', '2011-07-15 21:41:33', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/dsc03149.jpg.html', 'Yachtsody in Blue', 'Boats and reflections, Royal Perth Yacht Club', 'inherit', 'open', 'closed', '', 'dsc03149', '', '', '2011-07-15 14:41:33', '2011-07-15 21:41:33', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc03149.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (759, 1, '2011-07-15 14:41:37', '2011-07-15 21:41:37', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/dsc04563.jpg.html', 'Rain Ripples', 'Raindrop ripples on a pond', 'inherit', 'open', 'closed', '', 'dsc04563', '', '', '2011-07-15 14:41:37', '2011-07-15 21:41:37', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc04563.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (760, 1, '2011-07-15 14:41:41', '2011-07-15 21:41:41', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/dsc09114.jpg.html', 'Sydney Harbor Bridge', 'Sydney Harbor Bridge', 'inherit', 'open', 'closed', '', 'dsc09114', '', '', '2011-07-15 14:41:41', '2011-07-15 21:41:41', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc09114.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (761, 1, '2011-07-15 14:41:42', '2011-07-15 21:41:42', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/dsc20050102_192118_51.jpg.html', 'Wind Farm', 'Albany wind-farm against the sunset, Western Australia', 'inherit', 'open', 'closed', '', 'dsc20050102_192118_51', '', '', '2011-07-15 14:41:42', '2011-07-15 21:41:42', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc20050102_192118_51.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (762, 1, '2011-07-15 14:41:45', '2011-07-15 21:41:45', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/dsc20051220_160808_102.jpg.html', 'Antique Farm Machinery', 'Antique farm machinery, Mount Barker Museum, Western Australia', 'inherit', 'open', 'closed', '', 'dsc20051220_160808_102', '', '', '2011-07-15 14:41:45', '2011-07-15 21:41:45', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc20051220_160808_102.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (763, 1, '2011-07-15 14:46:27', '2011-07-15 21:46:27', 'Public domain via http://www.burningwell.org/gallery2/main.php?g2_view=dynamicalbum.UpdatesAlbum&amp;g2_itemId=25895', 'Orange Iris', 'Orange Iris', 'inherit', 'open', 'closed', '', 'dsc02085', '', '', '2011-07-15 14:46:27', '2011-07-15 21:46:27', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc02085.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (764, 1, '2011-07-15 14:47:17', '2011-07-15 21:47:17', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/dsc20051220_173257_119.jpg.html', 'Rusty Rail', 'Rusty rails with fishplate, Kojonup', 'inherit', 'open', 'closed', '', 'dsc20051220_173257_119', '', '', '2011-07-15 14:47:17', '2011-07-15 21:47:17', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dsc20051220_173257_119.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (765, 1, '2011-07-15 14:47:20', '2011-07-15 21:47:20', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/dscn3316.jpg.html', 'Sea and Rocks', 'Sea and rocks, Plimmerton, New Zealand', 'inherit', 'open', 'closed', '', 'dscn3316', '', '', '2011-07-15 14:47:20', '2011-07-15 21:47:20', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/dscn3316.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (766, 1, '2011-07-15 14:47:23', '2011-07-15 21:47:23', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/michelle_049.jpg.html', 'Big Sur', 'Beach at Big Sur, CA', 'inherit', 'open', 'closed', '', 'michelle_049', '', '', '2011-07-15 14:47:23', '2011-07-15 21:47:23', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/michelle_049.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (767, 1, '2011-07-15 14:47:26', '2011-07-15 21:47:26', 'Public domain via http://www.burningwell.org/gallery2/v/Objects/Windmill.jpg.html', 'Windmill', 'Windmill shrouded in fog at a farm outside of Walker, Iowa', 'inherit', 'open', 'closed', '', 'dcf-1-0', '', '', '2011-07-15 14:47:26', '2011-07-15 21:47:26', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/windmill.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (768, 1, '2011-07-15 14:49:48', '2011-07-15 21:49:48', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/IMG_0513-1.JPG.html', 'Huatulco Coastline', 'Sunrise over the coast in Huatulco, Oaxaca, Mexico', 'inherit', 'open', 'closed', '', 'alas-i-have-found-my-shangri-la', '', '', '2011-07-15 14:49:48', '2011-07-15 21:49:48', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_0513-1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (769, 1, '2011-07-15 14:50:37', '2011-07-15 21:50:37', 'Public domain via http://www.burningwell.org/gallery2/main.php?g2_view=dynamicalbum.UpdatesAlbum&amp;g2_itemId=25770', 'Brazil Beach', 'Jericoacoara Ceara Brasil', 'inherit', 'open', 'closed', '', 'img_0747', '', '', '2011-07-15 14:50:37', '2011-07-15 21:50:37', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_0747.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (770, 1, '2011-07-15 14:51:19', '2011-07-15 21:51:19', 'Public domain via http://www.burningwell.org/gallery2/v/Landscapes/ocean/IMG_0767.JPG.html', 'Huatulco Coastline', 'Coastline in Huatulco, Oaxaca, Mexico', 'inherit', 'open', 'closed', '', 'img_0767', '', '', '2011-07-15 14:51:19', '2011-07-15 21:51:19', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_0767.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (771, 1, '2011-07-15 14:51:57', '2011-07-15 21:51:57', 'Public domain via http://www.burningwell.org/gallery2/main.php?g2_view=dynamicalbum.UpdatesAlbum&amp;g2_itemId=25774', 'Boat Barco Texture', 'Boat BW PB Barco Texture Beautiful Fishing', 'inherit', 'open', 'closed', '', 'img_8399', '', '', '2011-07-15 14:51:57', '2011-07-15 21:51:57', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_8399.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (807, 1, '2012-06-04 11:36:56', '2012-06-04 18:36:56', '', 'dsc20040724_152504_532', '', 'inherit', 'open', 'closed', '', 'dsc20040724_152504_532-2', '', '', '2012-06-04 11:36:56', '2012-06-04 18:36:56', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/06/dsc20040724_152504_532.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (811, 1, '2012-06-04 11:58:15', '2012-06-04 18:58:15', '', 'dsc20050604_133440_3421', '', 'inherit', 'open', 'closed', '', 'dsc20050604_133440_3421', '', '', '2012-06-04 11:58:15', '2012-06-04 18:58:15', '', 555, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/06/dsc20050604_133440_34211.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (821, 1, '2012-07-05 09:49:29', '2012-07-05 16:49:29', 'St. Louis Blues, by Original Dixieland Jazz Band with Al Bernard (public domain)', 'St. Louis Blues', 'St. Louis Blues, by Original Dixieland Jazz Band with Al Bernard (public domain)', 'inherit', 'open', 'closed', '', 'originaldixielandjazzbandwithalbernard-stlouisblues', '', '', '2012-07-05 09:49:29', '2012-07-05 16:49:29', '', 587, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/originaldixielandjazzbandwithalbernard-stlouisblues.mp3', 0, 'attachment', 'audio/mpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (827, 1, '2012-07-05 11:07:34', '2012-07-05 18:07:34', '', 'OLYMPUS DIGITAL CAMERA', '', 'inherit', 'open', 'closed', '', 'olympus-digital-camera', '', '', '2012-07-05 11:07:34', '2012-07-05 18:07:34', '', 501, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/manhattansummer.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (967, 1, '2013-03-14 19:44:50', '2013-03-15 00:44:50', '', 'Image Alignment 580x300', '', 'inherit', 'open', 'open', '', 'image-alignment-580x300', '', '', '2013-03-14 19:44:50', '2013-03-15 00:44:50', '', 1177, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-580x300.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (968, 1, '2013-03-14 19:44:49', '2013-03-15 00:44:49', '', 'Image Alignment 150x150', '', 'inherit', 'open', 'open', '', 'image-alignment-150x150', '', '', '2013-03-14 19:44:49', '2013-03-15 00:44:49', '', 1177, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-150x150.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1022, 1, '2013-03-15 15:40:38', '2013-03-15 20:40:38', '', 'Horizontal Featured Image', '', 'inherit', 'open', 'open', '', 'featured-image-horizontal-2', '', '', '2013-03-15 15:40:38', '2013-03-15 20:40:38', '', 1011, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/featured-image-horizontal.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1023, 1, '2013-03-14 09:58:24', '2013-03-14 14:58:24', '', 'I Am Worth Loving Wallpaper', '', 'inherit', 'open', 'open', '', 'soworthloving-wallpaper', '', '', '2013-03-14 09:58:24', '2013-03-14 14:58:24', '', 1177, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/soworthloving-wallpaper.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1025, 1, '2013-03-14 19:44:49', '2013-03-15 00:44:49', '', 'Image Alignment 300x200', '', 'inherit', 'open', 'open', '', 'image-alignment-300x200', '', '', '2013-03-14 19:44:49', '2013-03-15 00:44:49', '', 1177, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-300x200.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1027, 1, '2013-03-15 15:41:09', '2013-03-15 20:41:09', '', 'Vertical Featured Image', '', 'inherit', 'open', 'open', '', 'featured-image-vertical-2', '', '', '2013-03-15 15:41:09', '2013-03-15 20:41:09', '', 1016, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/featured-image-vertical.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1029, 1, '2013-03-14 19:44:50', '2013-03-15 00:44:50', '', 'Image Alignment 1200x4002', '', 'inherit', 'open', 'open', '', 'image-alignment-1200x4002', '', '', '2013-03-14 19:44:50', '2013-03-15 00:44:50', '', 1177, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-1200x4002.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1045, 1, '2013-03-14 22:10:39', '2013-03-15 03:10:39', '', 'Unicorn Wallpaper', '', 'inherit', 'open', 'open', '', 'unicorn-wallpaper', '', '', '2013-03-14 22:10:39', '2013-03-15 03:10:39', '', 1158, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/unicorn-wallpaper.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1046, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Pages', '', 'publish', 'open', 'open', '', 'pages', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/pages/', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1047, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Categories', '', 'publish', 'open', 'open', '', 'categories', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/categories/', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1048, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', 'Posts in this category test markup tags and styles.', '', '', 'publish', 'open', 'open', '', '1048', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/1048/', 21, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1049, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', 'Posts in this category test post formats.', '', '', 'publish', 'open', 'open', '', '1049', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/1049/', 24, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1050, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', 'Posts in this category test unpublished posts.', '', '', 'publish', 'open', 'open', '', '1050', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/1050/', 28, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1051, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Depth', '', 'publish', 'open', 'open', '', 'depth', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/depth/', 29, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1052, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 01', '', 'publish', 'open', 'open', '', 'level-01', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-01/', 30, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1053, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 02', '', 'publish', 'open', 'open', '', 'level-02', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-02/', 31, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1054, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 03', '', 'publish', 'open', 'open', '', 'level-03', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-03/', 32, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1055, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 04', '', 'publish', 'open', 'open', '', 'level-04', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-04/', 33, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1056, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 05', '', 'publish', 'open', 'open', '', 'level-05', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-05/', 34, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1057, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 06', '', 'publish', 'open', 'open', '', 'level-06', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-06/', 35, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1058, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 07', '', 'publish', 'open', 'open', '', 'level-07', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-07/', 36, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1059, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 08', '', 'publish', 'open', 'open', '', 'level-08', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-08/', 37, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1060, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 09', '', 'publish', 'open', 'open', '', 'level-09', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-09/', 38, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1061, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Level 10', '', 'publish', 'open', 'open', '', 'level-10', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/level-10/', 39, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1062, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Advanced', '', 'publish', 'open', 'open', '', 'advanced', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/advanced/', 40, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1063, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', 'Custom Menu Description', 'Menu Description', '', 'publish', 'open', 'open', '', 'menu-description', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/menu-description/', 44, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1064, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Menu Title Attribute', 'Custom Title Attribute', 'publish', 'open', 'open', '', 'menu-title-attribute', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/menu-title-attribute/', 41, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1065, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'Menu CSS Class', '', 'publish', 'open', 'open', '', 'menu-css-class', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/menu-css-class/', 42, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1066, 1, '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 'New Window / Tab', '', 'publish', 'open', 'open', '', 'new-window-tab', '', '', '2014-03-28 08:59:54', '2014-03-28 08:59:54', '', 0, 'http://127.0.0.1:4001/wordpress/new-window-tab/', 43, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1628, 2, '2013-04-09 13:17:31', '2013-04-09 20:17:31', '', 'triforce-wallpaper', 'It’s dangerous to go alone! Take this.', 'inherit', 'open', 'closed', '', 'triforce-wallpaper', '', '', '2013-04-09 13:17:31', '2013-04-09 20:17:31', '', 1163, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/04/triforce-wallpaper.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1629, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 'Home', '', 'publish', 'open', 'open', '', 'home-2', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/home-2/', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1630, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1630', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1630/', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1631, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1631', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1631/', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1632, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1632', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1632/', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1633, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1633', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1633/', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1634, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1634', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1634/', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1635, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1635', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1635/', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1636, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 'Home', '', 'publish', 'open', 'open', '', 'home-3', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/home-3/', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1637, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1637', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1637/', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1638, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1638', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1638/', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1639, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1639', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1639/', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1640, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1640', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1640/', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1641, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1641', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1641/', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1642, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1642', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 135, 'http://127.0.0.1:4001/wordpress/1642/', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1643, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1643', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1643/', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1644, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1644', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1644/', 11, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1645, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1645', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1645/', 12, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1646, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1646', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1646/', 17, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1647, 1, '2014-03-28 08:59:57', '2014-03-28 08:59:57', ' ', '', '', 'publish', 'open', 'open', '', '1647', '', '', '2014-03-28 08:59:57', '2014-03-28 08:59:57', '', 0, 'http://127.0.0.1:4001/wordpress/1647/', 18, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1686, 4, '2013-09-18 14:37:05', '2013-09-18 21:37:05', '', 'dsc20040724_152504_532', '', 'inherit', 'open', 'closed', '', 'dsc20040724_152504_532', '', '', '2013-09-18 14:37:05', '2013-09-18 21:37:05', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/09/dsc20040724_152504_532.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1687, 4, '2013-09-18 14:37:07', '2013-09-18 21:37:07', '', 'dsc20050604_133440_34211', '', 'inherit', 'open', 'closed', '', 'dsc20050604_133440_34211', '', '', '2013-09-18 14:37:07', '2013-09-18 21:37:07', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/09/dsc20050604_133440_34211.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (358, 1, '2010-10-05 00:27:25', '2010-10-05 07:27:25', 'All children, except one, grow up. They soon know that they will grow up, and the way Wendy knew was this. One day when she was two years old she was playing in a garden, and she plucked another flower and ran with it to her mother. I suppose she must have looked rather delightful, for Mrs. Darling put her hand to her heart and cried, "Oh, why can\'t you remain like this for ever!" This was all that passed between them on the subject, but henceforth Wendy knew that she must grow up. You always know after you are two. Two is the beginning of the end.

<!--more-->

Mrs. Darling first heard of Peter when she was tidying up her children\'s minds. It is the nightly custom of every good mother after her children are asleep to rummage in their minds and put things straight for next morning, repacking into their proper places the many articles that have wandered during the day.

If you could keep awake (but of course you can\'t) you would see your own mother doing this, and you would find it very interesting to watch her. It is quite like tidying up drawers. You would see her on her knees, I expect, lingering humorously over some of your contents, wondering where on earth you had picked this thing up, making discoveries sweet and not so sweet, pressing this to her cheek as if it were as nice as a kitten, and hurriedly stowing that out of sight. When you wake in the morning, the naughtiness and evil passions with which you went to bed have been folded up small and placed at the bottom of your mind and on the top, beautifully aired, are spread out your prettier thoughts, ready for you to put on.

I don\'t know whether you have ever seen a map of a person\'s mind. Doctors sometimes draw maps of other parts of you, and your own map can become intensely interesting, but catch them trying to draw a map of a child\'s mind, which is not only confused, but keeps going round all the time. There are zigzag lines on it, just like your temperature on a card, and these are probably roads in the island, for the Neverland is always more or less an island, with astonishing splashes of colour here and there, and coral reefs and rakish-looking craft in the offing, and savages and lonely lairs, and gnomes who are mostly tailors, and caves through which a river runs, and princes with six elder brothers, and a hut fast going to decay, and one very small old lady with a hooked nose. It would be an easy map if that were all, but there is also first day at school, religion, fathers, the round pond, needle-work, murders, hangings, verbs that take the dative, chocolate pudding day, getting into braces, say ninety-nine, three-pence for pulling out your tooth yourself, and so on, and either these are part of the island or they are another map showing through, and it is all rather confusing, especially as nothing will stand still.

Of course the Neverlands vary a good deal. John\'s, for instance, had a lagoon with flamingoes flying over it at which John was shooting, while Michael, who was very small, had a flamingo with lagoons flying over it. John lived in a boat turned upside down on the sands, Michael in a wigwam, Wendy in a house of leaves deftly sewn together. John had no friends, Michael had friends at night, Wendy had a pet wolf forsaken by its parents, but on the whole the Neverlands have a family resemblance, and if they stood still in a row you could say of them that they have each other\'s nose, and so forth. On these magic shores children at play are for ever beaching their coracles [simple boat]. We too have been there; we can still hear the sound of the surf, though we shall land no more.

Of all delectable islands the Neverland is the snuggest and most compact, not large and sprawly, you know, with tedious distances between one adventure and another, but nicely crammed. When you play at it by day with the chairs and table-cloth, it is not in the least alarming, but in the two minutes before you go to sleep it becomes very real. That is why there are night-lights.

Occasionally in her travels through her children\'s minds Mrs. Darling found things she could not understand, and of these quite the most perplexing was the word Peter. She knew of no Peter, and yet he was here and there in John and Michael\'s minds, while Wendy\'s began to be scrawled all over with him. The name stood out in bolder letters than any of the other words, and as Mrs. Darling gazed she felt that it had an oddly cocky appearance.', 'Post Format: Standard', '', 'publish', 'closed', 'closed', '', 'post-format-standard', '', '', '2010-10-05 00:27:25', '2010-10-05 07:27:25', '', 0, 'http://wpthemetestdata.wordpress.com/?p=358', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (555, 1, '2010-09-10 07:24:14', '2010-09-10 14:24:14', '[gallery]

<!--nextpage-->

You can use this page to test the Theme\'s handling of the[gallery]

shortcode, including the <code>columns</code> parameter, from 1 to 9 columns. Themes are only required to support the default setting (3 columns), so this page is entirely optional.
<h2>One Column</h2>
[gallery columns="1"]
<h2>Two Columns</h2>
[gallery columns="2"]
<h2>Three Columns</h2>
[gallery columns="3"]
<h2>Four Columns</h2>
[gallery columns="4"]
<h2>Five Columns</h2>
[gallery columns="5"]
<h2>Six Columns</h2>
[gallery columns="6"]
<h2>Seven Columns</h2>
[gallery columns="7"]
<h2>Eight Columns</h2>
[gallery columns="8"]
<h2>Nine Columns</h2>
[gallery columns="9"]', 'Post Format: Gallery', '', 'publish', 'closed', 'closed', '', 'post-format-gallery', '', '', '2010-09-10 07:24:14', '2010-09-10 14:24:14', '', 0, 'http://wpthemetestdata.wordpress.com/?p=555', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (559, 1, '2010-05-09 07:51:54', '2010-05-09 14:51:54', '“I never tried to prove nothing, just wanted to give a good show. My life has always been my music, it\'s always come first, but the music ain\'t worth nothing if you can\'t lay it on the public. The main thing is to live for that audience, \'cause what you\'re there for is to please the people.”', 'Post Format: Aside', '', 'publish', 'closed', 'closed', '', 'post-format-aside', '', '', '2010-05-09 07:51:54', '2010-05-09 14:51:54', '', 0, 'http://wpthemetestdata.wordpress.com/?p=559', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (562, 1, '2010-01-08 07:59:31', '2010-01-08 14:59:31', 'Abbott: Strange as it may seem, they give ball players nowadays very peculiar names.

Costello: Funny names?

Abbott: Nicknames, nicknames. Now, on the St. Louis team we have Who\'s on first, What\'s on second, I Don\'t Know is on third--

Costello: That\'s what I want to find out. I want you to tell me the names of the fellows on the St. Louis team.

Abbott: I\'m telling you. Who\'s on first, What\'s on second, I Don\'t Know is on third--

Costello: You know the fellows\' names?

Abbott: Yes.

Costello: Well, then who\'s playing first?

Abbott: Yes.

Costello: I mean the fellow\'s name on first base.

Abbott: Who.

Costello: The fellow playin\' first base.

Abbott: Who.

Costello: The guy on first base.

Abbott: Who is on first.

Costello: Well, what are you askin\' me for?

Abbott: I\'m not asking you--I\'m telling you. Who is on first.

Costello: I\'m asking you--who\'s on first?

Abbott: That\'s the man\'s name.

Costello: That\'s who\'s name?

Abbott: Yes.

Costello: When you pay off the first baseman every month, who gets the money?

Abbott: Every dollar of it. And why not, the man\'s entitled to it.

Costello: Who is?

Abbott: Yes.

Costello: So who gets it?

Abbott: Why shouldn\'t he? Sometimes his wife comes down and collects it.

Costello: Who\'s wife?

Abbott: Yes. After all, the man earns it.

Costello: Who does?

Abbott: Absolutely.

Costello: Well, all I\'m trying to find out is what\'s the guy\'s name on first base?

Abbott: Oh, no, no. What is on second base.

Costello: I\'m not asking you who\'s on second.

Abbott: Who\'s on first!

Costello: St. Louis has a good outfield?

Abbott: Oh, absolutely.

Costello: The left fielder\'s name?

Abbott: Why.

Costello: I don\'t know, I just thought I\'d ask.

Abbott: Well, I just thought I\'d tell you.

Costello: Then tell me who\'s playing left field?

Abbott: Who\'s playing first.

Costello: Stay out of the infield! The left fielder\'s name?

Abbott: Why.

Costello: Because.

Abbott: Oh, he\'s center field.

Costello: Wait a minute. You got a pitcher on this team?

Abbott: Wouldn\'t this be a fine team without a pitcher?

Costello: Tell me the pitcher\'s name.

Abbott: Tomorrow.

Costello: Now, when the guy at bat bunts the ball--me being a good catcher--I want to throw the guy out at first base, so I pick up the ball and throw it to who?

Abbott: Now, that\'s he first thing you\'ve said right.

Costello: I DON\'T EVEN KNOW WHAT I\'M TALKING ABOUT!

Abbott: Don\'t get excited. Take it easy.

Costello: I throw the ball to first base, whoever it is grabs the ball, so the guy runs to second. Who picks up the ball and throws it to what. What throws it to I don\'t know. I don\'t know throws it back to tomorrow--a triple play.

Abbott: Yeah, it could be.

Costello: Another guy gets up and it\'s a long ball to center.

Abbott: Because.

Costello: Why? I don\'t know. And I don\'t care.

Abbott: What was that?

Costello: I said, I DON\'T CARE!

Abbott: Oh, that\'s our shortstop!', 'Post Format: Chat', '', 'publish', 'closed', 'closed', '', 'post-format-chat', '', '', '2010-01-08 07:59:31', '2010-01-08 14:59:31', '', 0, 'http://wpthemetestdata.wordpress.com/?p=562', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (565, 1, '2010-03-07 08:06:53', '2010-03-07 15:06:53', '<a href="http://make.wordpress.org/themes" title="The WordPress Theme Review Team Website">The WordPress Theme Review Team Website</a>', 'Post Format: Link', '', 'publish', 'closed', 'closed', '', 'post-format-link', '', '', '2010-03-07 08:06:53', '2010-03-07 15:06:53', '', 0, 'http://wpthemetestdata.wordpress.com/?p=565', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (568, 1, '2010-08-06 08:09:39', '2010-08-06 15:09:39', '[caption id="attachment_612" align="aligncenter" width="640" caption="Chunk of resinous blackboy husk, Clarkson, Western Australia. This burns like a spinifex log."]<a href="http://wpthemetestdata.files.wordpress.com/2012/06/dsc20040724_152504_532.jpg"><img src="http://wpthemetestdata.files.wordpress.com/2012/06/dsc20040724_152504_532.jpg" alt="chunk of resinous blackboy husk" title="dsc20040724_152504_532" width="640" height="480" class="size-full wp-image-612" /></a>[/caption]
', 'Post Format: Image (Linked)', '', 'publish', 'closed', 'closed', '', 'post-format-image-linked', '', '', '2010-08-06 08:09:39', '2010-08-06 15:09:39', '', 0, 'http://wpthemetestdata.wordpress.com/?p=568', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (575, 1, '2010-02-05 08:13:15', '2010-02-05 15:13:15', '<blockquote>Only one thing is impossible for God: To find any sense in any copyright law on the planet.
<cite><a href="http://www.brainyquote.com/quotes/quotes/m/marktwain163473.html">Mark Twain</a></cite></blockquote>', 'Post Format: Quote', '', 'publish', 'closed', 'closed', '', 'post-format-quote', '', '', '2010-02-05 08:13:15', '2010-02-05 15:13:15', '', 0, 'http://wpthemetestdata.wordpress.com/?p=575', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (579, 1, '2010-04-04 08:21:24', '2010-04-04 15:21:24', 'WordPress, how do I love thee? Let me count the ways (in 140 characters or less).', 'Post Format: Status', '', 'publish', 'closed', 'closed', '', 'post-format-status', '', '', '2010-04-04 08:21:24', '2010-04-04 15:21:24', '', 0, 'http://wpthemetestdata.wordpress.com/?p=579', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (582, 1, '2010-06-03 08:25:58', '2010-06-03 15:25:58', 'http://wordpress.tv/2009/03/16/anatomy-of-a-wordpress-theme-exploring-the-files-behind-your-theme/

Posted as per the <a href="http://codex.wordpress.org/Embeds" target="_blank">instructions in the Codex</a>.', 'Post Format: Video (WordPress.tv)', '', 'publish', 'closed', 'closed', '', 'post-format-video-wordpresstv', '', '', '2010-06-03 08:25:58', '2010-06-03 15:25:58', '', 0, 'http://wpthemetestdata.wordpress.com/?p=582', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (587, 1, '2010-07-02 08:36:44', '2010-07-02 15:36:44', 'Link:

<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/originaldixielandjazzbandwithalbernard-stlouisblues.mp3">St. Louis Blues</a>

Audio shortcode:

[audio http://127.0.0.1:4001/wordpress/wp-content/uploads/2012/07/originaldixielandjazzbandwithalbernard-stlouisblues.mp3]', 'Post Format: Audio', '', 'publish', 'closed', 'closed', '', 'post-format-audio', '', '', '2010-07-02 08:36:44', '2010-07-02 15:36:44', '', 0, 'http://wpthemetestdata.wordpress.com/?p=587', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (735, 1, '2011-06-23 18:39:14', '2011-06-24 01:39:14', '(lorem ipsum)', 'Page B', '', 'publish', 'open', 'closed', '', 'page-b', '', '', '2011-06-23 18:39:14', '2011-06-24 01:39:14', '', 0, 'http://wpthemetestdata.wordpress.com/?page_id=735', 11, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (742, 1, '2011-06-23 19:03:33', '2011-06-24 02:03:33', '(lorem ipsum)', 'Level 2a', '', 'publish', 'open', 'closed', '', 'level-2a', '', '', '2011-06-23 19:03:33', '2011-06-24 02:03:33', '', 174, 'http://wpthemetestdata.wordpress.com/?page_id=742', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (744, 1, '2011-06-23 19:04:03', '2011-06-24 02:04:03', '(lorem ipsum)', 'Level 2b', '', 'publish', 'open', 'closed', '', 'level-2b', '', '', '2011-06-23 19:04:03', '2011-06-24 02:04:03', '', 174, 'http://wpthemetestdata.wordpress.com/?page_id=744', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (746, 1, '2011-06-23 19:04:24', '2011-06-24 02:04:24', '(lorem ipsum)', 'Level 3a', '', 'publish', 'open', 'closed', '', 'level-3a', '', '', '2011-06-23 19:04:24', '2011-06-24 02:04:24', '', 173, 'http://wpthemetestdata.wordpress.com/?page_id=746', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (748, 1, '2011-06-23 19:04:46', '2011-06-24 02:04:46', '(lorem ipsum)', 'Level 3b', '', 'publish', 'open', 'closed', '', 'level-3b', '', '', '2011-06-23 19:04:46', '2011-06-24 02:04:46', '', 173, 'http://wpthemetestdata.wordpress.com/?page_id=748', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (993, 1, '2012-03-15 14:38:08', '2012-03-15 21:38:08', 'This is the post content. It should be displayed in place of the user-defined excerpt in single-page views.', 'Template: Excerpt (Defined)', 'This is a user-defined post excerpt. It should be displayed in place of the post content in archive-index pages.', 'publish', 'closed', 'closed', '', 'template-excerpt-defined', '', '', '2012-03-15 14:38:08', '2012-03-15 21:38:08', '', 0, 'http://wptest.io/demo/?p=993', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (996, 1, '2012-03-15 14:41:11', '2012-03-15 21:41:11', 'This content is before the <a title="The More Tag" href="http://en.support.wordpress.com/splitting-content/more-tag/" target="_blank">more tag</a>.

Right after this sentence should be a "continue reading" button of some sort.

<!--more-->

And this content is after the more tag.', 'Template: More Tag', '', 'publish', 'closed', 'closed', '', 'template-more-tag', '', '', '2012-03-15 14:41:11', '2012-03-15 21:41:11', '', 0, 'http://wptest.io/demo/?p=996', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1000, 1, '2009-05-15 14:48:32', '2009-05-15 21:48:32', 'Nested and mixed lists are an interesting beast. It\'s a corner case to make sure that
<ul>
	<li><span style="line-height:1.714285714;font-size:1rem;">Lists within lists do not break the ordered list numbering order</span></li>
	<li><span style="line-height:1.714285714;font-size:1rem;">Your list styles go deep enough.</span></li>
</ul>
<h3>Ordered - Unordered - Ordered</h3>
<ol>
	<li>ordered item</li>
	<li>ordered item
<ul>
	<li><strong>unordered</strong></li>
	<li><strong>unordered</strong>
<ol>
	<li>ordered item</li>
	<li>ordered item</li>
</ol>
</li>
</ul>
</li>
	<li>ordered item</li>
	<li>ordered item</li>
</ol>
<h3>Ordered - Unordered - Unordered</h3>
<ol>
	<li>ordered item</li>
	<li>ordered item
<ul>
	<li><strong>unordered</strong></li>
	<li><strong>unordered</strong>
<ul>
	<li>unordered item</li>
	<li>unordered item</li>
</ul>
</li>
</ul>
</li>
	<li>ordered item</li>
	<li>ordered item</li>
</ol>
<h3>Unordered - Ordered - Unordered</h3>
<ul>
	<li>unordered item</li>
	<li>unordered item
<ol>
	<li>ordered</li>
	<li>ordered
<ul>
	<li>unordered item</li>
	<li>unordered item</li>
</ul>
</li>
</ol>
</li>
	<li>unordered item</li>
	<li>unordered item</li>
</ul>
<h3>Unordered - Unordered - Ordered</h3>
<ul>
	<li>unordered item</li>
	<li>unordered item
<ul>
	<li>unordered</li>
	<li>unordered
<ol>
	<li><strong>ordered item</strong></li>
	<li><strong>ordered item</strong></li>
</ol>
</li>
</ul>
</li>
	<li>unordered item</li>
	<li>unordered item</li>
</ul>', 'Edge Case: Nested And Mixed Lists', '', 'publish', 'closed', 'closed', '', 'edge-case-nested-and-mixed-lists', '', '', '2009-05-15 14:48:32', '2009-05-15 21:48:32', '', 0, 'http://wptest.io/demo/?p=1000', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1005, 1, '2010-06-02 03:00:34', '2010-06-02 10:00:34', '[wpvideo tFnqC9XQ w=680]

<a title="VideoPress Plugin for WordPress" href="http://videopress.com/" target="_blank">VideoPress</a>, especially as a video post format, usually provides some unique styling issues.

You will need to install <a title="Jetpack for WordPress" href="http://jetpack.me/" target="_blank">Jetpack</a> or <a title="Slim Jetpack" href="http://wordpress.org/extend/plugins/slimjetpack/" target="_blank">Slim Jetpack</a> plugin to turn the shortcode into a viewable video.', 'Post Format: Video (VideoPress)', '', 'publish', 'closed', 'closed', '', 'post-format-video-videopress', '', '', '2010-06-02 03:00:34', '2010-06-02 10:00:34', '', 0, 'http://wptest.io/demo/?p=1005', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1011, 1, '2012-03-15 15:15:12', '2012-03-15 22:15:12', 'This post should display a <a title="Featured Images" href="http://en.support.wordpress.com/featured-images/#setting-a-featured-image" target="_blank">featured image</a>, if the theme <a title="Post Thumbnails" href="http://codex.wordpress.org/Post_Thumbnails" target="_blank">supports it</a>.

Non-square images can provide some unique styling issues.

This post tests a horizontal featured image.', 'Template: Featured Image (Horizontal)', '', 'publish', 'closed', 'closed', '', 'template-featured-image-horizontal', '', '', '2012-03-15 15:15:12', '2012-03-15 22:15:12', '', 0, 'http://wptest.io/demo/?p=1011', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1016, 1, '2012-03-15 15:36:32', '2012-03-15 22:36:32', 'This post should display a <a title="Featured Images" href="http://en.support.wordpress.com/featured-images/#setting-a-featured-image" target="_blank">featured image</a>, if the theme <a title="Post Thumbnails" href="http://codex.wordpress.org/Post_Thumbnails" target="_blank">supports it</a>.

Non-square images can provide some unique styling issues.

This post tests a vertical featured image.', 'Template: Featured Image (Vertical)', '', 'publish', 'closed', 'closed', '', 'template-featured-image-vertical', '', '', '2012-03-15 15:36:32', '2012-03-15 22:36:32', '', 0, 'http://wptest.io/demo/?p=1016', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1031, 1, '2010-09-09 17:23:27', '2010-09-10 00:23:27', 'This is a test for Jetpack\'s Tiled Gallery.

Install <a title="Jetpack for WordPress" href="http://wordpress.org/plugins/jetpack/" target="_blank">Jetpack</a> to test.

[gallery type="rectangular" columns="4" ids="755,757,758,760,766,763" orderby="rand"]

This is some text after the Tiled Gallery just to make sure that everything spaces nicely.', 'Post Format: Gallery (Tiled)', '', 'publish', 'closed', 'closed', '', 'post-format-gallery-tiled', '', '', '2010-09-09 17:23:27', '2010-09-10 00:23:27', '', 0, 'http://wptest.io/demo/?p=1031', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1133, 1, '2013-03-15 18:19:23', '2013-03-15 23:19:23', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.

On the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.
<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-580x300.jpg" width="580" height="300" /></p>
The image above happens to be <em><strong>centered</strong></em>.

<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-150x150.jpg" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>

As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!

And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.

<img class="alignnone  wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-1200x4002.jpg" width="1200" height="400" />

The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.

<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-300x200.jpg" width="300" height="200" />

And now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.

In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.

And just when you thought we were done, we\'re going to do them all over again with captions!

[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906  " title="Image Alignment 580x300" alt="Image Alignment 580x300" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-580x300.jpg" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]

The image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.

[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904  " title="Image Alignment 150x150" alt="Image Alignment 150x150" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-150x150.jpg" width="150" height="150" /> Itty-bitty caption.[/caption]

<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>

As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!

And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.

[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-1200x4002.jpg" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]

The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.

[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-300x200.jpg" width="300" height="200" /> Feels good to be right all the time.[/caption]

And now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.

In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.

And that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Page Image Alignment', '', 'publish', 'open', 'open', '', 'page-image-alignment', '', '', '2013-03-15 18:19:23', '2013-03-15 23:19:23', '', 135, 'http://wptest.io/demo/?page_id=1080', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1134, 1, '2013-03-15 18:20:05', '2013-03-15 23:20:05', '<strong>Headings</strong>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<tbody>
<tr>
<th>Employee</th>
<th class="views">Salary</th>
<th></th>
</tr>
<tr class="odd">
<td><a href="http://example.com/">Jane</a></td>
<td>$1</td>
<td>Because that\'s all Steve Job\' needed for a salary.</td>
</tr>
<tr class="even">
<td><a href="http://example.com">John</a></td>
<td>$100K</td>
<td>For all the blogging he does.</td>
</tr>
<tr class="odd">
<td><a href="http://example.com/">Jane</a></td>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Tom x 1,000.</td>
</tr>
<tr class="even">
<td><a href="http://example.com/">Jane</a></td>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag</strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag</strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Page Markup And Formatting', '', 'publish', 'open', 'open', '', 'page-markup-and-formatting', '', '', '2013-03-15 18:20:05', '2013-03-15 23:20:05', '', 135, 'http://wptest.io/demo/?page_id=1083', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1148, 1, '2012-01-03 10:11:37', '2012-01-03 17:11:37', 'This post tests comments in the following ways.
<ul>
	<li>Threaded comments up to 10 levels deep</li>
	<li>Paginated comments (set <em><strong>Settings &gt; Discussion &gt; Break comments into pages</strong></em> to <em><strong>5</strong></em> top level comments per page)</li>
	<li>Comment markup / formatting</li>
	<li>Comment images</li>
	<li>Comment videos</li>
	<li>Author comments</li>
	<li>Gravatars and default fallbacks</li>
</ul>', 'Template: Comments', '', 'publish', 'open', 'closed', '', 'template-comments', '', '', '2012-01-03 10:11:37', '2012-01-03 17:11:37', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/comment-test/', 0, 'post', '', 21) ; 
INSERT INTO `wp_posts` VALUES (1149, 1, '2012-01-01 10:17:18', '2012-01-01 17:17:18', 'This post has many pingpacks and trackbacks.

There are a few ways to list them.
<ol>
	<li>Above the comments</li>
	<li>Below the comments</li>
	<li>Included within the normal flow of comments</li>
</ol>', 'Template: Pingbacks And Trackbacks', '', 'publish', 'closed', 'closed', '', 'template-pingbacks-an-trackbacks', '', '', '2012-01-01 10:17:18', '2012-01-01 17:17:18', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/many-trackbacks/', 0, 'post', '', 5) ; 
INSERT INTO `wp_posts` VALUES (1150, 1, '2012-01-02 10:21:15', '2012-01-02 17:21:15', 'This post has its comments, pingbacks, and trackbacks disabled.

There should be no comment reply form, but <em>should</em> display pingbacks and trackbacks.', 'Template: Comments Disabled', '', 'publish', 'closed', 'closed', '', 'template-comments-disabled', '', '', '2012-01-02 10:21:15', '2012-01-02 17:21:15', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/no-comments/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1151, 1, '2009-06-01 01:00:34', '2009-06-01 08:00:34', 'This post has many tags.', 'Edge Case: Many Tags', '', 'publish', 'closed', 'closed', '', 'edge-case-many-tags', '', '', '2009-06-01 01:00:34', '2009-06-01 08:00:34', '', 0, 'http://wpthemetestdata.wordpress.com/2007/11/24/many-tags/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1152, 1, '2009-07-02 02:00:03', '2009-07-02 09:00:03', 'This post has many categories.', 'Edge Case: Many Categories', '', 'publish', 'closed', 'closed', '', 'edge-case-many-categories', '', '', '2009-07-02 02:00:03', '2009-07-02 09:00:03', '', 0, 'http://wpthemetestdata.wordpress.com/2007/11/24/many-categories/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1153, 1, '2020-01-01 12:00:18', '2020-01-01 19:00:18', 'This post is scheduled to be published in the future.

It should not be displayed by the theme.', 'Scheduled', '', 'future', 'closed', 'closed', '', 'scheduled', '', '', '2020-01-01 12:00:18', '2020-01-01 19:00:18', '', 0, 'http://wpthemetestdata.wordpress.com/?p=418', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1158, 1, '2010-08-08 05:00:39', '2010-08-08 12:00:39', '<img class="alignnone size-full wp-image-967" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/unicorn-wallpaper.jpg" alt="Unicorn Wallpaper" width="1600" height="1200" />

I really love this wallpaper. It makes me think fondly of <a title="Jane" href="http://example.com/" target="_blank">Jane</a>.', 'Post Format: Image', '', 'publish', 'closed', 'closed', '', 'post-format-image', '', '', '2014-05-08 12:17:18', '2014-05-08 12:17:18', '', 0, 'http://wpthemetestdata.wordpress.com/?p=568', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1161, 1, '2010-06-02 02:00:58', '2010-06-02 09:00:58', 'http://www.youtube.com/watch?v=nwe-H6l4beM

The official music video of "Rise Up" from <a title="Eddy Music" href="http://eddymusic.com/" target="_blank">Eddy\'s</a> <a title="Eddy - Start An Uproar! EP" href="http://bit.ly/bVmAyI" target="_blank">Start An Uproar!</a> EP.

Learn more about <a title="WordPress Embeds" href="http://codex.wordpress.org/Embeds" target="_blank">WordPress Embeds</a>.', 'Post Format: Video (YouTube)', '', 'publish', 'closed', 'closed', '', 'post-format-video-youtube', '', '', '2010-06-02 02:00:58', '2010-06-02 09:00:58', '', 0, 'http://wpthemetestdata.wordpress.com/?p=582', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1163, 1, '2010-08-07 06:00:19', '2010-08-07 13:00:19', '[caption id="attachment_1628" align="alignnone" width="808"]<img class="size-large wp-image-1628" alt="It’s dangerous to go alone! Take this." src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/04/triforce-wallpaper.jpg?w=808" width="808" height="505" /> It’s dangerous to go alone! Take this.[/caption]', 'Post Format: Image (Caption)', '', 'publish', 'closed', 'closed', '', 'post-format-image-caption', '', '', '2010-08-07 06:00:19', '2010-08-07 13:00:19', '', 0, 'http://wpthemetestdata.wordpress.com/?p=674', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1164, 1, '2013-04-09 11:20:39', '2013-04-09 18:20:39', 'This post is drafted and not published yet.

It should not be displayed by the theme.', 'Draft', '', 'draft', 'closed', 'closed', '', '', '', '', '2013-04-09 11:20:39', '2013-04-09 18:20:39', '', 0, 'http://wptest.io/demo/?p=922', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1168, 1, '2012-01-04 09:38:05', '2012-01-04 16:38:05', '<span style="line-height: 1.714285714; font-size: 1rem;">This content, comments, pingbacks, and trackbacks should not be visible until the password is entered.</span>', 'Template: Password Protected (the password is "enter")', '', 'publish', 'closed', 'closed', 'pass', 'template-password-protected', '', '', '2014-05-15 08:50:22', '2014-05-15 08:50:22', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/test-with-secret-password/', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (1169, 1, '2009-09-05 09:00:23', '2009-09-05 16:00:23', 'This post has no title, but it still must link to the single post view somehow.

This is typically done by placing the permalink on the post date.', '', '', 'publish', 'closed', 'closed', '', 'edge-case-no-title', '', '', '2009-09-05 09:00:23', '2009-09-05 16:00:23', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/14/', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1170, 1, '2009-08-06 09:39:56', '2009-08-06 16:39:56', '', 'Edge Case: No Content', '', 'publish', 'closed', 'closed', '', 'edge-case-no-content', '', '', '2009-08-06 09:39:56', '2009-08-06 16:39:56', '', 0, 'http://wpthemetestdata.wordpress.com/2007/09/04/this-post-has-no-body/', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (1171, 1, '2012-01-08 10:00:20', '2012-01-08 17:00:20', 'Post Page 1

<!--nextpage-->

Post Page 2

<!--nextpage-->

Post Page 3', 'Template: Paginated', '', 'publish', 'closed', 'closed', '', 'template-paginated', '', '', '2012-01-08 10:00:20', '2012-01-08 17:00:20', '', 0, 'http://noeltest.wordpress.com/?p=188', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1173, 1, '2013-01-05 10:00:49', '2013-01-05 17:00:49', 'Verify that:
<ul>
	<li><span style="line-height:1.714285714;font-size:1rem;">The post title renders the word "with" in </span><em style="line-height:1.714285714;font-size:1rem;">italics</em><span style="line-height:1.714285714;font-size:1rem;"> and the word "markup" in </span><strong style="line-height:1.714285714;font-size:1rem;">bold</strong><span style="line-height:1.714285714;font-size:1rem;">.</span></li>
	<li><span style="line-height:1.714285714;font-size:1rem;">The post title markup should be removed from the browser window / tab.</span></li>
</ul>', 'Markup: Title With Markup', '', 'publish', 'closed', 'closed', '', 'markup-title-with-markup', '', '', '2013-01-05 10:00:49', '2013-01-05 17:00:49', '', 0, 'http://wptest.io/demo/?p=861', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1174, 1, '2013-01-05 11:00:20', '2013-01-05 18:00:20', 'Putting special characters in the title should have no adverse effect on the layout or functionality.

Special characters in the post title have been known to cause issues with JavaScript when it is minified, especially in the admin when editing the post itself (ie. issues with metaboxes, media upload, etc.).
<h2>Latin Character Tests</h2>
This is a test to see if the fonts used in this theme support basic Latin characters.
<table>
<tbody>
<tr>
<td>!</td>
<td>"</td>
<td>#</td>
<td>$</td>
<td>%</td>
<td>&amp;</td>
<td>\'</td>
<td>(</td>
<td>)</td>
<td>*</td>
</tr>
<tr>
<td>+</td>
<td>,</td>
<td>-</td>
<td>.</td>
<td>/</td>
<td>0</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
</tr>
<tr>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>:</td>
<td>;</td>
<td>&gt;</td>
<td>=</td>
<td>&lt;</td>
</tr>
<tr>
<td>?</td>
<td>@</td>
<td>A</td>
<td>B</td>
<td>C</td>
<td>D</td>
<td>E</td>
<td>F</td>
<td>G</td>
<td>H</td>
</tr>
<tr>
<td>I</td>
<td>J</td>
<td>K</td>
<td>L</td>
<td>M</td>
<td>N</td>
<td>O</td>
<td>P</td>
<td>Q</td>
<td>R</td>
</tr>
<tr>
<td>S</td>
<td>T</td>
<td>U</td>
<td>V</td>
<td>W</td>
<td>X</td>
<td>Y</td>
<td>Z</td>
<td>[</td>
<td></td>
</tr>
<tr>
<td>]</td>
<td>^</td>
<td>_</td>
<td>`</td>
<td>a</td>
<td>b</td>
<td>c</td>
<td>d</td>
<td>e</td>
<td>f</td>
</tr>
<tr>
<td>g</td>
<td>h</td>
<td>i</td>
<td>j</td>
<td>k</td>
<td>l</td>
<td>m</td>
<td>n</td>
<td>o</td>
<td>p</td>
</tr>
<tr>
<td>q</td>
<td>r</td>
<td>s</td>
<td>t</td>
<td>u</td>
<td>v</td>
<td>w</td>
<td>x</td>
<td>y</td>
<td>z</td>
</tr>
<tr>
<td>{</td>
<td>|</td>
<td>}</td>
<td>~</td>
</tr>
</tbody>
</table>', 'Markup: Title With Special Characters ~`!@#$%^&*()-_=+{}[]/;:\'"?,.>', '', 'publish', 'closed', 'closed', '', 'title-with-special-characters', '', '', '2013-01-05 11:00:20', '2013-01-05 18:00:20', '', 0, 'http://wptest.io/demo/?p=867', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1175, 1, '2009-10-05 12:00:59', '2009-10-05 19:00:59', '<h2>Title should not overflow the content area</h2>

A few things to check for:
<ul>
	<li>Non-breaking text in the title, content, and comments should have no adverse effects on layout or functionality.</li>
	<li>Check the browser window / tab title.</li>
	<li>If you are a plugin or widget developer, check that this text does not break anything.</li>
</ul>

The following CSS properties will help you support non-breaking text.

<pre>-ms-word-wrap: break-word;
word-wrap: break-word;</pre>
&nbsp;', 'Antidisestablishmentarianism', '', 'publish', 'closed', 'closed', '', 'title-should-not-overflow-the-content-area', '', '', '2009-10-05 12:00:59', '2009-10-05 19:00:59', '', 0, 'http://wptest.io/demo/?p=877', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1176, 1, '2013-01-09 09:00:39', '2013-01-09 16:00:39', '<h3>Default</h3>
This is a paragraph. It should not have any alignment of any kind. It should just flow like you would normally expect. Nothing fancy. Just straight up text, free flowing, with love. Completely neutral and not picking a side or sitting on the fence. It just is. It just freaking is. It likes where it is. It does not feel compelled to pick a side. Leave him be. It will just be better that way. Trust me.
<h3>Left Align</h3>
<p style="text-align:left;">This is a paragraph. It is left aligned. Because of this, it is a bit more liberal in it\'s views. It\'s favorite color is green. Left align tends to be more eco-friendly, but it provides no concrete evidence that it really is. Even though it likes share the wealth evenly, it leaves the equal distribution up to justified alignment.</p>

<h3>Center Align</h3>
<p style="text-align:center;">This is a paragraph. It is center aligned. Center is, but nature, a fence sitter. A flip flopper. It has a difficult time making up its mind. It wants to pick a side. Really, it does. It has the best intentions, but it tends to complicate matters more than help. The best you can do is try to win it over and hope for the best. I hear center align does take bribes.</p>

<h3>Right Align</h3>
<p style="text-align:right;">This is a paragraph. It is right aligned. It is a bit more conservative in it\'s views. It\'s prefers to not be told what to do or how to do it. Right align totally owns a slew of guns and loves to head to the range for some practice. Which is cool and all. I mean, it\'s a pretty good shot from at least four or five football fields away. Dead on. So boss.</p>

<h3>Justify Align</h3>
<p style="text-align:justify;">This is a paragraph. It is justify aligned. It gets really mad when people associate it with Justin Timberlake. Typically, justified is pretty straight laced. It likes everything to be in it\'s place and not all cattywampus like the rest of the aligns. I am not saying that makes it better than the rest of the aligns, but it does tend to put off more of an elitist attitude.</p>', 'Markup: Text Alignment', '', 'publish', 'closed', 'closed', '', 'markup-text-alignment', '', '', '2013-01-09 09:00:39', '2013-01-09 16:00:39', '', 0, 'http://wptest.io/demo/?p=895', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1177, 1, '2013-01-10 20:15:40', '2013-01-11 03:15:40', '<span style="line-height:1.714285714;font-size:1rem;">Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.</span>

On the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.
<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-580x300.jpg" width="580" height="300" /></p>
The image above happens to be <em><strong>centered</strong></em>.

<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-150x150.jpg" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>

As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!

And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.

<img class="alignnone  wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-1200x4002.jpg" width="1200" height="400" />

The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.

<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-300x200.jpg" width="300" height="200" />

And now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.

In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.

And just when you thought we were done, we\'re going to do them all over again with captions!

[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906  " title="Image Alignment 580x300" alt="Image Alignment 580x300" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-580x300.jpg" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]

The image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.

[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904  " title="Image Alignment 150x150" alt="Image Alignment 150x150" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-150x150.jpg" width="150" height="150" /> Itty-bitty caption.[/caption]

<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>

As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!

And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.

[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-1200x4002.jpg" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]

The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.

[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/image-alignment-300x200.jpg" width="300" height="200" /> Feels good to be right all the time.[/caption]

And now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.

In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.

And that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Markup: Image Alignment', '', 'publish', 'closed', 'closed', '', 'markup-image-alignment', '', '', '2013-01-10 20:15:40', '2013-01-11 03:15:40', '', 0, 'http://wptest.io/demo/?p=903', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1178, 1, '2013-01-11 20:22:19', '2013-01-12 03:22:19', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!--nextpage--><!--pagetitle:Overview-->
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<!--nextpage-->
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'publish', 'closed', 'closed', '', 'markup-html-tags-and-formatting', '', '', '2014-04-14 13:24:46', '2014-04-14 13:24:46', '', 0, 'http://wptest.io/demo/?p=919', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1179, 1, '2011-03-15 15:47:16', '2011-03-15 22:47:16', 'https://twitter.com/nacin/status/319508408669708289

This post tests WordPress\' <a title="Twitter Embeds" href="http://en.support.wordpress.com/twitter/twitter-embeds/" target="_blank">Twitter Embeds</a> feature.', 'Media: Twitter Embeds', '', 'publish', 'closed', 'closed', '', 'media-twitter-embeds', '', '', '2011-03-15 15:47:16', '2011-03-15 22:47:16', '', 0, 'http://wptest.io/demo/?p=1027', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1241, 1, '2012-01-07 07:07:21', '2012-01-07 14:07:21', 'This is a sticky post.

There are a few things to verify:
<ul>
	<li>The sticky post should be distinctly recognizable in some way in comparison to normal posts. You can style the <code>.sticky</code> class if you are using the <a title="WordPress Codex post_class() Function" href="http://codex.wordpress.org/Function_Reference/post_class" target="_blank">post_class()</a> function to generate your post classes, which is a best practice.</li>
	<li>They should show at the very top of the blog index page, even though they could be several posts back chronologically.</li>
	<li>They should still show up again in their chronologically correct postion in time, but without the sticky indicator.</li>
	<li>If you have a plugin or widget that lists popular posts or comments, make sure that this sticky post is not always at the top of those lists unless it really is popular.</li>
</ul>', 'Template: Sticky', '', 'publish', 'closed', 'closed', '', 'template-sticky', '', '', '2012-01-07 07:07:21', '2012-01-07 14:07:21', '', 0, 'http://wptest.io/demo/?p=1241', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1446, 1, '2012-03-14 09:49:22', '2012-03-14 16:49:22', 'This is the post content. It should be displayed in place of the auto-generated excerpt in single-page views. Archive-index pages should display an auto-generated excerpt of this content. Depending on Theme-defined filters, the length of the auto-generated excerpt will vary from Theme-to-Theme. The default length for auto-generated excerpts is 55 words, so to test the excerpt auto-generation, this post must have more than 55 words.

Be sure to test the formatting of the auto-generated excerpt, to ensure that it doesn\'t create any layout problems. Also, ensure that any filters applied to the excerpt, such as &lt;code&gt;excerpt_length&lt;/code&gt; and &lt;code&gt;excerpt_more&lt;/code&gt;, display properly.', 'Template: Excerpt (Generated)', '', 'publish', 'closed', 'closed', '', 'template-excerpt-generated', '', '', '2012-03-14 09:49:22', '2012-03-14 16:49:22', '', 0, 'http://wpthemetestdata.wordpress.com/?p=1446', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1688, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1688', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1688/', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1689, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1689', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1689/', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1690, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1690', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1690/', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1691, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1691', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1691/', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1692, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1692', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1692/', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1693, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1693', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 135, 'http://127.0.0.1:4001/wordpress/1693/', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1694, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1694', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 173, 'http://127.0.0.1:4001/wordpress/1694/', 13, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1695, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1695', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 173, 'http://127.0.0.1:4001/wordpress/1695/', 14, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1696, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1696', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 174, 'http://127.0.0.1:4001/wordpress/1696/', 15, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1697, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1697', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 174, 'http://127.0.0.1:4001/wordpress/1697/', 16, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1698, 1, '2014-03-28 09:00:01', '2014-03-28 09:00:01', ' ', '', '', 'publish', 'open', 'open', '', '1698', '', '', '2014-03-28 09:00:01', '2014-03-28 09:00:01', '', 0, 'http://127.0.0.1:4001/wordpress/1698/', 19, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1752, 1, '2014-05-08 12:17:18', '2014-05-08 12:17:18', '<img class="alignnone size-full wp-image-967" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/unicorn-wallpaper.jpg" alt="Unicorn Wallpaper" width="1600" height="1200" />

I really love this wallpaper. It makes me think fondly of <a title="Jane" href="http://example.com/" target="_blank">Jane</a>.', 'Post Format: Image', '', 'inherit', 'open', 'open', '', '1158-revision-v1', '', '', '2014-05-08 12:17:18', '2014-05-08 12:17:18', '', 1158, 'http://127.0.0.1:4001/wordpress/2014/05/1158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1700, 1, '2014-03-28 09:50:46', '2014-03-28 09:50:46', ' ', '', '', 'publish', 'open', 'open', '', '1700', '', '', '2014-03-28 09:50:46', '2014-03-28 09:50:46', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1700', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1701, 1, '2014-03-28 09:50:46', '2014-03-28 09:50:46', ' ', '', '', 'publish', 'open', 'open', '', '1701', '', '', '2014-03-28 09:50:46', '2014-03-28 09:50:46', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1701', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1702, 1, '2014-03-28 09:50:46', '2014-03-28 09:50:46', ' ', '', '', 'publish', 'open', 'open', '', '1702', '', '', '2014-03-28 09:50:46', '2014-03-28 09:50:46', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1702', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1703, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1703', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1703', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1704, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1704', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1704', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1705, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1705', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1705', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1706, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1706', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1706', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1707, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1707', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1707', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1708, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1708', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1708', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1709, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1709', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 95, 'http://127.0.0.1:4001/wordpress/?p=1709', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1710, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1710', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 100, 'http://127.0.0.1:4001/wordpress/?p=1710', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1711, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1711', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1711', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1712, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1712', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1712', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1713, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1713', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 135, 'http://127.0.0.1:4001/wordpress/?p=1713', 11, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1714, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1714', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 135, 'http://127.0.0.1:4001/wordpress/?p=1714', 12, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1715, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1715', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 173, 'http://127.0.0.1:4001/wordpress/?p=1715', 13, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1716, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1716', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 173, 'http://127.0.0.1:4001/wordpress/?p=1716', 14, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1717, 1, '2014-03-28 09:51:08', '2014-03-28 09:51:08', ' ', '', '', 'publish', 'open', 'open', '', '1717', '', '', '2014-04-04 07:31:37', '2014-04-04 07:31:37', '', 174, 'http://127.0.0.1:4001/wordpress/?p=1717', 15, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1718, 1, '2014-04-01 08:53:19', '2014-04-01 08:53:19', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Page', '', 'inherit', 'open', 'open', '', '94-revision-v1', '', '', '2014-04-01 08:53:19', '2014-04-01 08:53:19', '', 94, 'http://127.0.0.1:4001/wordpress/2014/04/94-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1719, 1, '2014-04-02 12:53:37', '2014-04-02 12:53:37', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<img alt="" src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" />

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Image Page', '', 'inherit', 'open', 'open', '', '95-autosave-v1', '', '', '2014-04-02 12:53:37', '2014-04-02 12:53:37', '', 95, 'http://127.0.0.1:4001/wordpress/2014/04/95-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1721, 1, '2014-04-04 07:32:10', '2014-04-04 07:32:10', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickies to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://127.0.0.1:4001/wordpress/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-04-04 07:32:10', '2014-04-04 07:32:10', '', 2, 'http://127.0.0.1:4001/wordpress/2014/04/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1736, 1, '2014-04-14 13:24:46', '2014-04-14 13:24:46', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!--nextpage--><!--pagetitle:Overview-->
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<!--nextpage-->
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-14 13:24:46', '2014-04-14 13:24:46', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1723, 1, '2014-04-04 13:43:44', '2014-04-04 13:43:44', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<img alt="" src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" />

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Image Post', '', 'inherit', 'open', 'open', '', '89-revision-v1', '', '', '2014-04-04 13:43:44', '2014-04-04 13:43:44', '', 89, 'http://127.0.0.1:4001/wordpress/2014/04/89-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1761, 1, '2014-05-14 13:17:07', '2014-05-14 13:17:07', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/Chrysanthemum.jpg', 'Chrysanthemum.jpg', '', 'inherit', 'open', 'open', '', 'chrysanthemum-jpg', '', '', '2014-05-14 13:17:07', '2014-05-14 13:17:07', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/Chrysanthemum.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1725, 1, '2014-04-11 13:48:32', '2014-04-11 13:48:32', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd>&lt;!––nextpage––&gt; </dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 13:48:32', '2014-04-11 13:48:32', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1726, 1, '2014-04-11 14:05:18', '2014-04-11 14:05:18', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––><!––nextpage––><!––nextpage––>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-autosave-v1', '', '', '2014-04-11 14:05:18', '2014-04-11 14:05:18', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1733, 1, '2014-04-11 14:05:36', '2014-04-11 14:05:36', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:05:36', '2014-04-11 14:05:36', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1732, 1, '2014-04-11 14:05:20', '2014-04-11 14:05:20', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––><!––nextpage––><!––nextpage––>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:05:20', '2014-04-11 14:05:20', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1727, 1, '2014-04-11 13:49:00', '2014-04-11 13:49:00', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 13:49:00', '2014-04-11 13:49:00', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1728, 1, '2014-04-11 13:49:43', '2014-04-11 13:49:43', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<!––nextpage––> 
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 13:49:43', '2014-04-11 13:49:43', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1731, 1, '2014-04-11 14:02:14', '2014-04-11 14:02:14', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:02:14', '2014-04-11 14:02:14', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1729, 1, '2014-04-11 13:56:28', '2014-04-11 13:56:28', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––>
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<!––nextpage––> 
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 13:56:28', '2014-04-11 13:56:28', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1730, 1, '2014-04-11 14:01:33', '2014-04-11 14:01:33', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
[!––nextpage––]
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
[!––nextpage––] 
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:01:33', '2014-04-11 14:01:33', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1734, 1, '2014-04-11 14:07:54', '2014-04-11 14:07:54', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!––nextpage––><!--pagetitle:Overview-->
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:07:54', '2014-04-11 14:07:54', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1735, 1, '2014-04-11 14:08:15', '2014-04-11 14:08:15', '<h2>Headings</h2>
<h1>Header one</h1>
<h2>Header two</h2>
<h3>Header three</h3>
<h4>Header four</h4>
<h5>Header five</h5>
<h6>Header six</h6>
<h2>Blockquotes</h2>
<!--nextpage--><!--pagetitle:Overview-->
Single line blockquote:
<blockquote>Stay hungry. Stay foolish.</blockquote>
Multi line blockquote with a cite reference:
<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things. <cite>Steve Jobs - Apple Worldwide Developers\' Conference, 1997</cite></blockquote>
<h2>Tables</h2>
<table>
<thead>
<tr>
<th>Employee</th>
<th>Salary</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<th><a href="http://example.org/">John Doe</a></th>
<td>$1</td>
<td>Because that\'s all Steve Jobs needed for a salary.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Doe</a></th>
<td>$100K</td>
<td>For all the blogging she does.</td>
</tr>
<tr>
<th><a href="http://example.org/">Fred Bloggs</a></th>
<td>$100M</td>
<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
</tr>
<tr>
<th><a href="http://example.org/">Jane Bloggs</a></th>
<td>$100B</td>
<td>With hair like that?! Enough said...</td>
</tr>
</tbody>
</table>
<h2>Definition Lists</h2>
<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd><dd></dd><dd></dd></dl>
<h2>Unordered Lists (Nested)</h2>
<ul>
	<li>List item one
<ul>
	<li>List item one
<ul>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ul>
<h2>Ordered List (Nested)</h2>
<ol>
	<li>List item one
<ol>
	<li>List item one
<ol>
	<li>List item one</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
</li>
	<li>List item two</li>
	<li>List item three</li>
	<li>List item four</li>
</ol>
<h2>HTML Tags</h2>
These supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.

<strong>Address Tag</strong>

<address>1 Infinite Loop
Cupertino, CA 95014
United States</address><strong>Anchor Tag (aka. Link)</strong>

This is an example of a <a title="Apple" href="http://apple.com">link</a>.

<strong>Abbreviation Tag</strong>

The abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".

<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>

The acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".

<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

These tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.

<strong>Cite Tag</strong>

"Code is poetry." --<cite>Automattic</cite>

<strong>Code Tag</strong>

You will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.

<strong>Delete Tag</strong>

This tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).

<strong>Emphasize Tag</strong>

The emphasize tag should <em>italicize</em> text.

<strong>Insert Tag</strong>

This tag should denote <ins>inserted</ins> text.

<strong>Keyboard Tag</strong>

This scarsly known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Preformatted Tag</strong>

This tag styles large blocks of code.
<pre>.post-title {
	margin: 0 0 5px;
	font-weight: bold;
	font-size: 38px;
	line-height: 1.2;
	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
}</pre>
<strong>Quote Tag</strong>

<q>Developers, developers, developers...</q> --Steve Ballmer

<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This tag shows <span style="text-decoration: line-through;">strike-through text</span>

<strong>Strong Tag</strong>

This tag shows <strong>bold<strong> text.</strong></strong>

<strong>Subscript Tag</strong>

Getting our science styling on with H<sub>2</sub>O, which should push the "2" down.

<strong>Superscript Tag</strong>

Still sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.

<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>

This rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.

<strong>Variable Tag</strong>

This allows you to denote <var>variables</var>.', 'Markup: HTML Tags and Formatting', '', 'inherit', 'open', 'open', '', '1178-revision-v1', '', '', '2014-04-11 14:08:15', '2014-04-11 14:08:15', '', 1178, 'http://127.0.0.1:4001/wordpress/2014/04/1178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1737, 1, '2014-04-14 13:39:23', '2014-04-14 13:39:23', '', 'Chrysanthemum', '', 'inherit', 'open', 'open', '', 'chrysanthemum', '', '', '2014-04-14 13:39:23', '2014-04-14 13:39:23', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/Chrysanthemum.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1738, 1, '2014-04-14 13:39:31', '2014-04-14 13:39:31', '', 'Chrysanthemum', '', 'inherit', 'open', 'open', '', 'chrysanthemum-2', '', '', '2014-04-14 13:39:31', '2014-04-14 13:39:31', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/Chrysanthemum1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1739, 1, '2014-04-14 13:53:13', '2014-04-14 13:53:13', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-Penguins.jpg', 'cropped-Penguins.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-penguins-jpg', '', '', '2014-04-14 13:53:13', '2014-04-14 13:53:13', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-Penguins.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1740, 1, '2014-04-17 09:18:55', '2014-04-17 09:18:55', '', '_DSC0014', '', 'inherit', 'open', 'open', '', '_dsc0014', '', '', '2014-04-17 09:18:55', '2014-04-17 09:18:55', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/DSC0014.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1741, 1, '2014-04-17 09:19:34', '2014-04-17 09:19:34', '', '_DSC0024', '', 'inherit', 'open', 'open', '', '_dsc0024', '', '', '2014-04-17 09:19:34', '2014-04-17 09:19:34', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/DSC0024.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1742, 1, '2014-04-17 09:23:31', '2014-04-17 09:23:31', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-DSC_0093.jpg', 'cropped-DSC_0093.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-dsc_0093-jpg', '', '', '2014-04-17 09:23:31', '2014-04-17 09:23:31', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-DSC_0093.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1743, 1, '2014-04-17 10:00:48', '2014-04-17 10:00:48', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/sizedBlue%20Morpho%20Morpho%20peleides5335.jpg', 'sizedBlue%20Morpho%20Morpho%20peleides5335.jpg', '', 'inherit', 'open', 'open', '', 'sizedblue%20morpho%20morpho%20peleides5335-jpg', '', '', '2014-04-17 10:00:48', '2014-04-17 10:00:48', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/sizedBlue%20Morpho%20Morpho%20peleides5335.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1744, 1, '2014-04-17 10:01:35', '2014-04-17 10:01:35', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-ladybug-pictures.jpg', 'cropped-ladybug-pictures.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-ladybug-pictures-jpg', '', '', '2014-04-17 10:01:35', '2014-04-17 10:01:35', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-ladybug-pictures.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1745, 1, '2014-04-17 10:12:47', '2014-04-17 10:12:47', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-TG4ZZF2h.jpg', 'cropped-TG4ZZF2h.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-tg4zzf2h-jpg', '', '', '2014-04-17 10:12:47', '2014-04-17 10:12:47', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-TG4ZZF2h.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1747, 1, '2014-04-22 13:22:01', '2014-04-22 13:22:01', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-bro2.jpg.jpg', 'cropped-bro2.jpg.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-bro2-jpg-jpg', '', '', '2014-04-22 13:22:01', '2014-04-22 13:22:01', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-bro2.jpg.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1748, 1, '2014-04-24 15:46:35', '2014-04-24 15:46:35', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-header.jpg', 'cropped-header.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-header-jpg', '', '', '2014-04-24 15:46:35', '2014-04-24 15:46:35', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/04/cropped-header.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1750, 1, '2014-04-30 11:45:09', '2014-04-30 11:45:09', ' ', '', '', 'publish', 'open', 'closed', '', '1750', '', '', '2018-03-26 09:58:12', '2018-03-26 06:58:12', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1750', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1753, 1, '2014-05-08 12:17:25', '2014-05-08 12:17:25', '<img class="alignnone size-full wp-image-967" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2013/03/unicorn-wallpaper.jpg" alt="Unicorn Wallpaper" width="1600" height="1200" />

I really love this wallpaper. It makes me think fondly of <a title="Jane" href="http://example.com/" target="_blank">Jane</a>.', 'Post Format: Image', '', 'inherit', 'open', 'open', '', '1158-autosave-v1', '', '', '2014-05-08 12:17:25', '2014-05-08 12:17:25', '', 1158, 'http://127.0.0.1:4001/wordpress/2014/05/1158-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1754, 1, '2014-05-12 12:05:55', '2014-05-12 12:05:55', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/IMG_2579.jpg"><img src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/02/IMG_2579-300x200.jpg" alt="IMG_2579" width="300" height="200" class="aligncenter size-medium wp-image-127" /></a>[caption id="attachment_770" align="aligncenter" width="150"]<a href="http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_0767.jpg"><img src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2011/07/img_0767-150x150.jpg" alt="Huatulco Coastline" width="150" height="150" class="size-thumbnail wp-image-770" /></a> Coastline in Huatulco, Oaxaca, Mexico[/caption]', 'Headers Post', '', 'inherit', 'open', 'open', '', '93-autosave-v1', '', '', '2014-05-12 12:05:55', '2014-05-12 12:05:55', '', 93, 'http://127.0.0.1:4001/wordpress/2014/05/93-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1756, 1, '2014-05-13 14:54:00', '0000-00-00 00:00:00', 'New post', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-13 14:54:00', '2014-05-13 14:54:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1756', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1758, 1, '2014-05-14 08:25:36', '0000-00-00 00:00:00', '<blockquote><em><strong>sddadd</strong></em></blockquote>
jkhdajhdja', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-14 08:25:36', '2014-05-14 08:25:36', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1758', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1773, 1, '2014-06-26 07:21:46', '2014-06-26 07:21:46', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat dui tortor, vitae sollicitudin felis facilisis ut. In ac tortor id dui lobortis vestibulum vitae ac velit. Suspendisse accumsan est vitae justo tristique, viverra mattis tortor aliquet. Donec cursus ligula tincidunt est accumsan feugiat. Morbi a tristique est. Nulla a dolor nec neque facilisis tristique. Mauris imperdiet velit id sapien imperdiet pellentesque ac a nisi. Sed a dolor convallis, pharetra arcu sit amet, volutpat turpis. Cras condimentum velit pellentesque, aliquet orci et, lacinia felis. Aliquam placerat nisl vitae convallis porttitor. Sed a dignissim enim. Morbi eget libero in sapien adipiscing faucibus. Curabitur fringilla hendrerit ornare.

Sed eget laoreet ante. Quisque eget dui quis lorem laoreet egestas non et sem. Sed sollicitudin in lectus non scelerisque. Quisque accumsan laoreet pharetra. Quisque imperdiet, neque ac condimentum fermentum, leo nisl porta risus, vitae posuere tortor purus et odio. Nunc id venenatis dui. Nullam non ultricies nunc. Cras iaculis pulvinar eros, ac malesuada ante convallis sit amet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Etiam justo metus, hendrerit quis tortor non, scelerisque aliquam nulla. Vestibulum congue nulla ac leo vestibulum, in scelerisque libero tristique. Phasellus iaculis mauris elit, ut faucibus lectus ornare sit amet.', 'The WHITE Whale', '', 'publish', 'open', 'open', '', 'the-white-whale', '', '', '2014-06-27 13:35:26', '2014-06-27 13:35:26', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=project&#038;p=1773', 0, 'project', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1763, 1, '2014-05-14 13:44:43', '2014-05-14 13:44:43', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-735675_10151340077434490_1914316469_o.jpg', 'cropped-735675_10151340077434490_1914316469_o.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-735675_10151340077434490_1914316469_o-jpg', '', '', '2014-05-14 13:44:43', '2014-05-14 13:44:43', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-735675_10151340077434490_1914316469_o.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1764, 1, '2014-05-14 13:45:42', '2014-05-14 13:45:42', 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-966963_10151622422320600_2088357858_o.jpg', 'cropped-966963_10151622422320600_2088357858_o.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-966963_10151622422320600_2088357858_o-jpg', '', '', '2014-05-14 13:45:42', '2014-05-14 13:45:42', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2014/05/cropped-966963_10151622422320600_2088357858_o.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1767, 1, '2014-05-15 08:50:05', '2014-05-15 08:50:05', '<span style="line-height: 1.714285714; font-size: 1rem;">This content, comments, pingbacks, and trackbacks should not be visible until the password is entered.</span>', 'Template: Password Protected (the password is "enter")', '', 'inherit', 'open', 'open', '', '1168-revision-v1', '', '', '2014-05-15 08:50:05', '2014-05-15 08:50:05', '', 1168, 'http://127.0.0.1:4001/wordpress/2014/05/1168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1774, 1, '2014-06-26 07:26:41', '2014-06-26 07:26:41', '"What\'s that? There now\'s a patched professor in Queen Nature\'s granite-founded College; but methinks he\'s too subservient. Where wert thou born?" "In the little rocky Isle of Man, sir." "Excellent! Thou\'st hit the world by that." "I know not, sir, but I was born there." "In the Isle of Man, hey? Well, the other way, it\'s good. Here\'s a man from Man; a man born in once independent Man, and now unmanned of Man; which is sucked in&mdash;by what? Up with the reel! The dead, blind wall butts all inquiring heads at last. Up with it! So." The log was heaved. The loose coils rapidly straightened out in a long dragging line astern, and then, instantly, the reel began to whirl. In turn, jerkingly raised and lowered by the rolling billows, the towing resistance of the log caused the old reelman to stagger strangely. "Hold hard!" Snap! the overstrained line sagged down in one long festoon; the tugging log was gone. "I crush the quadrant, the thunder turns the needles, and now the mad sea parts the log-line. But Ahab can mend all. Haul in here, Tahitian; reel up, Manxman. And look ye, let the carpenter make another log, and mend thou the line. See to it." "There he goes now; to him nothing\'s happened; but to me.', 'What\'s that? There now\'s a patched professor in Queen', '', 'publish', 'open', 'open', '', 'whats-that-there-nows-a-patched-professor-in-queen', '', '', '2014-06-26 08:43:30', '2014-06-26 08:43:30', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=project&#038;p=1774', 0, 'project', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1775, 1, '2014-06-26 07:27:31', '2014-06-26 07:27:31', '"Tears are a strange sight upon Barsoom," she continued, "and so it is difficult for me to interpret them.  I have seen but two people weep in all my life, other than Dejah Thoris; one wept from sorrow, the other from baffled rage.  The first was my mother, years ago before they killed her; the other was Sarkoja, when they dragged her from me today." "Your mother!" I exclaimed, "but, Sola, you could not have known your mother, child." "But I did.  And my father also," she added.  "If you would like to hear the strange and un-Barsoomian story come to the chariot tonight, John Carter, and I will tell you that of which I have never spoken in all my life before.  And now the signal has been given to resume the march, you must go." "I will come tonight, Sola," I promised.  "Be sure to tell Dejah Thoris I am alive and well.  I shall not force myself upon her, and be sure that you do not let her know I saw her tears.  If she would speak with me I but await her command." Sola mounted the chariot, which was swinging into its place in line, and I hastened to my waiting thoat and galloped to my station beside Tars Tarkas at the rear of the column. We made a most imposing and awe-inspiring spectacle as', '"Tears are a strange sight upon Barsoom,"', '', 'publish', 'open', 'open', '', 'tears-are-a-strange-sight-upon-barsoom', '', '', '2014-06-27 13:31:35', '2014-06-27 13:31:35', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=project&#038;p=1775', 0, 'project', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1782, 1, '2014-08-04 13:22:08', '2014-07-23 10:42:29', 'Use add_theme_support( \'custom-background\', $args ) instead.
Deprecated in version 3.4.
<!--more-->
Used in wp-content/themes/modelun/library/siteframework.php on line 69.', 'Function: add_custom_background()', 'Used in wp-content/themes/modelun/library/siteframework.php on line 69.', 'publish', 'open', 'open', '', '44f643046a57bf09d80ca4e83b9a8acc', '', '', '2014-07-23 13:42:29', '2014-07-23 10:42:29', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1782', 0, 'deprecated_log', '', 53) ; 
INSERT INTO `wp_posts` VALUES (1778, 1, '2014-06-26 09:46:12', '2014-06-26 09:46:12', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Post', '', 'inherit', 'open', 'open', '', '93-revision-v1', '', '', '2014-06-26 09:46:12', '2014-06-26 09:46:12', '', 93, 'http://127.0.0.1:4001/wordpress/2014/06/93-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1779, 1, '2014-06-26 09:46:31', '2014-06-26 09:46:31', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Post', '', 'inherit', 'open', 'open', '', '92-revision-v1', '', '', '2014-06-26 09:46:31', '2014-06-26 09:46:31', '', 92, 'http://127.0.0.1:4001/wordpress/2014/06/92-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1797, 1, '2015-02-18 14:04:56', '2015-02-18 11:04:56', '', '10688275_1528986380691254_4638960547305208_o', '', 'inherit', 'open', 'open', '', '10688275_1528986380691254_4638960547305208_o', '', '', '2015-02-18 14:04:56', '2015-02-18 11:04:56', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2015/02/10688275_1528986380691254_4638960547305208_o.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (1783, 1, '2014-08-04 13:22:08', '2014-07-23 10:42:30', 'Use wp_get_theme() instead.
Deprecated in version 3.4.
<!--more-->
Used in wp-content/themes/modelun/theme-options.php on line 56.', 'Function: get_theme_data()', 'Used in wp-content/themes/modelun/theme-options.php on line 56.', 'publish', 'open', 'open', '', '56177b63dea8517b214506075ccd950d', '', '', '2014-07-23 13:42:30', '2014-07-23 10:42:30', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1783', 0, 'deprecated_log', '', 34) ; 
INSERT INTO `wp_posts` VALUES (1784, 1, '2014-08-04 13:21:59', '2014-07-23 10:42:31', 'Use wp_get_theme() instead.
Deprecated in version 3.4.
<!--more-->
Used in wp-content/themes/modelun/admin/inc/customfunctions.php on line 105.', 'Function: get_theme_data()', 'Used in wp-content/themes/modelun/admin/inc/customfunctions.php on line 105.', 'publish', 'open', 'open', '', '9d67f03ca5bf788df222ec15e08b1ed6', '', '', '2014-07-23 13:42:31', '2014-07-23 10:42:31', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1784', 0, 'deprecated_log', '', 14) ; 
INSERT INTO `wp_posts` VALUES (1785, 1, '2014-08-04 12:06:09', '2014-07-23 10:42:45', '"caller_get_posts" is deprecated. Use "ignore_sticky_posts" instead.
Deprecated in version 3.1.
<!--more-->
Used in wp-includes/query.php on line 3636.', 'Argument in WP_Query()', 'Used in wp-includes/query.php on line 3636.', 'publish', 'open', 'open', '', '6fd2c63e8ae5ba6ab0ef141b0b9a6d35', '', '', '2014-07-23 13:42:45', '2014-07-23 10:42:45', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1785', 0, 'deprecated_log', '', 6) ; 
INSERT INTO `wp_posts` VALUES (1787, 1, '2014-08-04 13:16:47', '0000-00-00 00:00:00', '', 'Sc Clogo', '', 'draft', 'closed', 'closed', '', 'of-sc_clogo', '', '', '2014-08-04 13:16:47', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1787', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1788, 1, '2014-08-04 13:16:50', '0000-00-00 00:00:00', '', 'Sc Custom Shortcut Favicon', '', 'draft', 'closed', 'closed', '', 'of-sc_custom_shortcut_favicon', '', '', '2014-08-04 13:16:50', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1788', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1789, 1, '2014-08-04 13:16:52', '0000-00-00 00:00:00', '', 'Sc Pageheaderurl', '', 'draft', 'closed', 'closed', '', 'of-sc_pageheaderurl', '', '', '2014-08-04 13:16:52', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1789', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1790, 1, '2014-08-04 13:16:55', '0000-00-00 00:00:00', '', 'Sc Homecontent1img', '', 'draft', 'closed', 'closed', '', 'of-sc_homecontent1img', '', '', '2014-08-04 13:16:55', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1790', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1791, 1, '2014-08-04 13:16:57', '0000-00-00 00:00:00', '', 'Sc Homecontent2img', '', 'draft', 'closed', 'closed', '', 'of-sc_homecontent2img', '', '', '2014-08-04 13:16:57', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1791', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1792, 1, '2014-08-04 13:16:58', '0000-00-00 00:00:00', '', 'Sc Homecontent3img', '', 'draft', 'closed', 'closed', '', 'of-sc_homecontent3img', '', '', '2014-08-04 13:16:58', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1792', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1793, 1, '2014-08-04 13:16:59', '0000-00-00 00:00:00', '', 'Sc Homecontent4img', '', 'draft', 'closed', 'closed', '', 'of-sc_homecontent4img', '', '', '2014-08-04 13:16:59', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=optionsframework&p=1793', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1794, 1, '2014-08-04 13:16:47', '2014-08-04 10:16:47', 'Use wp_get_theme() instead.
Deprecated in version 3.4.
<!--more-->
Used in wp-content/themes/modelun/admin/options-framework.php on line 192.', 'Function: get_theme_data()', 'Used in wp-content/themes/modelun/admin/options-framework.php on line 192.', 'publish', 'open', 'open', '', '0c594bf8686609c29c791abd5e08d2fb', '', '', '2014-08-04 13:16:47', '2014-08-04 10:16:47', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1794', 0, 'deprecated_log', '', 1) ; 
INSERT INTO `wp_posts` VALUES (1800, 1, '2018-03-26 05:58:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-03-26 05:58:46', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1800', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1801, 0, '2018-03-26 11:28:50', '2018-03-26 03:27:07', 'Use wpdb::esc_like() instead.
Deprecated in version 4.0.0.
<!--more-->
Used in wp-includes/functions.php on line 3826.', 'Function: like_escape()', 'Used in wp-includes/functions.php on line 3826.', 'publish', 'closed', 'closed', '', '136e3437cd9a45f6fcf4b450bbaebc05', '', '', '2018-03-26 06:27:07', '2018-03-26 03:27:07', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=deprecated_log&p=1801', 0, 'deprecated_log', '', 6) ; 
INSERT INTO `wp_posts` VALUES (1802, 1, '2018-03-26 06:32:03', '2018-03-26 03:32:03', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2018-03-26 06:32:03', '2018-03-26 03:32:03', '', 0, 'http://127.0.0.1:4001/wordpress/shop/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1803, 1, '2018-03-26 06:32:03', '2018-03-26 03:32:03', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2018-03-26 06:32:03', '2018-03-26 03:32:03', '', 0, 'http://127.0.0.1:4001/wordpress/cart/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1804, 1, '2018-03-26 06:32:03', '2018-03-26 03:32:03', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2018-03-26 06:32:03', '2018-03-26 03:32:03', '', 0, 'http://127.0.0.1:4001/wordpress/checkout/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1805, 1, '2018-03-26 06:32:03', '2018-03-26 03:32:03', '[woocommerce_my_account]', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2018-03-26 06:32:03', '2018-03-26 03:32:03', '', 0, 'http://127.0.0.1:4001/wordpress/my-account/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1806, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Beanie', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:33:57', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/beanie.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1807, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Belt', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:33:58', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/belt.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1808, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Cap', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:33:59', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/cap.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1809, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hoodie with Logo', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:00', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hoodie-with-logo.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1810, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hoodie with Pocket', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:00', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hoodie-with-pocket.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1811, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hoodie with Zipper', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:01', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hoodie-with-zipper.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1812, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hoodie', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:02', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hoodie.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1813, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Long Sleeve Tee', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:02', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/long-sleeve-tee.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1814, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Polo', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:03', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/polo.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1815, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Sunglasses', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:04', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/sunglasses.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1816, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Tshirt', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:05', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/tshirt.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1817, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Vneck Tshirt', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:05', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/vneck-tee.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1818, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hero', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:06', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hero.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1819, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Accessories', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:11', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/accessories.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1820, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'T-shirts', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:11', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/tshirts.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1821, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 'Hoodies', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:12', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/hoodies.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1822, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1822', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1823, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1823', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1824, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1824', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1825, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1825', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1826, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1826', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1827, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1827', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1828, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1828', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1829, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1829', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1830, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1830', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1831, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1831', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1832, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:13', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1832', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1833, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1833', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1834, 1, '2018-03-26 06:34:14', '0000-00-00 00:00:00', '{"nav_menus_created_posts":{"starter_content":true,"value":[1806,1807,1808,1809,1810,1811,1812,1813,1814,1815,1816,1817,1818,1819,1820,1821,1822,1823,1824,1825,1826,1827,1828,1829,1830,1831,1832,1833,1803,1804,1805,1802],"type":"option","user_id":1,"date_modified_gmt":"2018-03-26 03:34:14"}}', '', '', 'auto-draft', 'closed', 'closed', '', '4e337dbc-093e-41f5-adf9-185e718bf6f1', '', '', '2018-03-26 06:34:14', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1834', 0, 'customize_changeset', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1835, 1, '2018-03-26 06:37:41', '2018-03-26 03:37:41', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh', '', '', '2018-03-26 06:38:10', '2018-03-26 03:38:10', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1835', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1836, 1, '2018-03-26 06:36:51', '2018-03-26 03:36:51', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2018-03-26 06:36:51', '2018-03-26 03:36:51', '', 1835, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1837, 1, '2018-03-26 06:38:05', '2018-03-26 03:38:05', '', '1', '', 'inherit', 'open', 'closed', '', '1-2', '', '', '2018-03-26 06:38:05', '2018-03-26 03:38:05', '', 1835, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1838, 1, '2018-03-26 06:38:36', '2018-03-26 03:38:36', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh  1', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh-1', '', '', '2018-03-26 11:16:55', '2018-03-26 08:16:55', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1838', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1839, 1, '2018-03-26 06:38:55', '2018-03-26 03:38:55', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh 2', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh-2', '', '', '2018-03-26 11:16:47', '2018-03-26 08:16:47', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1839', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1840, 1, '2018-03-26 06:39:09', '2018-03-26 03:39:09', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh 3', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh-3', '', '', '2018-03-26 06:39:16', '2018-03-26 03:39:16', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1840', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1841, 1, '2018-03-26 06:39:34', '2018-03-26 03:39:34', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh 4', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh-4', '', '', '2018-03-26 10:37:12', '2018-03-26 07:37:12', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1841', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1842, 1, '2018-03-26 06:39:48', '2018-03-26 03:39:48', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh 5', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'o-to-go-luon-hinh-thong-minh-5', '', '', '2018-03-26 11:15:55', '2018-03-26 08:15:55', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1842', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1843, 1, '2018-03-26 07:19:52', '0000-00-00 00:00:00', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-03-26 07:19:52', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&p=1843', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1844, 1, '2018-03-26 07:56:05', '2018-03-26 04:56:05', '[products orderby="date" order="desc"]', '1', '', 'publish', 'closed', 'closed', '', '1-2', '', '', '2018-03-26 07:56:05', '2018-03-26 04:56:05', '', 0, 'http://127.0.0.1:4001/wordpress/?page_id=1844', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1845, 1, '2018-03-26 07:56:05', '2018-03-26 04:56:05', '[products orderby="date" order="desc"]', '1', '', 'inherit', 'closed', 'closed', '', '1844-revision-v1', '', '', '2018-03-26 07:56:05', '2018-03-26 04:56:05', '', 1844, 'http://127.0.0.1:4001/wordpress/1844-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1846, 1, '2018-03-26 09:57:08', '2018-03-26 06:57:08', ' ', '', '', 'publish', 'closed', 'closed', '', '1846', '', '', '2018-03-26 09:58:12', '2018-03-26 06:58:12', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1846', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1847, 1, '2018-03-26 09:57:09', '2018-03-26 06:57:09', ' ', '', '', 'publish', 'closed', 'closed', '', '1847', '', '', '2018-03-26 09:58:12', '2018-03-26 06:58:12', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1847', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1848, 1, '2018-03-26 09:57:09', '2018-03-26 06:57:09', ' ', '', '', 'publish', 'closed', 'closed', '', '1848', '', '', '2018-03-26 09:58:12', '2018-03-26 06:58:12', '', 0, 'http://127.0.0.1:4001/wordpress/?p=1848', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1849, 1, '2018-03-26 11:16:58', '2018-03-26 08:16:58', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'Ô tô gỗ luồn hình thông minh 5 (Copy)', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'draft', 'open', 'closed', '', '', '', '', '2018-03-26 11:16:58', '2018-03-26 08:16:58', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&p=1849', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1851, 1, '2018-03-26 11:18:07', '2018-03-26 08:18:07', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2018-03-26 11:18:07', '2018-03-26 08:18:07', '', 1850, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1852, 1, '2018-03-26 11:18:30', '2018-03-26 08:18:30', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'rubic go thong minh 1', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'rubic-go-thong-minh-1', '', '', '2018-03-26 11:19:07', '2018-03-26 08:19:07', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1852', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1853, 1, '2018-03-26 11:19:23', '2018-03-26 08:19:23', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'rubic go thong minh 2', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'rubic-go-thong-minh-2', '', '', '2018-03-26 11:19:37', '2018-03-26 08:19:37', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1853', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1854, 1, '2018-03-26 11:19:51', '2018-03-26 08:19:51', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'rubic go thong minh 3', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'rubic-go-thong-minh-3', '', '', '2018-03-26 11:20:00', '2018-03-26 08:20:00', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1854', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1855, 1, '2018-03-26 11:20:14', '2018-03-26 08:20:14', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'rubic go thong minh  4', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'rubic-go-thong-minh-4', '', '', '2018-03-26 11:20:23', '2018-03-26 08:20:23', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1855', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1856, 1, '2018-03-26 11:35:12', '2018-03-26 08:35:12', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'slider do choi go 01', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'slider-do-choi-go-01', '', '', '2018-03-26 11:36:50', '2018-03-26 08:36:50', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1856', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1857, 1, '2018-03-26 11:35:27', '2018-03-26 08:35:27', '', 'slider1', '', 'inherit', 'open', 'closed', '', 'slider1', '', '', '2018-03-26 11:35:27', '2018-03-26 08:35:27', '', 1856, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/slider1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (1858, 1, '2018-03-26 11:37:07', '2018-03-26 08:37:07', '<img class="alignnone size-medium wp-image-1836" src="http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/1-300x300.jpg" alt="" width="300" height="300" />', 'slider do choi go 02', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.

Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.

Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt.

Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.', 'publish', 'open', 'closed', '', 'slider-do-choi-go-02', '', '', '2018-03-26 12:06:32', '2018-03-26 09:06:32', '', 0, 'http://127.0.0.1:4001/wordpress/?post_type=product&#038;p=1858', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1859, 1, '2018-03-26 12:07:35', '2018-03-26 09:07:35', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2018-03-26 12:07:35', '2018-03-26 09:07:35', '', 0, 'http://127.0.0.1:4001/wordpress/wp-content/uploads/2018/03/logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (1860, 1, '2018-03-26 12:07:45', '2018-03-26 09:07:45', '{"mazpage_theme_options[site_logo]":{"value":"http:\\/\\/127.0.0.1:4001\\/wordpress\\/wp-content\\/uploads\\/2018\\/03\\/logo.png","type":"option","user_id":1,"date_modified_gmt":"2018-03-26 09:07:45"}}', '', '', 'trash', 'closed', 'closed', '', '7a6484c3-8407-4d5e-b8a5-8a72b8bbb75e', '', '', '2018-03-26 12:07:45', '2018-03-26 09:07:45', '', 0, 'http://127.0.0.1:4001/wordpress/7a6484c3-8407-4d5e-b8a5-8a72b8bbb75e/', 0, 'customize_changeset', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (568 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (9, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (10, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (11, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (12, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (13, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (14, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (15, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (16, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (17, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (18, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (19, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (20, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (21, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (22, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (23, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (31, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (33, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (35, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (52, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (53, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (48, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (49, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (51, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (50, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (58, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1852, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1849, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1849, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1849, 240, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1050, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1849, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1049, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1838, 240, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1839, 240, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1048, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1047, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1842, 240, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1046, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (112, 18, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (111, 18, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (110, 18, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1841, 240, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (93, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (92, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (91, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (90, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (88, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1051, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1052, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1053, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1054, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1055, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1056, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1057, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1058, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1059, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1060, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1061, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1062, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1063, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1064, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1065, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1066, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1629, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1630, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1631, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1632, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1633, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1634, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1635, 191, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1636, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1637, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1638, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1639, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1640, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1641, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1642, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1643, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1644, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1645, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1646, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1647, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (555, 195, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (358, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (358, 160, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (358, 165, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (358, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (555, 116, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (555, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (555, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (555, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (559, 196, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (559, 86, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (559, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (559, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (562, 197, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (562, 90, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (562, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (562, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (565, 198, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (565, 129, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (565, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (565, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (568, 199, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (568, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (568, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (568, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (575, 200, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (575, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (575, 157, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (575, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (579, 201, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (579, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (579, 166, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (579, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 202, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 104, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 184, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 188, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (582, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (587, 203, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (587, 87, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (587, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (587, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (587, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (993, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (993, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (993, 108, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (993, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (993, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (996, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (996, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (996, 159, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (996, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (996, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 202, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 130, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1000, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 104, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 126, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 184, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 185, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1005, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 94, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 110, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1011, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 94, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 110, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1016, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 195, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 116, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 126, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 178, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1031, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1148, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1148, 95, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1148, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1148, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 95, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 147, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 180, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1149, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1150, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1150, 95, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1150, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1150, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 89, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 83, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 84, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 85, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 88, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 89, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 90, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 94, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 95, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 102, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 104, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 108, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 109, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 110, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 114, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 115, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 116, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 122, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 126, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 128, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 129, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 132, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 139, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 140, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 141, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 146, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 157, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 165, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 168, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 169, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 173, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 179, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 181, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 183, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 184, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 185, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 187, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 188, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1151, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 19, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 22, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 24, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 25, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 26, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 27, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 28, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 29, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 30, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 74, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 75, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 76, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 77, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 78, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 79, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 80, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 32, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 33, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 34, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 35, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 37, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 38, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 39, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 40, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 81, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 41, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 42, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 82, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 43, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 44, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 45, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 47, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 48, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 49, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 50, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 51, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 52, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 53, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 54, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 56, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 57, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 58, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 59, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 60, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 61, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 62, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 63, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 64, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 65, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 67, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 68, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 69, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 70, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 71, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 72, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 73, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1152, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1158, 199, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1153, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1153, 67, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1158, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1158, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1158, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1161, 202, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1161, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1161, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1163, 199, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1163, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1163, 151, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1163, 163, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1163, 55, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1168, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1164, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1164, 67, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1168, 145, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1168, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1168, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1171, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1169, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1169, 128, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1169, 179, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1169, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1170, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1170, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1170, 128, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1170, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1171, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1171, 143, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1171, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1171, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1241, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1173, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1173, 122, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1173, 179, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1173, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1174, 122, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1174, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1174, 150, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1174, 179, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1174, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 103, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 122, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 128, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 179, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1175, 36, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1176, 84, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1176, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1176, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1176, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1176, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 84, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 88, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1177, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 98, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 113, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 122, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 133, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1178, 46, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1179, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1179, 104, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1179, 134, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1179, 181, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1179, 47, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1241, 167, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1241, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1446, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1446, 96, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1446, 108, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1446, 174, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1446, 66, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1688, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1689, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1690, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1691, 193, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1692, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1693, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1694, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1695, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1696, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1697, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1698, 190, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1700, 204, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1701, 204, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1702, 204, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1703, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1704, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1705, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1706, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1707, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1708, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1709, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1710, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1711, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1712, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1713, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1714, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1715, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1716, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1717, 205, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (88, 206, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (88, 137, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (88, 22, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 206, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 207, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 123, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1750, 17, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1756, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1758, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (91, 208, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (91, 209, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (91, 210, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1773, 211, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1773, 212, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1773, 213, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1774, 214, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1774, 215, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1774, 211, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1775, 216, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1775, 217, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1775, 212, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1775, 218, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1774, 218, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (90, 221, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (93, 220, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (92, 221, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1822, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1823, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1824, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1825, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1826, 237, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1827, 237, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1828, 237, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1829, 237, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1830, 238, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1831, 238, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1832, 238, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1833, 238, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1822, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1823, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1824, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1825, 228, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1825, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1826, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1827, 228, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1827, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1828, 228, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1828, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1829, 228, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1829, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1830, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1831, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1832, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1833, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1835, 235, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1835, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1838, 235, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1838, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1839, 235, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1839, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1840, 235, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1840, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1841, 235, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1841, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1842, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1842, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1842, 236, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1846, 17, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1847, 17, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1848, 17, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1852, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1850, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1850, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1850, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1852, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1853, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1853, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1853, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1854, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1854, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1854, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1855, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1855, 239, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1855, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1856, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1858, 242, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1856, 222, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1856, 243, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1858, 243, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1858, 222, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=244 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (243 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 22) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 216, 'link_category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'category', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'category', '', 3, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'category', '', 3, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'category', '', 5, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'category', '', 7, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'post_tag', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (13, 13, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (14, 14, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (15, 15, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (16, 16, 'post_tag', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (17, 17, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (18, 18, 'nav_menu', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (19, 19, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (20, 20, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (21, 21, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (22, 22, 'category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (23, 2, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (24, 23, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (25, 24, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (26, 25, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (27, 26, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (28, 27, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (29, 28, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (30, 29, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (31, 30, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (32, 31, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (33, 32, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (34, 33, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (35, 34, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (36, 35, 'category', 'Posts that have edge-case related tests', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (37, 36, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (38, 37, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (39, 38, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (40, 39, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (41, 40, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (42, 41, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (43, 42, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (44, 43, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (45, 44, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (46, 45, 'category', 'Posts in this category test markup tags and styles.', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (47, 46, 'category', 'Posts that have media-related tests', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (48, 47, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (49, 48, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (50, 49, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (51, 50, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (52, 51, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (53, 52, 'category', 'This is a parent category. It will contain child categories', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (54, 53, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (55, 54, 'category', 'Posts in this category test post formats.', 0, 16) ; 
INSERT INTO `wp_term_taxonomy` VALUES (56, 55, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (57, 56, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (58, 57, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (59, 58, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (60, 59, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (61, 60, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (62, 61, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (63, 62, 'category', '', 19, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (64, 63, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (65, 64, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (66, 65, 'category', 'Posts with template-related tests', 0, 10) ; 
INSERT INTO `wp_term_taxonomy` VALUES (67, 66, 'category', 'Posts in this category test unpublished posts.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (68, 67, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (69, 68, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (70, 69, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (71, 70, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (72, 71, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (73, 72, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (74, 73, 'category', '', 51, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (75, 74, 'category', '', 73, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (76, 75, 'category', 'This is a description for the Child Category 01.', 52, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (77, 76, 'category', 'This is a description for the Child Category 02.', 52, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (78, 77, 'category', 'This is a description for the Child Category 03.', 52, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (79, 78, 'category', 'This is a description for the Child Category 04.', 52, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (80, 79, 'category', 'This is a description for the Child Category 05.', 52, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (81, 80, 'category', '', 40, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (82, 81, 'category', 'This is a description for the Grandchild Category.', 77, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (83, 82, 'post_tag', 'Tags posts about 8BIT.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (84, 83, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (85, 84, 'post_tag', 'Tags posts about Articles.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (86, 85, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (87, 86, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (88, 87, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (89, 88, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (90, 89, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (91, 90, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (92, 91, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (93, 92, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (94, 93, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (95, 94, 'post_tag', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (96, 95, 'post_tag', '', 0, 12) ; 
INSERT INTO `wp_term_taxonomy` VALUES (97, 96, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (98, 97, 'post_tag', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (99, 98, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (100, 99, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (101, 100, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (102, 101, 'post_tag', 'Tags posts about #dowork.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (103, 102, 'post_tag', '', 0, 8) ; 
INSERT INTO `wp_term_taxonomy` VALUES (104, 103, 'post_tag', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (105, 104, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (106, 105, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (107, 106, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (108, 107, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (109, 108, 'post_tag', 'Tags posts about fail.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (110, 109, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (111, 110, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (112, 111, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (113, 112, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (114, 113, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (115, 114, 'post_tag', 'Tags posts about fun.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (116, 115, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (117, 116, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (118, 117, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (119, 118, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (120, 119, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (121, 120, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (122, 121, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (123, 122, 'post_tag', '', 0, 8) ; 
INSERT INTO `wp_term_taxonomy` VALUES (124, 123, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (125, 124, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (126, 125, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (127, 126, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (128, 127, 'post_tag', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (129, 128, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (130, 129, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (131, 130, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (132, 131, 'post_tag', 'Tags posts about love.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (133, 132, 'post_tag', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (134, 133, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (135, 134, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (136, 135, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (137, 136, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (138, 137, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (139, 138, 'post_tag', 'Tags posts about motherships.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (140, 139, 'post_tag', 'Tags posts about articles you must read.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (141, 140, 'post_tag', 'Tags posts about that nailed it.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (142, 141, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (143, 142, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (144, 143, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (145, 144, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (146, 145, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (147, 146, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (148, 147, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (149, 148, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (150, 149, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (151, 220, 'post_tag', '', 0, 16) ; 
INSERT INTO `wp_term_taxonomy` VALUES (152, 150, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (153, 151, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (154, 152, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (155, 153, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (156, 154, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (157, 155, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (158, 156, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (159, 157, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (160, 158, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (161, 159, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (162, 160, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (163, 161, 'post_tag', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (164, 162, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (165, 163, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (166, 164, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (167, 165, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (168, 166, 'post_tag', 'Tags posts about success.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (169, 167, 'post_tag', 'Tags posts about swagger.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (170, 168, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (171, 169, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (172, 170, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (173, 171, 'post_tag', 'Tags posts about tags. #inception', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (174, 172, 'post_tag', '', 0, 12) ; 
INSERT INTO `wp_term_taxonomy` VALUES (175, 173, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (176, 174, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (177, 175, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (178, 176, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (179, 177, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (180, 178, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (181, 179, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (182, 180, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (183, 181, 'post_tag', 'Tags posts about things that cannot be unseen.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (184, 182, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (185, 183, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (186, 184, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (187, 185, 'post_tag', 'Tags posts about WordPress.', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (188, 186, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (189, 187, 'post_tag', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (190, 188, 'nav_menu', '', 0, 19) ; 
INSERT INTO `wp_term_taxonomy` VALUES (191, 189, 'nav_menu', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (192, 190, 'nav_menu', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (193, 191, 'nav_menu', '', 0, 25) ; 
INSERT INTO `wp_term_taxonomy` VALUES (194, 192, 'nav_menu', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (195, 193, 'post_format', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (196, 194, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (197, 195, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (198, 196, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (199, 197, 'post_format', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (200, 198, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (201, 199, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (202, 200, 'post_format', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (203, 201, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (204, 202, 'nav_menu', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (205, 203, 'nav_menu', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (206, 204, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (207, 205, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (208, 206, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (209, 207, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (210, 208, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (211, 217, 'tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (212, 218, 'tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (213, 219, 'tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (214, 221, 'tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (215, 209, 'tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (216, 210, 'tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (217, 211, 'tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (218, 212, 'project_category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (219, 213, 'location', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (220, 214, 'location', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (221, 215, 'location', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (222, 222, 'product_type', '', 0, 13) ; 
INSERT INTO `wp_term_taxonomy` VALUES (223, 223, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (224, 224, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (225, 225, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (226, 226, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (227, 227, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (228, 228, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (229, 229, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (230, 230, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (231, 231, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (232, 232, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (233, 233, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (234, 234, 'product_visibility', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (235, 235, 'product_cat', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (236, 236, 'product_cat', 'A short category description', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (237, 237, 'product_cat', 'A short category description', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (238, 238, 'product_cat', 'A short category description', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (239, 239, 'product_tag', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (240, 240, 'product_cat', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (241, 241, 'product_cat', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (242, 242, 'product_cat', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (243, 243, 'product_tag', '', 0, 2) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_termmeta (20 records)
#
 
INSERT INTO `wp_termmeta` VALUES (1, 236, 'thumbnail_id', '1819') ; 
INSERT INTO `wp_termmeta` VALUES (2, 236, 'product_count_product_cat', '1') ; 
INSERT INTO `wp_termmeta` VALUES (3, 237, 'thumbnail_id', '1821') ; 
INSERT INTO `wp_termmeta` VALUES (4, 237, 'product_count_product_cat', '0') ; 
INSERT INTO `wp_termmeta` VALUES (5, 238, 'thumbnail_id', '1820') ; 
INSERT INTO `wp_termmeta` VALUES (6, 238, 'product_count_product_cat', '0') ; 
INSERT INTO `wp_termmeta` VALUES (7, 235, 'product_count_product_cat', '5') ; 
INSERT INTO `wp_termmeta` VALUES (8, 239, 'product_count_product_tag', '6') ; 
INSERT INTO `wp_termmeta` VALUES (9, 240, 'order', '0') ; 
INSERT INTO `wp_termmeta` VALUES (10, 240, 'display_type', '') ; 
INSERT INTO `wp_termmeta` VALUES (11, 240, 'thumbnail_id', '0') ; 
INSERT INTO `wp_termmeta` VALUES (12, 241, 'order', '0') ; 
INSERT INTO `wp_termmeta` VALUES (13, 241, 'display_type', '') ; 
INSERT INTO `wp_termmeta` VALUES (14, 241, 'thumbnail_id', '0') ; 
INSERT INTO `wp_termmeta` VALUES (15, 242, 'order', '0') ; 
INSERT INTO `wp_termmeta` VALUES (16, 242, 'display_type', '') ; 
INSERT INTO `wp_termmeta` VALUES (17, 242, 'thumbnail_id', '0') ; 
INSERT INTO `wp_termmeta` VALUES (18, 240, 'product_count_product_cat', '4') ; 
INSERT INTO `wp_termmeta` VALUES (19, 242, 'product_count_product_cat', '7') ; 
INSERT INTO `wp_termmeta` VALUES (20, 243, 'product_count_product_tag', '2') ;
#
# End of data contents of table wp_termmeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=244 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (243 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Parent Category I', 'parent-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Parent Category II', 'parent-category-ii', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Parent Category III', 'parent-category-iii', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'Child Category I', 'child-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'Child Category II', 'child-category-ii', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'Child Category III', 'child-category-iii', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'Grandchild Category I', 'grandchild-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (10, 'tag1', 'tag1', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'tag2', 'tag2', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'tag3', 'tag3', 0) ; 
INSERT INTO `wp_terms` VALUES (13, 'tag4', 'tag4', 0) ; 
INSERT INTO `wp_terms` VALUES (14, 'tag5', 'tag5', 0) ; 
INSERT INTO `wp_terms` VALUES (15, 'tag6', 'tag6', 0) ; 
INSERT INTO `wp_terms` VALUES (16, 'tag7', 'tag7', 0) ; 
INSERT INTO `wp_terms` VALUES (17, 'Menu 1', 'menu-1', 0) ; 
INSERT INTO `wp_terms` VALUES (18, 'Menu 2', 'menu-2', 0) ; 
INSERT INTO `wp_terms` VALUES (19, 'aciform', 'aciform', 0) ; 
INSERT INTO `wp_terms` VALUES (20, 'antiquarianism', 'antiquarianism', 0) ; 
INSERT INTO `wp_terms` VALUES (21, 'arrangement', 'arrangement', 0) ; 
INSERT INTO `wp_terms` VALUES (22, 'asmodeus', 'asmodeus', 0) ; 
INSERT INTO `wp_terms` VALUES (23, 'broder', 'broder', 0) ; 
INSERT INTO `wp_terms` VALUES (24, 'buying', 'buying', 0) ; 
INSERT INTO `wp_terms` VALUES (25, 'Cat A', 'cat-a', 0) ; 
INSERT INTO `wp_terms` VALUES (26, 'Cat B', 'cat-b', 0) ; 
INSERT INTO `wp_terms` VALUES (27, 'Cat C', 'cat-c', 0) ; 
INSERT INTO `wp_terms` VALUES (28, 'championship', 'championship', 0) ; 
INSERT INTO `wp_terms` VALUES (29, 'chastening', 'chastening', 0) ; 
INSERT INTO `wp_terms` VALUES (30, 'clerkship', 'clerkship', 0) ; 
INSERT INTO `wp_terms` VALUES (31, 'disinclination', 'disinclination', 0) ; 
INSERT INTO `wp_terms` VALUES (32, 'disinfection', 'disinfection', 0) ; 
INSERT INTO `wp_terms` VALUES (33, 'dispatch', 'dispatch', 0) ; 
INSERT INTO `wp_terms` VALUES (34, 'echappee', 'echappee', 0) ; 
INSERT INTO `wp_terms` VALUES (35, 'Edge Case', 'edge-case-2', 0) ; 
INSERT INTO `wp_terms` VALUES (36, 'enphagy', 'enphagy', 0) ; 
INSERT INTO `wp_terms` VALUES (37, 'equipollent', 'equipollent', 0) ; 
INSERT INTO `wp_terms` VALUES (38, 'fatuity', 'fatuity', 0) ; 
INSERT INTO `wp_terms` VALUES (39, 'Foo A', 'foo-a', 0) ; 
INSERT INTO `wp_terms` VALUES (40, 'Foo Parent', 'foo-parent', 0) ; 
INSERT INTO `wp_terms` VALUES (41, 'gaberlunzie', 'gaberlunzie', 0) ; 
INSERT INTO `wp_terms` VALUES (42, 'illtempered', 'illtempered', 0) ; 
INSERT INTO `wp_terms` VALUES (43, 'insubordination', 'insubordination', 0) ; 
INSERT INTO `wp_terms` VALUES (44, 'lender', 'lender', 0) ; 
INSERT INTO `wp_terms` VALUES (45, 'Markup', 'markup', 0) ; 
INSERT INTO `wp_terms` VALUES (46, 'Media', 'media-2', 0) ; 
INSERT INTO `wp_terms` VALUES (47, 'monosyllable', 'monosyllable', 0) ; 
INSERT INTO `wp_terms` VALUES (48, 'packthread', 'packthread', 0) ; 
INSERT INTO `wp_terms` VALUES (49, 'palter', 'palter', 0) ; 
INSERT INTO `wp_terms` VALUES (50, 'papilionaceous', 'papilionaceous', 0) ; 
INSERT INTO `wp_terms` VALUES (51, 'Parent', 'parent', 0) ; 
INSERT INTO `wp_terms` VALUES (52, 'Parent Category', 'parent-category', 0) ; 
INSERT INTO `wp_terms` VALUES (53, 'personable', 'personable', 0) ; 
INSERT INTO `wp_terms` VALUES (54, 'Post Formats', 'post-formats', 0) ; 
INSERT INTO `wp_terms` VALUES (55, 'propylaeum', 'propylaeum', 0) ; 
INSERT INTO `wp_terms` VALUES (56, 'pustule', 'pustule', 0) ; 
INSERT INTO `wp_terms` VALUES (57, 'quartern', 'quartern', 0) ; 
INSERT INTO `wp_terms` VALUES (58, 'scholarship', 'scholarship', 0) ; 
INSERT INTO `wp_terms` VALUES (59, 'selfconvicted', 'selfconvicted', 0) ; 
INSERT INTO `wp_terms` VALUES (60, 'showshoe', 'showshoe', 0) ; 
INSERT INTO `wp_terms` VALUES (61, 'sloyd', 'sloyd', 0) ; 
INSERT INTO `wp_terms` VALUES (62, 'sub', 'sub', 0) ; 
INSERT INTO `wp_terms` VALUES (63, 'sublunary', 'sublunary', 0) ; 
INSERT INTO `wp_terms` VALUES (64, 'tamtam', 'tamtam', 0) ; 
INSERT INTO `wp_terms` VALUES (65, 'Template', 'template-2', 0) ; 
INSERT INTO `wp_terms` VALUES (66, 'Unpublished', 'unpublished', 0) ; 
INSERT INTO `wp_terms` VALUES (67, 'weakhearted', 'weakhearted', 0) ; 
INSERT INTO `wp_terms` VALUES (68, 'ween', 'ween', 0) ; 
INSERT INTO `wp_terms` VALUES (69, 'wellhead', 'wellhead', 0) ; 
INSERT INTO `wp_terms` VALUES (70, 'wellintentioned', 'wellintentioned', 0) ; 
INSERT INTO `wp_terms` VALUES (71, 'whetstone', 'whetstone', 0) ; 
INSERT INTO `wp_terms` VALUES (72, 'years', 'years', 0) ; 
INSERT INTO `wp_terms` VALUES (73, 'Child 1', 'child-1', 0) ; 
INSERT INTO `wp_terms` VALUES (74, 'Child 2', 'child-2', 0) ; 
INSERT INTO `wp_terms` VALUES (75, 'Child Category 01', 'child-category-01', 0) ; 
INSERT INTO `wp_terms` VALUES (76, 'Child Category 02', 'child-category-02', 0) ; 
INSERT INTO `wp_terms` VALUES (77, 'Child Category 03', 'child-category-03', 0) ; 
INSERT INTO `wp_terms` VALUES (78, 'Child Category 04', 'child-category-04', 0) ; 
INSERT INTO `wp_terms` VALUES (79, 'Child Category 05', 'child-category-05', 0) ; 
INSERT INTO `wp_terms` VALUES (80, 'Foo A', 'foo-a-foo-parent', 0) ; 
INSERT INTO `wp_terms` VALUES (81, 'Grandchild Category', 'grandchild-category', 0) ; 
INSERT INTO `wp_terms` VALUES (82, '8BIT', '8bit', 0) ; 
INSERT INTO `wp_terms` VALUES (83, 'alignment', 'alignment-2', 0) ; 
INSERT INTO `wp_terms` VALUES (84, 'Articles', 'articles', 0) ; 
INSERT INTO `wp_terms` VALUES (85, 'aside', 'aside', 0) ; 
INSERT INTO `wp_terms` VALUES (86, 'audio', 'audio', 0) ; 
INSERT INTO `wp_terms` VALUES (87, 'captions', 'captions-2', 0) ; 
INSERT INTO `wp_terms` VALUES (88, 'categories', 'categories', 0) ; 
INSERT INTO `wp_terms` VALUES (89, 'chat', 'chat', 0) ; 
INSERT INTO `wp_terms` VALUES (90, 'chattels', 'chattels', 0) ; 
INSERT INTO `wp_terms` VALUES (91, 'cienaga', 'cienaga', 0) ; 
INSERT INTO `wp_terms` VALUES (92, 'claycold', 'claycold', 0) ; 
INSERT INTO `wp_terms` VALUES (93, 'Codex', 'codex', 0) ; 
INSERT INTO `wp_terms` VALUES (94, 'comments', 'comments-2', 0) ; 
INSERT INTO `wp_terms` VALUES (95, 'content', 'content-2', 0) ; 
INSERT INTO `wp_terms` VALUES (96, 'crushing', 'crushing', 0) ; 
INSERT INTO `wp_terms` VALUES (97, 'css', 'css', 0) ; 
INSERT INTO `wp_terms` VALUES (98, 'depo', 'depo', 0) ; 
INSERT INTO `wp_terms` VALUES (99, 'dinarchy', 'dinarchy', 0) ; 
INSERT INTO `wp_terms` VALUES (100, 'doolie', 'doolie', 0) ; 
INSERT INTO `wp_terms` VALUES (101, 'dowork', 'dowork', 0) ; 
INSERT INTO `wp_terms` VALUES (102, 'edge case', 'edge-case', 0) ; 
INSERT INTO `wp_terms` VALUES (103, 'embeds', 'embeds-2', 0) ; 
INSERT INTO `wp_terms` VALUES (104, 'energumen', 'energumen', 0) ; 
INSERT INTO `wp_terms` VALUES (105, 'ephialtes', 'ephialtes', 0) ; 
INSERT INTO `wp_terms` VALUES (106, 'eudiometer', 'eudiometer', 0) ; 
INSERT INTO `wp_terms` VALUES (107, 'excerpt', 'excerpt-2', 0) ; 
INSERT INTO `wp_terms` VALUES (108, 'Fail', 'fail', 0) ; 
INSERT INTO `wp_terms` VALUES (109, 'featured image', 'featured-image', 0) ; 
INSERT INTO `wp_terms` VALUES (110, 'figuriste', 'figuriste', 0) ; 
INSERT INTO `wp_terms` VALUES (111, 'filler', 'filler', 0) ; 
INSERT INTO `wp_terms` VALUES (112, 'formatting', 'formatting-2', 0) ; 
INSERT INTO `wp_terms` VALUES (113, 'FTW', 'ftw', 0) ; 
INSERT INTO `wp_terms` VALUES (114, 'Fun', 'fun', 0) ; 
INSERT INTO `wp_terms` VALUES (115, 'gallery', 'gallery', 0) ; 
INSERT INTO `wp_terms` VALUES (116, 'goes here', 'goes-here', 0) ; 
INSERT INTO `wp_terms` VALUES (117, 'habergeon', 'habergeon', 0) ; 
INSERT INTO `wp_terms` VALUES (118, 'hapless', 'hapless', 0) ; 
INSERT INTO `wp_terms` VALUES (119, 'hartshorn', 'hartshorn', 0) ; 
INSERT INTO `wp_terms` VALUES (120, 'hostility impregnability', 'hostility-impregnability', 0) ; 
INSERT INTO `wp_terms` VALUES (121, 'html', 'html', 0) ; 
INSERT INTO `wp_terms` VALUES (122, 'image', 'image', 0) ; 
INSERT INTO `wp_terms` VALUES (123, 'impropriation', 'impropriation', 0) ; 
INSERT INTO `wp_terms` VALUES (124, 'is', 'is', 0) ; 
INSERT INTO `wp_terms` VALUES (125, 'jetpack', 'jetpack-2', 0) ; 
INSERT INTO `wp_terms` VALUES (126, 'knave', 'knave', 0) ; 
INSERT INTO `wp_terms` VALUES (127, 'layout', 'layout', 0) ; 
INSERT INTO `wp_terms` VALUES (128, 'link', 'link', 0) ; 
INSERT INTO `wp_terms` VALUES (129, 'lists', 'lists-2', 0) ; 
INSERT INTO `wp_terms` VALUES (130, 'lorem', 'lorem', 0) ; 
INSERT INTO `wp_terms` VALUES (131, 'Love', 'love', 0) ; 
INSERT INTO `wp_terms` VALUES (132, 'markup', 'markup-2', 0) ; 
INSERT INTO `wp_terms` VALUES (133, 'media', 'media', 0) ; 
INSERT INTO `wp_terms` VALUES (134, 'misinformed', 'misinformed', 0) ; 
INSERT INTO `wp_terms` VALUES (135, 'moil', 'moil', 0) ; 
INSERT INTO `wp_terms` VALUES (136, 'more', 'more', 0) ; 
INSERT INTO `wp_terms` VALUES (137, 'mornful', 'mornful', 0) ; 
INSERT INTO `wp_terms` VALUES (138, 'Mothership', 'mothership', 0) ; 
INSERT INTO `wp_terms` VALUES (139, 'Must Read', 'mustread', 0) ; 
INSERT INTO `wp_terms` VALUES (140, 'Nailed It', 'nailedit', 0) ; 
INSERT INTO `wp_terms` VALUES (141, 'outlaw', 'outlaw', 0) ; 
INSERT INTO `wp_terms` VALUES (142, 'pagination', 'pagination', 0) ; 
INSERT INTO `wp_terms` VALUES (143, 'pamphjlet', 'pamphjlet', 0) ; 
INSERT INTO `wp_terms` VALUES (144, 'password', 'password-2', 0) ; 
INSERT INTO `wp_terms` VALUES (145, 'Pictures', 'pictures', 0) ; 
INSERT INTO `wp_terms` VALUES (146, 'pingbacks', 'pingbacks-2', 0) ; 
INSERT INTO `wp_terms` VALUES (147, 'pneumatics', 'pneumatics', 0) ; 
INSERT INTO `wp_terms` VALUES (148, 'portly portreeve', 'portly-portreeve', 0) ; 
INSERT INTO `wp_terms` VALUES (149, 'post', 'post', 0) ; 
INSERT INTO `wp_terms` VALUES (150, 'precipitancy', 'precipitancy', 0) ; 
INSERT INTO `wp_terms` VALUES (151, 'privation', 'privation', 0) ; 
INSERT INTO `wp_terms` VALUES (152, 'programme', 'programme', 0) ; 
INSERT INTO `wp_terms` VALUES (153, 'psychological', 'psychological', 0) ; 
INSERT INTO `wp_terms` VALUES (154, 'puncher', 'puncher', 0) ; 
INSERT INTO `wp_terms` VALUES (155, 'quote', 'quote', 0) ; 
INSERT INTO `wp_terms` VALUES (156, 'ramose', 'ramose', 0) ; 
INSERT INTO `wp_terms` VALUES (157, 'read more', 'read-more', 0) ; 
INSERT INTO `wp_terms` VALUES (158, 'readability', 'readability', 0) ; 
INSERT INTO `wp_terms` VALUES (159, 'renegade', 'renegade', 0) ; 
INSERT INTO `wp_terms` VALUES (160, 'retrocede', 'retrocede', 0) ; 
INSERT INTO `wp_terms` VALUES (161, 'shortcode', 'shortcode', 0) ; 
INSERT INTO `wp_terms` VALUES (162, 'stagnation unhorsed', 'stagnation-unhorsed', 0) ; 
INSERT INTO `wp_terms` VALUES (163, 'standard', 'standard-2', 0) ; 
INSERT INTO `wp_terms` VALUES (164, 'status', 'status', 0) ; 
INSERT INTO `wp_terms` VALUES (165, 'sticky', 'sticky-2', 0) ; 
INSERT INTO `wp_terms` VALUES (166, 'Success', 'success', 0) ; 
INSERT INTO `wp_terms` VALUES (167, 'Swagger', 'swagger', 0) ; 
INSERT INTO `wp_terms` VALUES (168, 'Tag A', 'tag-a', 0) ; 
INSERT INTO `wp_terms` VALUES (169, 'Tag B', 'tag-b', 0) ; 
INSERT INTO `wp_terms` VALUES (170, 'Tag C', 'tag-c', 0) ; 
INSERT INTO `wp_terms` VALUES (171, 'Tags', 'tags', 0) ; 
INSERT INTO `wp_terms` VALUES (172, 'template', 'template', 0) ; 
INSERT INTO `wp_terms` VALUES (173, 'text', 'text', 0) ; 
INSERT INTO `wp_terms` VALUES (174, 'the man', 'the-man', 0) ; 
INSERT INTO `wp_terms` VALUES (175, 'thunderheaded', 'thunderheaded', 0) ; 
INSERT INTO `wp_terms` VALUES (176, 'tiled', 'tiled', 0) ; 
INSERT INTO `wp_terms` VALUES (177, 'title', 'title', 0) ; 
INSERT INTO `wp_terms` VALUES (178, 'trackbacks', 'trackbacks-2', 0) ; 
INSERT INTO `wp_terms` VALUES (179, 'twitter', 'twitter-2', 0) ; 
INSERT INTO `wp_terms` VALUES (180, 'unculpable', 'unculpable', 0) ; 
INSERT INTO `wp_terms` VALUES (181, 'Unseen', 'unseen', 0) ; 
INSERT INTO `wp_terms` VALUES (182, 'video', 'video', 0) ; 
INSERT INTO `wp_terms` VALUES (183, 'videopress', 'videopress', 0) ; 
INSERT INTO `wp_terms` VALUES (184, 'withered brandnew', 'withered-brandnew', 0) ; 
INSERT INTO `wp_terms` VALUES (185, 'WordPress', 'wordpress', 0) ; 
INSERT INTO `wp_terms` VALUES (186, 'wordpress.tv', 'wordpress-tv', 0) ; 
INSERT INTO `wp_terms` VALUES (187, 'xanthopsia', 'xanthopsia', 0) ; 
INSERT INTO `wp_terms` VALUES (188, 'All Pages', 'all-pages', 0) ; 
INSERT INTO `wp_terms` VALUES (189, 'Short', 'short', 0) ; 
INSERT INTO `wp_terms` VALUES (190, 'All Pages Flat', 'all-pages-flat', 0) ; 
INSERT INTO `wp_terms` VALUES (191, 'Testing Menu', 'testing-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (192, 'Empty Menu', 'empty-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (193, 'Gallery', 'post-format-gallery', 0) ; 
INSERT INTO `wp_terms` VALUES (194, 'Aside', 'post-format-aside', 0) ; 
INSERT INTO `wp_terms` VALUES (195, 'Chat', 'post-format-chat', 0) ; 
INSERT INTO `wp_terms` VALUES (196, 'Link', 'post-format-link', 0) ; 
INSERT INTO `wp_terms` VALUES (197, 'Image', 'post-format-image', 0) ; 
INSERT INTO `wp_terms` VALUES (198, 'Quote', 'post-format-quote', 0) ; 
INSERT INTO `wp_terms` VALUES (199, 'Status', 'post-format-status', 0) ; 
INSERT INTO `wp_terms` VALUES (200, 'Video', 'post-format-video', 0) ; 
INSERT INTO `wp_terms` VALUES (201, 'Audio', 'post-format-audio', 0) ; 
INSERT INTO `wp_terms` VALUES (202, 'Test Short Menu', 'test-short-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (203, 'Test Long Menu', 'test-long-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (204, 'something', 'something', 0) ; 
INSERT INTO `wp_terms` VALUES (205, 'tag', 'tag', 0) ; 
INSERT INTO `wp_terms` VALUES (206, 'cats', 'cats', 0) ; 
INSERT INTO `wp_terms` VALUES (207, 'cute', 'cute', 0) ; 
INSERT INTO `wp_terms` VALUES (208, 'blockquote', 'blockquote', 0) ; 
INSERT INTO `wp_terms` VALUES (209, 'other', 'other', 0) ; 
INSERT INTO `wp_terms` VALUES (210, 'comma', 'comma', 0) ; 
INSERT INTO `wp_terms` VALUES (211, 'make', 'make', 0) ; 
INSERT INTO `wp_terms` VALUES (212, 'books', 'books', 0) ; 
INSERT INTO `wp_terms` VALUES (213, 'Boston', 'boston', 0) ; 
INSERT INTO `wp_terms` VALUES (214, 'London', 'london', 0) ; 
INSERT INTO `wp_terms` VALUES (215, 'Sofia', 'sofia', 0) ; 
INSERT INTO `wp_terms` VALUES (216, 'Blogroll', 'blogroll', 0) ; 
INSERT INTO `wp_terms` VALUES (217, 'tag1', 'tag1', 0) ; 
INSERT INTO `wp_terms` VALUES (218, 'tag2', 'tag2', 0) ; 
INSERT INTO `wp_terms` VALUES (219, 'tag3', 'tag3', 0) ; 
INSERT INTO `wp_terms` VALUES (220, 'Post Formats', 'post-formats', 0) ; 
INSERT INTO `wp_terms` VALUES (221, 'something', 'something', 0) ; 
INSERT INTO `wp_terms` VALUES (222, 'simple', 'simple', 0) ; 
INSERT INTO `wp_terms` VALUES (223, 'grouped', 'grouped', 0) ; 
INSERT INTO `wp_terms` VALUES (224, 'variable', 'variable', 0) ; 
INSERT INTO `wp_terms` VALUES (225, 'external', 'external', 0) ; 
INSERT INTO `wp_terms` VALUES (226, 'exclude-from-search', 'exclude-from-search', 0) ; 
INSERT INTO `wp_terms` VALUES (227, 'exclude-from-catalog', 'exclude-from-catalog', 0) ; 
INSERT INTO `wp_terms` VALUES (228, 'featured', 'featured', 0) ; 
INSERT INTO `wp_terms` VALUES (229, 'outofstock', 'outofstock', 0) ; 
INSERT INTO `wp_terms` VALUES (230, 'rated-1', 'rated-1', 0) ; 
INSERT INTO `wp_terms` VALUES (231, 'rated-2', 'rated-2', 0) ; 
INSERT INTO `wp_terms` VALUES (232, 'rated-3', 'rated-3', 0) ; 
INSERT INTO `wp_terms` VALUES (233, 'rated-4', 'rated-4', 0) ; 
INSERT INTO `wp_terms` VALUES (234, 'rated-5', 'rated-5', 0) ; 
INSERT INTO `wp_terms` VALUES (235, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (236, 'Accessories', 'accessories', 0) ; 
INSERT INTO `wp_terms` VALUES (237, 'Hoodies', 'hoodies', 0) ; 
INSERT INTO `wp_terms` VALUES (238, 'Tshirts', 'tshirts', 0) ; 
INSERT INTO `wp_terms` VALUES (239, 'tag1', 'tag1', 0) ; 
INSERT INTO `wp_terms` VALUES (240, 'san pham hot', 'san-pham-hot', 0) ; 
INSERT INTO `wp_terms` VALUES (241, 'san pham moi', 'san-pham-moi', 0) ; 
INSERT INTO `wp_terms` VALUES (242, 'san pham khuyen mai', 'san-pham-khuyen-mai', 0) ; 
INSERT INTO `wp_terms` VALUES (243, 'slider', 'slider', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (69 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'default_password_nag', '') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_user-settings', 'libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings-time', '1522033121') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_dashboard_quick_press_last_post_id', '1800') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_native_dashboard_language', 'en_US') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'nav_menu_recently_edited', '17') ; 
INSERT INTO `wp_usermeta` VALUES (22, 2, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (23, 2, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (24, 2, 'nickname', 'Test 1') ; 
INSERT INTO `wp_usermeta` VALUES (25, 2, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (26, 2, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (27, 2, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (28, 2, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (29, 2, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (30, 2, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (31, 2, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (32, 2, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (33, 2, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (34, 3, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (35, 3, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (36, 3, 'nickname', 'Test 2') ; 
INSERT INTO `wp_usermeta` VALUES (37, 3, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (38, 3, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (39, 3, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (40, 3, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (41, 3, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (42, 3, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (43, 3, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (44, 3, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (45, 3, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (46, 4, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (47, 4, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (48, 4, 'nickname', 'Test 3') ; 
INSERT INTO `wp_usermeta` VALUES (49, 4, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (50, 4, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (51, 4, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (52, 4, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (53, 4, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (54, 4, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (55, 4, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (56, 4, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (57, 4, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (61, 1, 'closedpostboxes_post', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (58, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (59, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (60, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (62, 1, 'metaboxhidden_post', 'a:7:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:11:"commentsdiv";i:5;s:7:"slugdiv";i:6;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (63, 1, 'closedpostboxes_project', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (64, 1, 'metaboxhidden_project', 'a:1:{i:0;s:7:"slugdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (65, 1, 'session_tokens', 'a:2:{s:64:"b8cdcaa1ecb68a12b2e47a72adbb2bb4626259e8f4c84986cc3da66f7e47d1cb";a:4:{s:10:"expiration";i:1522206282;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36";s:5:"login";i:1522033482;}s:64:"97e6b8c06b2df26c1bdacca8bd505a07de3a5941148113215c0d9d591d31432a";a:4:{s:10:"expiration";i:1522220080;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36";s:5:"login";i:1522047280;}}') ; 
INSERT INTO `wp_usermeta` VALUES (66, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:1:{s:32:"d7657583058394c828ee150fada65345";a:10:{s:3:"key";s:32:"d7657583058394c828ee150fada65345";s:10:"product_id";i:1838;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:10000;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:10000;s:8:"line_tax";i:0;}}}') ; 
INSERT INTO `wp_usermeta` VALUES (67, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}') ; 
INSERT INTO `wp_usermeta` VALUES (68, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:84:"submitdiv,product_catdiv,tagsdiv-product_tag,postimagediv,woocommerce-product-images";s:6:"normal";s:55:"woocommerce-product-data,postcustom,slugdiv,postexcerpt";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (69, 1, 'screen_layout_product', '2') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (4 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$B.l/3XjIcB8CXX23tRrWJr88pqEImO1', 'admin', 'congnd91@gmail.com', '', '2012-10-02 22:12:12', '', 0, 'admin') ; 
INSERT INTO `wp_users` VALUES (2, 'Test 1', '$P$BpU3BEQRn/e5P0zuC4o6YosrcKMUdu.', 'test-1', '', '', '2014-03-28 08:53:37', '', 0, 'Test 1') ; 
INSERT INTO `wp_users` VALUES (3, 'Test 2', '$P$B9MfFuECAHxPcnd1kkuSK9ZoNPwGLk/', 'test-2', '', '', '2014-03-28 08:53:37', '', 0, 'Test 2') ; 
INSERT INTO `wp_users` VALUES (4, 'Test 3', '$P$BjpR7FQ6HWJ9sBDICxbWwRB9EAffej1', 'test-3', '', '', '2014-03-28 08:53:37', '', 0, 'Test 3') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------


#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wc_download_log (0 records)
#

#
# End of data contents of table wp_wc_download_log
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------


#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  `name` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text NOT NULL,
  `secret` text NOT NULL,
  `topic` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wc_webhooks (0 records)
#

#
# End of data contents of table wp_wc_webhooks
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `permissions` varchar(10) NOT NULL,
  `consumer_key` char(64) NOT NULL,
  `consumer_secret` char(43) NOT NULL,
  `nonces` longtext,
  `truncated_key` char(7) NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_api_keys (0 records)
#

#
# End of data contents of table wp_woocommerce_api_keys
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` varchar(200) DEFAULT NULL,
  `attribute_type` varchar(20) NOT NULL,
  `attribute_orderby` varchar(20) NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_attribute_taxonomies (0 records)
#

#
# End of data contents of table wp_woocommerce_attribute_taxonomies
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_downloadable_product_permissions (0 records)
#

#
# End of data contents of table wp_woocommerce_downloadable_product_permissions
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `context` longtext,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_log (0 records)
#

#
# End of data contents of table wp_woocommerce_log
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_itemmeta (0 records)
#

#
# End of data contents of table wp_woocommerce_order_itemmeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_items (0 records)
#

#
# End of data contents of table wp_woocommerce_order_items
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_payment_tokenmeta (0 records)
#

#
# End of data contents of table wp_woocommerce_payment_tokenmeta
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) NOT NULL,
  `token` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_payment_tokens (0 records)
#

#
# End of data contents of table wp_woocommerce_payment_tokens
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) NOT NULL,
  `session_value` longtext NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_sessions (1 records)
#
 
INSERT INTO `wp_woocommerce_sessions` VALUES (7, '1', 'a:9:{s:4:"cart";s:362:"a:1:{s:32:"d7657583058394c828ee150fada65345";a:10:{s:3:"key";s:32:"d7657583058394c828ee150fada65345";s:10:"product_id";i:1838;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:10000;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:10000;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:414:"a:15:{s:8:"subtotal";s:8:"10000.00";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:4:"0.00";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:8:"10000.00";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:4:"0.00";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:8:"10000.00";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"GB";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"GB";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1522208887) ;
#
# End of data contents of table wp_woocommerce_sessions
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_shipping_zone_locations (0 records)
#

#
# End of data contents of table wp_woocommerce_shipping_zone_locations
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_shipping_zone_methods (0 records)
#

#
# End of data contents of table wp_woocommerce_shipping_zone_methods
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zones`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_shipping_zones (0 records)
#

#
# End of data contents of table wp_woocommerce_shipping_zones
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zones`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rate_locations (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rate_locations
# --------------------------------------------------------

# WordPress : http://127.0.0.1:4001/wordpress MySQL database backup
#
# Generated: Tuesday 27. March 2018 07:51 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_download_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wc_webhooks`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_api_keys`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_payment_tokens`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_sessions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_shipping_zones`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(8) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rates (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rates
# --------------------------------------------------------

