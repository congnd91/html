=== Woocommerce Product Gallery Slider ===
Contributors: im_niloy
Tags: gallery carousel, gallery slider, product gallery slider, vafpress, woocommerce, woocommerce product thumbnails slider 
Requires at least: 3.0.1
Tested up to: 4.7.4
Stable tag: 4.4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Too Many Product Images in your Product Gallery ? This plugin will add a carousel in your Product Gallery.. 

== Description ==
Too Many Product Images in your Product Gallery ? This plugin will add a carousel in your Product Gallery. 


 >[Live Demo](http://iamniloy.com/project/woo-product-gallery-slider) 
 

<br />
### Pro Features
<li> Responsive Layout
<li> Navigation support
<li> Slider AutoPlay Options
<li> Gallery Layout [Vertical and Horizonal Silder]
<li> On/Off LightBox Setting for Thumbnails images
<li> Working with Most of Premium themes
<h3><a href="http://codecanyon.net/item/twist-product-gallery-slidercarousel-plugin-for-woocommerce/14849108?ref=NiloySarker">Get the Pro Version Now</a></h3>   
   
   
   
    
    


== Installation ==



1. Upload `woocommerce-product-gallery-slider` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==
=How do I install this plugin?=
You can install as others regular wordpress plugin. No different way. Please see on installation tab.

== Screenshots ==
 >[Live Demo](http://iamniloy.com/project/woo-product-gallery-slider) 


== Changelog ==
= 1.1.8.2 =
Added : Infinite loop in slider Setting >[Feature Request](https://wordpress.org/support/topic/make-infinite-loop-in-slider/#post-8837626)
= 1.1.8.1 =
Fixed: Gallery Thumbnails of equal size  >[Topic](https://wordpress.org/support/topic/thumbnails-of-equal-size/#post-9060187) 
= 1.1.8 =
Fixed: add missing files
Added: New gallery Setting option in WPGS setting for Woocommerce version 3.0 or later 
= 1.1.7 =
Fixed: woocommerce version 3.0 gallery conflict 
= 1.0 =
* Initial Release
