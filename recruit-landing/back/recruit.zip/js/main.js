(function ($) {
    $(document).on('ready', function () {
        var db = new Object();
        db.preLoad = function () {
            $('#page-loader').delay(800).fadeOut(600, function () {
                $('body').fadeIn();
            });
        }
        db.menuResponsive = function () {
            $('.menu-icon').on('click', function (e) {
                e.stopPropagation();
                $('body').toggleClass("open-menu");
            });
            $('.page').on('click', function () {
                $('body').removeClass("open-menu");
            });
        }
        db.matchHeight = function () {
            if ($('.service-item').length) {
                $('.service-item').matchHeight();
            }
        }
        db.preLoad();
        db.menuResponsive();
    });
})(jQuery);
