$(document).ready(function () {




    $('.page-preload').delay(400).fadeOut(200, function () {
        $('body').fadeIn();
    });

    $('.menu-icon').click(function () {
        var menu = $(".menu");


        if ($(menu).is(":visible")) {

            $("body").removeClass("open-menu");
        } else {

            $("body").addClass("open-menu");
        }


    });



    var owl_gallery = $('.owl-gallery');
    if ($(owl_gallery).length) {
        $(owl_gallery).owlCarousel({
            loop: true,
            margin: 0,
            //mouseDrag: false,
            nav: true,
            smartSpeed: 1000,
            autoplay: false,
            autoplayTimeout: 4000,
            items: 1,
            navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],

            // animateOut: 'fadeOut'
        });
    }


    var owl_feature = $('.owl-feature');
    if ($(owl_feature).length) {
        $(owl_feature).owlCarousel({
            loop: true,
            margin: 0,
            mouseDrag: false,
            nav: false,
            smartSpeed: 1000,
            autoplay: true,
            autoplayTimeout: 6000,
            items: 1,

        });
    }


});
