$(function() {

  // RTL

  if ($('html').attr('dir') === 'rtl') {
    $('.project-actions .dropdown-menu').removeClass('dropdown-menu-right');
  }

});
