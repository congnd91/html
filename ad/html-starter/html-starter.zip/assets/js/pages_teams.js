$(function() {

  // RTL

  if ($('html').attr('dir') === 'rtl') {
    $('.team-actions .dropdown-menu').removeClass('dropdown-menu-right');
  }

});
