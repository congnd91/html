$(function() {
  var map = new GMaps({
    el: '#gmaps-example',
    lat: -12.043333,
    lng: -77.028333
  });
});
