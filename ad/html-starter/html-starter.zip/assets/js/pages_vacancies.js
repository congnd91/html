$(function() {

  // Tooltips

  $('body').tooltip({
    selector: '.vacancy-tooltip'
  });

});
