function validate(step) {

}

function validateStep1() {

}


function validateStep2() {

}


function validateStep3() {

}


function validateStep4() {

}

