$('document').ready(function () {




    // $('.form-step-1').validator()


    $('.form-step-1').validator().on('submit', function (e) {
        if (e.isDefaultPrevented()) {} else {
            e.preventDefault();
            nextStep(2);
        }
    });


    $('.form-step-2').validator().on('submit', function (e) {
        if (e.isDefaultPrevented()) {} else {
            e.preventDefault();
            nextStep(3);
        }
    });

    $('.form-step-3').validator().on('submit', function (e) {
        if (e.isDefaultPrevented()) {} else {
            e.preventDefault();
            nextStep(4);
        }
    });


    $('.input-date-picker').datepicker({});

    $('.btn-step-1').click(function () {
        // nextStep(1);


    });

    $('.btn-step-2').click(function () {

        /*  $('.form-step-1').validator('validate');
          alert("s");*/
        //  nextStep(2);


        var validator = $(".form-step-1").data("bs.validator");
        validator.validate();

        if (!validator.hasErrors()) {
            nextStep(2);
        } else {
            // alert("Please fill in the required fields");
        }

    });

    $('.btn-step-3').click(function () {

        var validator = $(".form-step-1").data("bs.validator");
        validator.validate();

        if (!validator.hasErrors()) {

            nextStep(2);
            var validator1 = $(".form-step-2").data("bs.validator");
            validator1.validate();

            if (!validator1.hasErrors()) {

                nextStep(3);



            } else {
                // alert("Please fill in the required fields");
            }


        } else {
            // alert("Please fill in the required fields");
        }
    });

    $('.btn-step-4').click(function () {
        var validator = $(".form-step-1").data("bs.validator");
        validator.validate();

        if (!validator.hasErrors()) {

            nextStep(2);
            var validator1 = $(".form-step-2").data("bs.validator");
            validator1.validate();

            if (!validator1.hasErrors()) {

                nextStep(3);

                var validator2 = $(".form-step-3").data("bs.validator");
                validator2.validate();

                if (!validator2.hasErrors()) {

                    nextStep(4);



                } else {
                    // alert("Please fill in the required fields");
                }




            } else {
                // alert("Please fill in the required fields");
            }


        } else {
            // alert("Please fill in the required fields");
        }
    });

    $('.input-group-addon').click(function () {
        $(this).parent().find('input').focus();
    });
});

function nextStep(step) {

    var stepCurrent = (step).toString();

    var selectClassFormStepCurrent = ".form-step-" + stepCurrent;
    var selectClassFormStep1 = ".form-step-" + 1;
    var selectClassFormStep2 = ".form-step-" + 2;
    var selectClassFormStep3 = ".form-step-" + 3;
    var selectClassFormStep4 = ".form-step-" + 4;

    //which form fields to show?
    $(selectClassFormStep1).hide();
    $(selectClassFormStep2).hide();
    $(selectClassFormStep3).hide();
    $(selectClassFormStep4).hide();
    $(selectClassFormStepCurrent).show();

    var selectClassProgBarChildCurrent = ".progression-bar li:nth-child(" + stepCurrent + ")";
    var selectClassProgBarChild1 = ".progression-bar li:nth-child(1)";
    var selectClassProgBarChild2 = ".progression-bar li:nth-child(2)";
    var selectClassProgBarChild3 = ".progression-bar li:nth-child(3)";
    var selectClassProgBarChild4 = ".progression-bar li:nth-child(4)";

    //progress bar - which dots to light up?
    if (step < 2) {
        $(selectClassProgBarChild2).removeClass("is-active");
    }
    if (step < 3) {
        $(selectClassProgBarChild3).removeClass("is-active");
    }
    if (step < 4) {
        $(selectClassProgBarChild4).removeClass("is-active");
    }

    if (step > 2) {
        $(selectClassProgBarChild2).addClass("is-active");
    }
    if (step > 3) {
        $(selectClassProgBarChild3).addClass("is-active");
    }
    if (step > 4) {
        $(selectClassProgBarChild4).addClass("is-active");
    }

    $(selectClassProgBarChildCurrent).addClass("is-active");

    //progress bar - which sections to light up?
    var addClassStep = "step-" + stepCurrent;
    $('.progression-bar').removeClass("step-1 step-2 step-3 step-4");
    $('.progression-bar').addClass(addClassStep);
}
