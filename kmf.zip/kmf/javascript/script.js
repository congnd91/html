$('document').ready(function () {
    $('.input-date-picker').datepicker({});
    $('.btn-step-1').click(function () {
        $('.form-step-1').hide();
        $('.form-step-2').show();
        $('.progression-bar').addClass("step-2");
        $('.progression-bar li:nth-child(2)').addClass("is-active");
    });
    $('.btn-step-2').click(function () {
        $('.form-step-2').hide();
        $('.form-step-3').show();
        $('.progression-bar').addClass("step-3");
        $('.progression-bar li:nth-child(3)').addClass("is-active");
    });
    $('.input-group-addon').click(function () {
        $(this).parent().find('input').focus();
    });
});
