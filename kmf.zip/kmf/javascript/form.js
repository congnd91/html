$(document).ready(function () {
    init();
});

function init() {
    setupFloatLabels();
    sameAddress();
    filenameDisplay(); //ToDo
}
/* Sets up and handles the float labels on the inputs. */
function setupFloatLabels() {
    // Check the inputs to see if we should keep the label floating or not
    $('form input').not('button').on('blur', function () {
        // Different validation for different inputs
        switch (this.tagName) {
            case 'SELECT':
                if (this.value > 0) {
                    this.className = 'hasInput';
                } else {
                    this.className = '';
                }
                break;
            case 'INPUT':
                if (this.value !== '') {
                    this.className = 'hasInput';
                } else {
                    this.className = '';
                }
                break;
            default:
                break;
        }
    });
    $('form textarea').on('blur', function () {
        // Different validation for different inputs
        if (this.value !== '') {
            this.className = 'hasInput';
        } else {
            this.className = '';
        }
    });
    return false;
}

function sameAddress() {
    $('#same_address_m').click(function () {
        sameAddressMother();
    });
    $('#same_address_p').click(function () {
        sameAddressFather();
    });
    $('#same_address_g').click(function () {
        sameAddressGuardian();
    });
    //uncheck same address boxes if Home Address changes
    $('#applicant_address').change(function () {
        $("#same_address_m").prop("checked", false);
        $("#same_address_p").prop("checked", false);
        $("#same_address_g").prop("checked", false);
    });
}

function sameAddressMother() {
    if ($("#same_address_m").is(':checked') && $("#applicant_address").val() != "") {
        $("#maternal_address").addClass("hasInput");
        var address = $("#applicant_address").val();
        $("#maternal_address").val(address);
    }
}

function sameAddressFather() {
    if ($("#same_address_p").is(':checked') && $("#applicant_address").val() != "") {
        $("#paternal_address").addClass("hasInput");
        var address = $("#applicant_address").val();
        $("#paternal_address").val(address);
    }
}

function sameAddressGuardian() {
    if ($("#same_address_g").is(':checked') && $("#applicant_address").val() != "") {
        $("#guardian_address").addClass("hasInput");
        var address = $("#applicant_address").val();
        $("#guardian_address").val(address);
    }
}

function filenameDisplay() {
    $('#postsec_transcript').change(function (e) {
        var fileName = e.target.files[0].name;
        alert('The file "' + fileName + '" has been selected.');
        $("#postsec_transcript_filename").text(fileName);
    });
    $('#hs_transcript').change(function (e) {
        var fileName = e.target.files[0].name;
        alert('The file "' + fileName + '" has been selected.');
        $("#hs_transcript_filename").text(fileName);
    });
}
