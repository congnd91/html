<?php include 'header.php'; ?>
<div class='content'>
		<h1> Contact </h1>

		<p> Please email us with any questions at: </br>
		<a href="mailto:president@kohlberg-manacherfoundation.com">president@kohlberg-manacherfoundation.com</a></p>
		<p> No phone calls, please. <br>
		Thank you very much. </p>
		<div class="contact-img-wrap">
			<img class="contact-img" src='./assets/images/kneeling-ninja.svg'>
		</div>
</div>
<?php include 'footer.php'; ?>