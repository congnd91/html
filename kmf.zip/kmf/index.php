<?php include 'header.php'; ?>
    <div class="content">

        <h1 class="main-header"> Ninja Warrior <br> Scholarship Program </h1><img class="main-img" src='./assets/images/ninja.svg'>
        <hr>
        <p> The Kohlberg-Manacher Foundation ('KMF') provides academic scholarships and active
            <br> mentoring to very ambitious, hard-working students from lower-income families in the
            <br> Greater Boston and San Diego Communities.</p>
        <p> Scholarships are up to $7,500 for each academic year and can potentially be renewed
            <br> annually for up to 4 years. Awards are merit and situation-based and are granted without
            <br> regard to race, color, religion,ethnicity, gender or sexual orientation. </p>

        <h2> Eligibility Criteria </h2>
        <hr>
        <p> Applicants must have graduated (or will soon graduate) high school in Greater
            <br> Boston or San Diego communities and have been accepted or be a full-time student
            <br> (any year) at a college, university, vocational, or graduate school.
            <br> Selection criteria include, yet is not limited to, the following: </p>
        <ul>
            <li> Evidence of very high levels of ambition, determination and resiliency </li>
            <li> Academic record, sports, other extra-curricular activities and/or unique skills/capabilities</li>
            <li> Personal and/or family circumstances </li>
            <li> Commitment to giving back to the local community and other KMF scholarship awardees </li>
        </ul>
        <h2> Application Deadline and Scholarship Selection</h2>
        <hr>
        <p> The application deadlines are May 1 for the fall semester and November 1 for the
            <br> spring semester. KMF staff will acknowledge receipt of all applications. In-person or
            <br> video interviews and reference letters may be requested. Awardees will be notified in
            <br> June and December. Scholaship renewal criteria will be discussed with awardees. </p>
        <a href="application.php"><span class="btn btn-primary btn-step-2">Apply Now</span></a>

    </div>

    <?php include 'footer.php'; ?>