</div>
	<div class='footer'>
	<footer>
		<div> ©2020 Kohlberg-Manacher Foundation </div>
		<div> All Rights Reserved </div>
	</footer>
</div>