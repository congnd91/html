<?php include 'header.php'; ?>
<!-- Redirect when there's no JS -->
<!-- https://stackoverflow.com/questions/14121743/php-noscript-combination-to-detect-enabled-javascript-in-browser -->
<!-- Local Storage: -->
<!-- https://stackoverflow.com/questions/17087636/how-to-save-data-from-a-form-with-html5-local-storage -->
<!-- multipage form -->
<!-- https://www.w3schools.com/howto/howto_js_form_steps.asp -->
<?php
session_start();
?>
<div class="content">
    <div class="progress-container">
        <ol class="progression-bar step-1">
            <li class="is-active"><span class="progression-title">Personal and Family</span></li>
            <li class="is-pending"><span class="progression-title">School Information</span></li>
            <li><span class="progression-title">Essay Questions</span></li>
            <li class=""><span class="progression-title">Review</span></li>
        </ol>
    </div>
    <!--fom-step-1-->
    <form action="" name="form-step-1" class="form-step-1">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="name" id="name" />
                        <label for="name">Name</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="homeAddress" id="homeAddress" />
                        <label for="homeAddress">Home Address</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="fieldgroup">
                                <div class="input-date-picker  date">
                                    <input type="text" name="dob" id="dob">
                                    <label for="dob">Date of Birth</label>
                                    <span class="input-group-addon"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="fieldgroup">
                                <input type="text" name="pob" id="pob" />
                                <label for="pob">Place of Birth</label> </div>
                        </div>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="timeInUS" id="timeInUS" />
                        <label for="timeInUS">How long have you live in the U.S.?</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="disabilities" id="disabilities" />
                        <label for="disabilities">List any psychological and/or physical disabilities</label>
                    </div>
                    <div class="mb-5"></div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="email" id="email" />
                        <label for="email">Email</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="applicant-phone" id="applicant-phone" />
                        <label for="applicant-phone">Telephone</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="pt-3">
                            <span>Are you a U.S. citizen?</span>
                            <input type="radio" id="US-yes" name="USCitizen" value="US-yes">Yes
                            <input type="radio" id="US-no" name="USCitizen" value="US-no">No </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="mother-name" id="mother-name" />
                        <label for="mother-name">Mother’s Name</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="address" id="address" />
                        <label for="address">Address</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="year-us" id="year-us" />
                        <label for="year-us">Years in U.S.</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="occ" id="occ" />
                        <label for="occ">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="fieldgroup">
                                <input type="text" name="job" id="job" />
                                <label for="job">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="fieldgroup">
                                <input type="text" name="employer" id="employer" />
                                <label for="employer">Employer</label> </div>
                        </div>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="contact" id="contact" />
                        <label for="contact">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="applicant-phone1" id="applicant-phone1" />
                        <label for="applicant-phone1">Telephone</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="pt-3">
                            <input type="radio" id="US-yes" name="same-address" value="US-yes">Same address
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="fieldgroup">
                        <input type="text" name="city" id="city" />
                        <label for="city">City, State</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="input-date-picker  date">
                            <input type="text" name="dol" id="dol">
                            <label for="dol">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-5"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="father-name" id="father-name" />
                        <label for="father-name">Father’s Name</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="address1" id="address1" />
                        <label for="address1">Address</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="year-us1" id="year-us1" />
                        <label for="year-us1">Years in U.S.</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="occ1" id="occ1" />
                        <label for="occ1">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="fieldgroup">
                                <input type="text" name="job1" id="job1" />
                                <label for="job1">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="fieldgroup">
                                <input type="text" name="employer1" id="employer1" />
                                <label for="employer1">Employer</label> </div>
                        </div>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="contact1" id="contact1" />
                        <label for="contact1">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="applicant-phone2" id="applicant-phone2" />
                        <label for="applicant-phone2">Telephone</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="pt-3">
                            <span></span>
                            <input type="radio" id="US-yes" name="same-address1" value="address">Same address
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="fieldgroup">
                        <input type="text" name="city" id="city" />
                        <label for="city">City, State</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="input-date-picker  date">
                            <input type="text" name="dol1" id="dol1">
                            <label for="dol1">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <textarea name="sna" id="sna"></textarea>
                        <label for="sna">Sibling(s) Name(s) and Age(s):</label>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="guardian-name" id="guardian-name" />
                        <label for="guardian-name">Legal Guardian’s Name (if not mother or father):</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="address2" id="address2" />
                        <label for="address2">Address</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="year-us2" id="year-us2" />
                        <label for="year-us2">Years in U.S.</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="occ2" id="occ2" />
                        <label for="occ2">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="fieldgroup">
                                <input type="text" name="job2" id="job2" />
                                <label for="job2">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="fieldgroup">
                                <input type="text" name="employer2" id="employer2" />
                                <label for="employer2">Employer</label> </div>
                        </div>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="contact2" id="contact2" />
                        <label for="contact1">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="applicant-phone2" id="applicant-phone2" />
                        <label for="lastName">Telephone</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="pt-3">
                            <span></span>
                            <input type="radio" id="US-yes" name="same-address1" value="address">Same address
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="fieldgroup">
                        <input type="text" name="city2" id="city2" />
                        <label for="city2">City, State</label>
                    </div>
                    <div class="fieldgroup">
                        <div class="input-date-picker  date">
                            <input type="text" name="dol2" id="dol2">
                            <label for="dol2">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="guardian-name1" id="guardian-name1" />
                        <label for="guardian-name1">Parents’ / Legal Guardian’s $ annual income (combined)</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="annual" id="annual" />
                        <label for="annual">Annual $ financial support they are able to provide (if any)</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="fieldgroup">
                <span class="btn btn-primay btn-step-1">Next</span>
            </div>
        </div>
    </form>
    <!--fom-step-2-->
    <form action="" name="form-step-2" class="form-step-2">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="high-school" id="high-school" />
                        <label for="high-school">High School</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="state" id="state" />
                        <label for="state">State</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="city" id="city" />
                        <label for="city">City</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="grade-point" id="grade-point" />
                        <label for="grade-point">Grade Point Average (GPA) based on 4.0 scale*</label>
                    </div>
                </div>
                <div class="col-lg-5   col-md-12 col-12">
                    <div class="fieldgroup">
                        <div class="upload-btn-wrapper">
                            <button class="btn btn-primay">Attach Transcript</button>
                            <input type="file" name="myfile" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="note mb-4">
                *You must attach a copy of your transcript to be considered for a KMF Scholarship
            </div>
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <div class="fieldgroup">
                        <label for="mother-name">SAT Scores</label>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-6">
                    <div class="fieldgroup">
                        <input type="text" name="verbal" id="verbal" />
                        <label for="verbal">Verbal</label>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-6">
                    <div class="fieldgroup">
                        <input type="text" name="math" id="math" />
                        <label for="math">Math</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <textarea name="sna" id="sna"></textarea>
                        <label for="sna">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="fieldgroup">
                        <div class="input-date-picker  date">
                            <input type="text" name="gd" id="gd">
                            <label for="gd">Graduation date</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pb-2"></div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <textarea name="employment" id="employment"></textarea>
                        <label for="employment">Employment (part-time and/or summers, last 3 years)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="cc" id="cc" />
                        <label for="cc">Current College/University/Graduate or Vocational School (if applicable)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4  col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="city1" id="city1" />
                        <label for="city1">City</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="state1" id="state1" />
                        <label for="state1">State</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="grade-point" id="grade-point" />
                        <label for="grade-point">Grade Point Average (GPA) based on 4.0 scale*</label>
                    </div>
                </div>
                <div class="col-lg-5   col-md-12 col-12">
                    <div class="fieldgroup">
                        <div class="upload-btn-wrapper">
                            <button class="btn btn-primay">Attach Transcript</button>
                            <input type="file" name="myfile" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="note mb-4">
                *You must attach a copy of your transcript to be considered for a KMF Scholarship
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <textarea name="sco" id="sco"></textarea>
                        <label for="sco">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <textarea name="employment2" id="employment2"></textarea>
                        <label for="employment2">Employment (part-time and/or summers (part-time and/or summers</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup">
                        <label>Target College / University (where you have been accepted and plan to attend)</label>
                    </div>
                    <div class="pb-5"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="name" id="name" />
                        <label for="name">Name</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="state" id="state" />
                        <label for="state">State</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="major" id="major" />
                        <label for="major">What is your likely major?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="city" id="city" />
                        <label for="city">City</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 col-md-12 col-12">
                    <div class="fieldgroup">
                        <input type="text" name="financial" id="financial" />
                        <label for="financial">What financial assistance will be provided by the institution (per year)?</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="contribute" id="contribute" />
                        <label for="contribute">How much are you and your family able to contribute (per year)?</label>
                    </div>
                    <div class="fieldgroup">
                        <input type="text" name="attend" id="attend" />
                        <label for="attend">What is the $ gap between the cost to attend (tuition, room, board, etc.) and your total $ resources?</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="fieldgroup">
                <span class="btn btn-primay btn-step-2">Next</span>
            </div>
        </div>
    </form>
    <!--fom-step-3-->
    <form action="" name="form-step-2" class="form-step-3">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="fieldgroup mb-3">
                        <textarea name="kmf" id="kmf"></textarea>
                        <label for="kmf">Why should KMF award you this scholarship? What is unique and/or special about your achievements and/or circumstances?</label>
                    </div>
                    <div class="fieldgroup mb-3">
                        <textarea name="accomplishments" id="accomplishments"></textarea>
                        <label for="accomplishments">What two accomplishments are you most proud of, and why?</label>
                    </div>
                    <div class="fieldgroup mb-3">
                        <textarea name="significant" id="significant"></textarea>
                        <label for="significant">Provide two example of significant mistakes you have made and what you learned from each one.</label>
                    </div>
                    <div class="fieldgroup mb-3">
                        <textarea name="rate" id="rate"></textarea>
                        <label for="rate">On a scale of 1-100 (with 100 being the highest), how would you rate your level of determination to succeed? Provide one or two examples of situations in which you showed resilience after failing.</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="fieldgroup">
                <span class="btn btn-primay btn-step-3">Next</span>
            </div>
        </div>
    </form>
</div>
<?php include 'footer.php'; ?>
