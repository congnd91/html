<?php include 'header.php'; ?>
<!-- Redirect when there's no JS -->
<!-- https://stackoverflow.com/questions/14121743/php-noscript-combination-to-detect-enabled-javascript-in-browser -->
<!-- Local Storage: -->
<!-- https://stackoverflow.com/questions/17087636/how-to-save-data-from-a-form-with-html5-local-storage -->
<!-- multipage form -->
<!-- https://www.w3schools.com/howto/howto_js_form_steps.asp -->
<?php
session_start();
?>
<div class="content">
    <div class="progress-container">
        <ol class="progression-bar step-1">
            <li class="btn-step-1 is-active"><span class="progression-title">Personal and Family</span></li>
            <li class="btn-step-2 is-pending"><span class="progression-title">School Information</span></li>
            <li class="btn-step-3 "><span class="progression-title">Essay Questions</span></li>
            <li class="btn-step-4 "><span class="progression-title">Review</span></li>
        </ol>
    </div>

    <!--fom-step-1-->
    <form role="form" name="form-step-1" class="form-step-1">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">

                    <div class="form-group">
                        <input required type="text" name="applicant_name" id="applicant_name" />
                        <label for="applicant_name">Name</label>
                    </div>
                    <div class="form-group">
                        <input required type="text" name="applicant_address" id="applicant_address" />
                        <label for="applicant_address">Home Address</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="form-group">
                                <div class="input-date-picker  date">
                                    <input required type="text" name="applicant_dob" id="applicant_dob">
                                    <label for="applicant_dob">Date of Birth</label>
                                    <span class="input-group-addon"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="form-group">
                                <input required type="text" name="applicant_birth_loc" id="applicant_birth_loc" />
                                <label for="applicant_birth_loc">Place of Birth</label> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input required type="text" name="applicant_time_us" id="applicant_time_us" />
                        <label for="applicant_time_us">How long have you live in the U.S.?</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="applicant_disabilities" id="applicant_disabilities" />
                        <label for="applicant_disabilities">List any psychological and/or physical disabilities</label>
                    </div>
                    <div class="mb-5"></div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input required type="text" name="applicant_email" id="applicant_email" />
                        <label for="applicant_email">Email</label>
                    </div>
                    <div class="form-group">
                        <input required type="text" name="applicant_phone" id="applicant_phone" />
                        <label for="applicant_phone">Telephone</label>
                    </div>
                    <div class="form-group">
                        <div class="pt-3 radio-text">
                            <span>Are you a U.S. citizen?</span>
                            <input required type="radio" id="US-yes" name="applicant_us_citizen" value="US-yes">Yes
                            <input type="radio" id="US-no" name="applicant_us_citizen" value="US-no">No </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="maternal_name" id="maternal_name" />
                        <label for="maternal_name">Mother’s Name</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="maternal_address" id="maternal_address" />
                        <label for="maternal_address">Address</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="maternal_time_us" id="maternal_time_us" />
                        <label for="maternal_time_us">Years in U.S.</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="maternal_occupation" id="maternal_occupation" />
                        <label for="maternal_occupation">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="form-group">
                                <input type="text" name="maternal_job" id="maternal_job" />
                                <label for="maternal_job">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="form-group">
                                <input type="text" name="maternal_employer" id="maternal_employer" />
                                <label for="maternal_employer">Employer</label> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="maternal_reg_contact" id="maternal_reg_contact" />
                        <label for="maternal_reg_contact">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="maternal_phone" id="maternal_phone" />
                        <label for="maternal_phone">Telephone</label>
                    </div>
                    <div class="form-group">
                        <div class="pt-3">
                            <input type="checkbox" id="same_address_m" name="same_address_m" value="same_address_m"><span>Same address</span>
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="form-group">
                        <input type="text" name="maternal_employer_loc" id="maternal_employer_loc" />
                        <label for="maternal_employer_loc">City, State</label>
                    </div>
                    <div class="form-group">
                        <div class="input-date-picker  date">
                            <input type="text" name="maternal_last_contact" id="maternal_last_contact">
                            <label for="maternal_last_contact">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-5"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="paternal_name" id="paternal_name" />
                        <label for="paternal_name">Father’s Name</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="paternal_address" id="paternal_address" />
                        <label for="paternal_address">Address</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="paternal_time_us" id="paternal_time_us" />
                        <label for="paternal_time_us">Years in U.S.</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="paternal_occupation" id="paternal_occupation" />
                        <label for="paternal_occupation">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="form-group">
                                <input type="text" name="paternal_job" id="paternal_job" />
                                <label for="paternal_job">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="form-group">
                                <input type="text" name="paternal_employer" id="paternal_employer" />
                                <label for="paternal_employer">Employer</label> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="paternal_last_contact" id="paternal_last_contact" />
                        <label for="paternal_last_contact">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="paternal_phone" id="paternal_phone" />
                        <label for="paternal_phone">Telephone</label>
                    </div>
                    <div class="form-group">
                        <div class="pt-3">
                            <span></span>
                            <input type="checkbox" id="same_address_p" name="same_address_p"><span>Same address</span>
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="form-group">
                        <input type="text" name="paternal_employer_loc" id="paternal_employer_loc" />
                        <label for="paternal_employer_loc">City, State</label>
                    </div>
                    <div class="form-group">
                        <div class="input-date-picker  date">
                            <input type="text" name="paternal_last_contact" id="paternal_last_contact">
                            <label for="paternal_last_contact">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <textarea name="applicant_siblings" id="applicant_siblings"></textarea>
                        <label for="applicant_siblings">Sibling(s) Name(s) and Age(s):</label>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="guardian_name" id="guardian_name" />
                        <label for="guardian_name">Legal Guardian’s Name (if not mother or father):</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="guardian_address" id="guardian_address" />
                        <label for="guardian_address">Address</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="guardian_time_us" id="guardian_time_us" />
                        <label for="guardian_time_us">Years in U.S.</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="guardian_occupation" id="guardian_occupation" />
                        <label for="guardian_occupation">Occupation</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-12">
                            <div class="form-group">
                                <input type="text" name="guardian_job" id="guardian_job" />
                                <label for="guardian_job">Job</label>
                            </div>
                        </div>
                        <div class="col-1 col-md-5 col-12 offset-lg-2 offset-md-2">
                            <div class="form-group">
                                <input type="text" name="guardian_employer" id="guardian_employer" />
                                <label for="guardian_employer">Employer</label> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="guardian_reg_contact" id="guardian_reg_contact" />
                        <label for="guardian_reg_contact">Are you in regular contact with her?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="guardian_phone" id="guardian_phone" />
                        <label for="guardian_phone">Telephone</label>
                    </div>
                    <div class="form-group">
                        <div class="pt-3">
                            <span></span>
                            <input type="checkbox" id="same_address_g" name="same_address_g" value="address"><span>Same address</span>
                        </div>
                    </div>
                    <div class="pt-5 pt-5 pb-5"></div>
                    <div class="form-group">
                        <input type="text" name="guardian_employer_loc" id="guardian_employer_loc" />
                        <label for="guardian_employer_loc">City, State</label>
                    </div>
                    <div class="form-group">
                        <div class="input-date-picker  date">
                            <input type="text" name="guardian_last_contact" id="guardian_last_contact">
                            <label for="guardian_last_contact">Date of last contact</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-4"></div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="guardians_income" id="guardians_income" />
                        <label for="guardians_income">Parents’ / Legal Guardian’s $ annual income (combined)</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="guardians_support" id="guardians_support" />
                        <label for="guardians_support">Annual $ financial support they are able to provide (if any)</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-step-2">Next</button>
            </div>
        </div>
    </form>
    <!--fom-step-2-->
    <form role="form" name="form-step-2" class="form-step-2">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input required type="text" name="hs_name" id="hs_name" />
                        <label for="hs_name">High School</label>
                    </div>
                    <div class="form-group">
                        <input required type="text" name="hs_state" id="hs_state" />
                        <label for="hs_state">State</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input required type="text" name="hs_city" id="hs_city" />
                        <label for="hs_city">City</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input required type="text" name="hs_gpa" id="hs_gpa" />
                        <label for="hs_gpa">Grade Point Average (GPA) based on 4.0 scale*</label>
                    </div>
                </div>
                <div class="col-lg-5   col-md-12 col-12">
                    <div class="form-group">
                        <div class="upload-btn-wrapper">
                            <span class="btn btn-primary">Attach Transcript</span>
                            <input required type="file" name="hs_transcript" id="hs_transcript" />
                            <span id="hs_transcript_filename"></span>
                            <span class="error-text">Please upload file</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="note mb-4">
                *You must attach a copy of your transcript to be considered for a KMF Scholarship
            </div>
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <div class="form-group">
                        <label>SAT Scores</label>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-6">
                    <div class="form-group">
                        <input type="text" name="sat_verbal" id="sat_verbal" />
                        <label for="sat_verbal">Verbal</label>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-6">
                    <div class="form-group">
                        <input type="text" name="sat_math" id="sat_math" />
                        <label for="sat_math">Math</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <textarea required name="hs_extras" id="hs_extras"></textarea>
                        <label for="hs_extras">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="form-group">
                        <div class="input-date-picker  date">
                            <input required type="text" name="grad_date" id="grad_date">
                            <label for="grad_date">Graduation date</label>
                            <span class="input-group-addon"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pb-2"></div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <textarea name="hs_employment" id="hs_employment"></textarea>
                        <label for="hs_employment">Employment (part-time and/or summers, last 3 years)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="current_postsec_name" id="current_postsec_name" />
                        <label for="current_postsec_name">Current College/University/Graduate or Vocational School (if applicable)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4  col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="current_postsec_city" id="current_postsec_city" />
                        <label for="current_postsec_city">City</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="current_postsec_state" id="current_postsec_state" />
                        <label for="current_postsec_state">State</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="current_postsec_gpa" id="current_postsec_gpa" />
                        <label for="current_postsec_gpa">Grade Point Average (GPA) based on 4.0 scale*</label>
                    </div>
                </div>
                <div class="col-lg-5   col-md-12 col-12">
                    <div class="form-group">
                        <div class="upload-btn-wrapper">
                            <span class="btn btn-primary cursor-pointer">Attach Transcript</span>
                            <input type="file" name="postsec_transcript" id="postsec_transcript" />
                            <span id="postsec_transcript_filename"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="note mb-4">
                *You must attach a copy of your transcript to be considered for a KMF Scholarship
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <textarea name="current_postsec_extras" id="current_postsec_extras"></textarea>
                        <label for="current_postsec_extras">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <textarea name="current_postsec_employment" id="current_postsec_employment"></textarea>
                        <label for="current_postsec_employment">Employment (part-time and/or summers (part-time and/or summers</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group">
                        <label>Target College / University (where you have been accepted and plan to attend)</label>
                    </div>
                    <div class="pb-5"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="target_postsec_name" id="target_postsec_name" />
                        <label for="target_postsec_name">Name</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="target_postsec_state" id="target_postsec_state" />
                        <label for="target_postsec_state">State</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="target_major" id="target_major" />
                        <label for="target_major">What is your likely major?</label>
                    </div>
                </div>
                <div class="col-lg-5  offset-lg-1 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="target_postsec_city" id="target_postsec_city" />
                        <label for="target_postsec_city">City</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 col-md-12 col-12">
                    <div class="form-group">
                        <input type="text" name="tuition_assistance" id="tuition_assistance" />
                        <label for="tuition_assistance">What financial assistance will be provided by the institution (per year)?</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="tuition_contributing" id="tuition_contributing" />
                        <label for="tuition_contributing">How much are you and your family able to contribute (per year)?</label>
                    </div>
                    <div class="form-group">
                        <input required type="text" name="tuition_gap" id="tuition_gap" />
                        <label for="tuition_gap">What is the $ gap between the cost to attend (tuition, room, board, etc.) and your total $ resources?</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="form-group">

                <button type="submit" class="btn btn-primary btn-step-3">Next</button>
            </div>
        </div>
    </form>
    <!--fom-step-3-->
    <form role="form" name="form-step-3" class="form-step-3">
        <div class="container container-form">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="form-group mb-3">
                        <textarea required name="kmf" id="longform1"></textarea>
                        <label for="longform1">Why should KMF award you this scholarship? What is unique and/or special about your achievements and/or circumstances?</label>
                    </div>
                    <div class="form-group mb-3">
                        <textarea required name="longform2" id="longform2"></textarea>
                        <label for="longform2">What two accomplishments are you most proud of, and why?</label>
                    </div>
                    <div class="form-group mb-3">
                        <textarea required name="longform3" id="longform3"></textarea>
                        <label for="longform3">Provide two example of significant mistakes you have made and what you learned from each one.</label>
                    </div>
                    <div class="form-group mb-3">
                        <textarea required name="longform4" id="longform4"></textarea>
                        <label for="longform4">On a scale of 1-100 (with 100 being the highest), how would you rate your level of determination to succeed? Provide one or two examples of situations in which you showed resilience after failing.</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 pb-4"></div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-step-4">Next</button>
            </div>
        </div>

        <!--<input class="btn btn-primary" type="submit">-->
    </form>

    <form role="form" name="form-step-4" class="form-step-4">
        <div class="container container-form">


            <div class="mb-4 d-flex align-items-center">
                <span class="caption">Personal and Family</span>
                <a href="#" type="submit" class="btn btn-primary btn-edit ml-3">Edit</a>
            </div>

            <div class="row">

                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Name</span>

                        <p>John Doe</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Name</span>
                        <p>Jj.doe03@gmail.com</p>
                    </div>
                </div>


                <div class="col-lg-8 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Home Address</span>
                        <p>4801 Narragansett Ave, San Diego, CA 92107 USA</p>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Telephone</span>
                        <p>+1 619-226-6250</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Date of Birth</span>
                        <p>02-15-2003</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Place of Birth</span>
                        <p>San Diego, USA</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Are you a U.S. citizen</span>
                        <p>Yes</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">How long have you lived in the U.S.?</span>
                        <p>17 years (all my life)</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">List any psychological and/or physical disabilities:</span>
                        <p>None</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="pb-5">
                    </div>
                </div>

                <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Mother’s Name</span>
                        <p>Agatha Smith</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Telephone</span>
                        <p>+1 619-226-6250</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Home Address</span>
                        <p>4801 Narragansett Ave, San Diego, CA 92107 USA</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Years in U.S.</span>
                        <p>52</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Occupation</span>
                        <p>School Teacher</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Job</span>
                        <p>Elementary School Teacher</p>
                    </div>
                </div>

                <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Job</span>
                        <p>San Diego Unified School District</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Location</span>
                        <p>4741 Santa Monica Ave, San Diego, CA 92107, United States</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Are you in regular contact with her?</span>
                        <p>Yes</p>
                    </div>
                </div>
                <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Date of last contact</span>
                        <p>02-15-2020</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Sibling(s) Name(s) and Age(s):</span>
                        <p>None</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Parents’ / Legal Guardian’s $ annual income (combined)</span>
                        <p>$62,000</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Annual $ financial support they are able to provide to you (if any):</span>
                        <p>$2,000</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="pb-5">
                    </div>
                </div>





            </div>

            <div class="mb-4 d-flex align-items-center">
                <span class="caption">Essay Questions</span>
                <a href="#" type="submit" class="btn btn-primary btn-edit ml-3">Edit</a>
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">High School Name</span>
                        <p>High Tech Middle Media Arts</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">City</span>
                        <p>San Diego</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">State</span>
                        <p>California</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-9 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">GPA</span>
                        <p>3.98</p>
                    </div>
                </div>
                <div class="col-lg-10 col-md-9 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Attached Transcript</span>
                        <p>JDoeGPA2020.txt</p>
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 col-4">

                    <div class="review-field mb-3">
                        <span class="field-caption">Sat Scores</span>
                        <p>1527</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-4">

                    <div class="review-field mb-3">
                        <span class="field-caption">Verbal</span>
                        <p>745</p>
                    </div>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-4 col-4">

                    <div class="review-field mb-3">
                        <span class="field-caption">Math</span>
                        <p>782</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Sports, clubs, other extra-curricular activities, honors and/or unique accomplishments</span>
                        <p>High School Basketball team Point Guard, President of AV club, Winner of Young Film Director's California Festival 2019.</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Graduation date</span>
                        <p>05-5-2020</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Employment (part-time and/or summers, last 3 years)</span>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">TARGET COLLEGE / UNIVERSITY Name</span>
                        <p>CalTech</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">City</span>
                        <p>Pasadena</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">State</span>
                        <p>California</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Likely Major</span>
                        <p>Computer Science</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Financial assistance will be provided by the institution</span>
                        <p>$7,500</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">How much are you and your family able to contribute?</span>
                        <p>$2,000</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">How much are you and your family able to contribute?</span>
                        <p>$4,500</p>
                    </div>
                </div>

            </div>

            <div class="mb-4 d-flex align-items-center">
                <span class="caption">School Information</span>
                <a href="#" type="submit" class="btn btn-primary btn-edit ml-3">Edit</a>
            </div>
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Why should KMF award you this scholarship? What is unique and/or special about your achievements and/or circumstances?</span>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">What two accomplishments are you most proud of?</span>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">Provide two example of significant mistakes you have made and what you learned from each one.</span>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="review-field mb-3">
                        <span class="field-caption">On a scale of 1-100 with 100 being the highest, how would you rate your level of determination to succeed? Provide one or two examples of situations in which you showed resilience after failing at something.</span>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="mb-4 pb-4"></div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-step-4">Submit Application</button>
                    </div>
                </div>
            </div>




        </div>

        <!--<input class="btn btn-primary" type="submit">-->
    </form>
</div>
<?php include 'footer.php'; ?>
