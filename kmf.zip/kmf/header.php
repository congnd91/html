<head>

    <title>Kohlberg-Manacher Foundation Application</title>

    <!-- Dependencies -->
    <script type="text/javascript" src="libraries/jquery/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="libraries/bootstrap/bootstrap-4.4.1-dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="libraries/datepicker/css/bootstrap-datepicker.css">
    <script type="text/javascript" src="libraries/datepicker/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="libraries/validator/validator.js"></script>

    <!-- My scripts and styles -->
    <script type="text/javascript" src="javascript/script.js"></script>
    <script type="text/javascript" src="javascript/form.js"></script>
    <script type="text/javascript" src="javascript/validate.js"></script>


    <link rel="stylesheet" href="css/style.css">


    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">

</head>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-light">
        <div class="d-flex flex-grow-1 logo-container">
            <span class="w-100 d-lg-none d-block"><!-- hidden spacer to center brand on mobile --></span>
            <a class="navbar-brand d-none d-lg-inline-block" id="logo-lg" href="index.php">
            The Kohlberg-Manacher Foundation
        </a>
            <div class="w-100 text-right">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            </div>
        </div>
        <div class="collapse navbar-collapse flex-grow-1 text-right" id="myNavbar">
            <ul class="navbar-nav ml-auto flex-nowrap">
                <li class="nav-item">
                    <a href="index.php" class="nav-link m-2 menu-item nav-active">Home</a>
                </li>
                <li class="nav-item">
                    <a href="application.php" class="nav-link m-2 menu-item">Application</a>
                </li>
                <li class="nav-item">
                    <a href="contact.php" class="nav-link m-2 menu-item">Contact</a>
                </li>
            </ul>
        </div>
    </nav>

</header>
