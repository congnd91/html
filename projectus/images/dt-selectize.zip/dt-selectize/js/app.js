$(function() {
  var log = console.log;
  var countries = window.countries;
  var options = countries.map(c => ({ code: c[0], name: c[1] }));
  log('options', options);

  var tag_create = function(item) {
    return '<div class="dt-tag dt-search-font-size"><img src="img/countries/' + item.code.toLowerCase() + '.png" class="mr-1">' + item.name + '</div>'
  }
  var option_create = function(item) {
    return '<div class="dt-option dt-search-font-size"><img src="img/countries/' + item.code.toLowerCase() + '.png" class="mr-1">' + item.name + '</div>'
  }

  $.each(options, function(index, item) {
    $('#dt-search-tags').append(tag_create(item))
  });

  $('#dt-search-input').selectize({
    options: options,
    valueField: 'name',
    labelField: 'name',
    searchField: 'name',
    plugins: ['remove_button'],
    delimiter: ',',
    create: false,
    render: {
      item: function(item, escape) {
        return tag_create(item);
      },
      option: function(item, escape) {
        return option_create(item);
      }
    },
  });

  var font_size = 18;

  var font_size_update = function(size) {
    var id = 'dt-demo-font-size';
    var sel = '#' + id;
    if ($(sel).length) {
      var $style = $(sel);
    } else {
      var $style = $('<style id="' + id + '" type="text/css"></style>');
      $style.appendTo('body')
    }
    log('font_size_update', size, $style);
    $style.html('.dt-search-font-size {font-size: ' + size + 'px !important;}')
  }
  font_size_update(font_size);


  $('#dt-demo-font-size-changer button').on('click', function() {
    log('click')
    var $input = $(this).closest('.input-group').find('input').first()
    var size = parseInt($input.val());
    size = ($(this).hasClass('increase')) ? size + 1 : size - 1;
    $input.val(size);
    //$('.dt-search-font-size').each(function() {
    //  $(this)[0].style.fontSize = size + 'px';
    //});
    font_size_update(size);
  });


});