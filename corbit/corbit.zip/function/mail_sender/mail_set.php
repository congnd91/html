<?PHP
$phpmail_smtpauth =true;//設定為安全驗證方式 true or false
$phpmail_smtpsecure=""; // ssl  SMTP主機需要使用SSL連線 
$phpmail_host="corbitmed.de"; //SMTP主機 gmail server smtp.gmail.com
$phpmail_user="mailsender@corbitmed.de";//寄信帳號
$phpmail_password="oHoi74@9";//寄信密碼
$phpmail_port="25"; //SMTP主機的SMTP埠位 一般為25   ssl的為465埠。
$phpmail_charset="utf-8";//設定信件字元編碼 big5 or utf-8
?>