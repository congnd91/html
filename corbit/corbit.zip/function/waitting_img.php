<div id="waiting" style="position:absolute; left:0px; top:200px; width:100%; height:80px; z-index:999999;  display: none;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"><img src="<?PHP echo $root_path;?>function/wait.gif" width="300" height="80" /></td>
    </tr>
  </table>
</div>
<div id="waiting_type" style="display: none;" onClick="close_layer_detail()">
<img src="<?PHP echo $root_path;?>function/wait.gif" width="300" height="80" />
</div>
