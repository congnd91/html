##Elegant Icons

This is [Elegant Themes'](http://www.elegantthemes.com/) Elegant Icon Font packaged as a Bower package.

[Original Release](http://www.elegantthemes.com/blog/resources/elegant-icon-font)

### License

As per the original release, this icon font is dual licensed under the [GPL v2.0](http://www.gnu.org/licenses/gpl-2.0.html) and [MIT](http://opensource.org/licenses/MIT) license.