$(document).ready(function() {
	setTimeout(function() {
		$('#loader').fadeOut();
	}, 1000);
});