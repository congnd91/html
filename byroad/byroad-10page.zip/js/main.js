(function ($) {
  $(document).on('ready', function () {
    var db = new Object();
    db.preLoad = function () {
      $('.page-loader').delay(800).fadeOut(600, function () {
        $('body').fadeIn();
      });
    }
    db.menu = function () {
      $('.menu-icon').click(function () {
        $('body').toggleClass("open-menu");
      });
    }
    db.customerSlider = function () {
      var owl = $('.owl-customer');
      $(owl).owlCarousel({
        center: true,
        loop: true,
        margin: 0,
        nav: true,
        responsive: {
          0: {
            items: 1,
          },
          992: {
            items: 3,
          },
        }
      });
    }

    db.mediaSlider = function () {
      var owl = $('.owl-media');
      $(owl).owlCarousel({
        loop: false,
        margin: 5,
        autoWidth: true,
        nav: true,
        responsive: {
          0: {
            items: 3,
          },
          992: {
            items: 4,
          },

          1200: {
            items: 5,
          }
        }
      });
    }
    db.preLoad();
    db.menu();
    db.customerSlider();
    db.mediaSlider();
  });
})(jQuery);
