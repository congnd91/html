<?PHP
$act=trim($_REQUEST["act"]);
if(trim($_REQUEST["act"])==""){
	echo "<script language='javascript'>
	alert('error.');
	</script>";		
	exit;
}



#寄發電子郵件
function SendMail($To, $Subject, $Body, $Name="", $From="", $Cc="", $Bcc="",$language="utf-8",$file="",$filename="") {
	#ini_set("SMTP","giga.smtp.twope.com");
	#ini_set("smtp_port","25");
	// main header (multipart mandatory)
	$From = $From?$From:"";
	$Header .= "MIME-Version: 1.0\r\n";
	if(trim($file)!="" && trim($filename)!=""){
		// a random hash will be necessary to send mixed content
		$separator = md5(time());
		// carriage return type (we use a PHP end of line constant)
		$eol = PHP_EOL;
		$Header .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol . $eol;
		$Header .= "Content-Transfer-Encoding: 7bit" . $eol;
		$Header .= "This is a MIME encoded message." . $eol . $eol;
		// message
		$Header .= "--" . $separator . $eol;
		$Header .= "Content-Type: text/html; charset=".$language."" . $eol;
		$Header .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;
		$Header .= $Body . $eol . $eol;
	}else{
		#To send HTML mail, you can set the Content-type header
		$Header .= "MIME-Version: 1.0\r\n";
		$Header .= "Content-type: text/html; charset=".$language."\r\n";
		$Header .= "Content-Transfer-Encoding: 8bit\r\n";
		$Header .= "X-Mailer: PHP\r\n";
		#To
		if($To) $Header .= "To: $To\r\n";
	}
	if ($language == 'utf-8') {
		$Subject = "=?UTF-8?B?" . base64_encode($Subject) . "?=";
	}
	if ($language == 'utf-8') {
		//$From = "=?UTF-8?B?" . base64_encode($From) . "?=";
	}
	if ($language == 'utf-8') {
		$Name = "=?UTF-8?B?" . base64_encode($Name) . "?=";
	}
	#From
	$Header .= "From: $Name<$From>\r\n";
	#CC
	if($Cc) $Header .= "Cc: $Cc\r\n";
	#BCC
	if($Bcc) $Header .= "Bcc: $Bcc\r\n";
	if(trim($file)!="" && trim($filename)!=""){
		$file_size = filesize($file);
		$handle = fopen($file, "r");
		$content = fread($handle, $file_size);
		fclose($handle);
		$content = chunk_split(base64_encode($content));
		// a random hash will be necessary to send mixed content
		$separator = md5(time());
		// carriage return type (we use a PHP end of line constant)
		$eol = PHP_EOL;
		// attachment
		$Header .= "--" . $separator . $eol;
		$Header .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"" . $eol;
		$Header .= "Content-Transfer-Encoding: base64" . $eol;
		$Header .= "Content-Disposition: attachment" . $eol . $eol;
		$Header .= $content . $eol . $eol;
		$Header .= "--" . $separator . "--";
	}
	if(Mail($To, $Subject, $Body, $Header))
		return True;
}
$act=intval($_REQUEST["act"]);
$email_title="corbit ";
$host_mailer="mailsender@corbitmed.de";
if($act==1){
	include("function/js_act.php");
	include("mod/contact.php");
}elseif($act==91){
	include("function/js_act.php");
	include("mod/contact_index.php");
}else{
	echo "<script language='javascript'>
	alert('error.');
	 </script>";		
	exit;
}
?>