<?
$phpmail_smtpauth =false;//設定為安全驗證方式 true or false
$phpmail_smtpsecure=""; // ssl  SMTP主機需要使用SSL連線 
$phpmail_host="msa.hinet.net"; //SMTP主機 gmail server smtp.gmail.com
$phpmail_user="";//寄信帳號
$phpmail_password="";//寄信密碼
$phpmail_port="25"; //SMTP主機的SMTP埠位 一般為25   ssl的為465埠。
$phpmail_charset="utf-8";//設定信件字元編碼 big5 or utf-8
/*相關參數
$phpmail_subject="";//郵件標題
$phpmail_body="";//郵件內容
$phpmail_frommail="";//寄件人Email
$$phpmail_fromname="";//寄件人名稱
$phpmail_address_list=array();//收件人Email陣列
$phpmail_addreplyto="";//回信Email
$phpmail_files_list=array();//檔案陣列 陣列 array("檔案位置","檔案名稱");
*/
?>