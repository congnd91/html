<script src="<?PHP echo $root_path;?>function/jquery-2.1.0.min.js"></script>
<script src="<?PHP echo $root_path;?>function/ui/jquery.blockUI.js"></script>
<SCRIPT language=JavaScript src="<?PHP echo $root_path;?>function/ui/jquery.form.js"></SCRIPT> 
<script language="JavaScript" src="<?PHP echo $root_path;?>function/script.js"></script>
<script language="javascript">
function close_layer_detail(){
	$.unblockUI();
}
</script>