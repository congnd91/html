<!doctype html>
<html lang="en">
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119974515-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119974515-1');
</script>
<meta charset="UTF-8">
<title>corbit GmbH – Kontaktmöglichkeit</title>
<meta name="description" content="Nutzen Sie zur Kontaktaufnahme einfach unser Kontaktformular. Wir melden uns schnellstmöglich bei Ihnen">
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes,maximum-scale=5.0,minimum-scale=1.0">
<link href='favicon.ico' rel='icon' type='image/x-icon'/>
<link rel="stylesheet" href="css/cms-index.css" type="text/css">
<link rel="stylesheet" href="css/cms-header.css" type="text/css">
<link rel="stylesheet" href="css/cms-footer.css" type="text/css">

<script src="function/jquery-2.1.0.min.js"></script>
<SCRIPT language=JavaScript src="function/ui/jquery.form.js"></SCRIPT> 
<SCRIPT language=JavaScript src="function/ajax_function.js"></SCRIPT> 
<script language="JavaScript" src="function/script_en.js"></script>
<script language="javascript">
function open_loading_status(loading_name){
    width=$('#'+loading_name).css('width').replace("px","");
    height=$('#'+loading_name).css('height').replace("px","");
    $.blockUI({
    message:$('#'+loading_name),
        css:{ 
        cursor:'default',
        border:'',
        backgroundColor:'',
        width: width + 'px',
        height:height+ 'px',
        padding:'0px',
        top:($(window).height()-height)/2 + 'px',
        left:($(window).width()-width)/2 + 'px'
        }
    });
}
function close_layer_detail(){
    $.unblockUI();
}
//end
</script>

<link rel="stylesheet" href="scripts/menubar/meanmenu.css" media="all" />

<link rel="stylesheet" type="text/css" href="scripts/slick-master/slick/slick.css"/>

<link rel="stylesheet" href="scripts/venobox/venobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="scripts/venobox/venobox.min.js"></script>

<link rel="stylesheet" type="text/css" href="css/ac-globalfooter.built.css" />

</head>

<body>
<header>
	<div class="logo"><a href="index.html"><img src="images/logo.gif"></a></div>
	<nav>
		<ul>
			<li><a href="index.html">HOME</a></li>
			<li><a href="produkteneuheit.html">FÜR DICH</a></li>
			<li><a href="unserspirit.html">UNSER SPIRIT</a></li>
			<li><a href="blog.html">BLOG</a></li>
			<li><a href="kontakt.php" class="action">KONTAKT</a></li>
		</ul>
	</nav>
</header>
<div id="content" class="a">	
<!--
	<div class="contact-top">
        <h1><br>Kontaktieren Sie uns</h1>
    </div>
-->

<div class="iframe">
        <div>corbit GmbH, Brühlstraße 19, D-30169 Hannover, Tel.: +49 (0) 511/219 388 83, Email: info@corbitmed.de</div>
       <div id="map"></div>
       <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBy9YqmoE1-FGjOG3Vz44jbgTHGCo4-LyY&callback=initMap"></script>
       <script>
        function initMap() {
            var latlng = { lat: 52.376664,lng: 9.724599 };
          var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
            center: latlng
          });

          var image = 'images/map.png';
          var beachMarker = new google.maps.Marker({
            position: latlng,
            map: map,
            icon: image,
            title: 'corbit GmbH'
          });

        }
        </script>
        <style>
        #map {
            height: 350px;
            }
        </style>
        </div>

<?PHP
$category_list=array();
$category_list[]="Produkte";
$category_list[]="Shop und Bestellungen";
$category_list[]="Service";
$category_list[]="Mein corbit";
$category_list[]="Partnerschaft & Kooperation";
$category_list[]="Andere";
$category_list[]="Feedback";
?>
<form  method="post" name="service_form" id="service_form">
    <div class="about-content contact-content">
    	Vielen Dank für Ihren Besuch auf unserer Homepage. Wenn Sie Anmerkungen, Anfragen oder Fragen zu unseren Produkten haben, füllen Sie bitte unser Kontaktformular aus.<br>Wir werden uns in Kürze mit Ihnen in Verbindung setzen.
        <div class="contact-content-note">(Die mit * gekennzeichneten Felder sind Pflichtfelder.)</div>
        <div class="contact-select">
        	<span>Wählen Sie eine Kategorie, die Ihr Anliegen am besten beschreibt:</span>
           <select name="data_category" id="data_category">
           <option value="">Wähle eine Kategorie</option>
<?PHP
for($i=0;$i<count($category_list);$i++){
?>
           <option value="<?PHP echo trim($category_list[$i]);?>"><?PHP echo trim($category_list[$i]);?></option>
<?PHP }//for?>
           </select>
        </div>
    </div>
    <div class="content-Box contact-form">
    	<div class="about-content contact-content">
        	<div class="contact-form-title">Unsere Informationen</div>
           <table class="contact-form-table">
           	<tr>
            		<th>Name <i>*</i></th>
                  <td><input name="data_name" type="text" id="data_name" placeholder="Vor- und Nachname"></td>
            	</tr>
           	<tr>
            		<th>E-mail Address <i>*</i></th>
                  <td><input name="data_email" type="email" id="data_email" placeholder="Email"></td>
            	</tr>
           	<tr>
            		<th>Land <i>*</i></th>
                  <td>
<select name="data_country" id="data_country">
<option value="">Bitte wählen Sie Ihr Land</option>
<?PHP

//國家清單
$world_country_list=array();
$world_country_list[]="Germany";
$world_country_list[]="USA";
for($i=0;$i<count($world_country_list);$i++){
?>
           <option value="<?PHP echo trim($world_country_list[$i]);?>"><?PHP echo trim($world_country_list[$i]);?></option>
<?PHP }//for?>
</select></td>
            	</tr>
           	<tr>
            		<th>Telefon</th>
                  <td><input name="data_tel" type="phone" id="data_tel" placeholder="Telefonnummer"></td>
            	</tr>
           	<tr>
            		<th>Adresse</th>
                  <td><input type="text" name="data_address" id="data_address" placeholder="Adresse"></td>
            	</tr>
           <!-- <tr>
            		<th>Betreff</th>
                  <td><input type="text" name="data_subject" id="data_subject" placeholder="Betreff"></td>
            	</tr> -->
           	<tr>
            		<th>Ihre Informationen</th>
                  <td><textarea name="data_note" id="data_note" placeholder="Ihre Informationen"></textarea></td>
            	</tr>
               <tr>
               	<td colspan="2">
                		<div class="contact-form-btn">
                   <!-- <a style="cursor:pointer" onClick="$('#service_form').resetForm();" id="resetbtn" class="btn-1 submitbtn">Reset</a> -->
                      	<a style="cursor:pointer" onClick="submit_btn()" id="submitbtn" class="btn-2 submitbtn">Abschicken</a><span id="loading_msg"></span>
                      </div>
                	</td>
               </tr>
           </table>
        </div>
    </div>
<input type="hidden" name="act" id="act" value="1">
</form>


<script language="javascript">
function wirte_iframe(){
	$('#iframe_string').html("<iframe height='0' name='rundata_action' frameborder='0' scrolling='no' width='0' style='display:none' title=''></iframe>");
}
</script>
<span id="iframe_string"></span>
<script language="javascript">
function submit_btn(){
	var error='';
	if($("#data_name").val()==""){
		error=error+"\n--Name is required.";
	}
	if($("#data_email").val()==""){
		error=error+"\n--E-mail is required.";
	}else if(! isEmail($("#data_email").val())){
		error=error+"\n--E-mail must contain an e-mail address.";
	}
	if($("#data_country").val()==""){
		error=error+"\n--Land is required.";
	}
	if(error!=""){
		error="Error:"+error;
		alert(error);
		return false;
	}
	wirte_iframe();
	$('#service_form').attr('target','rundata_action');
	$('#service_form').attr('action','act.php');
	$(".submitbtn").hide();
	$("#loading_msg").html('Loading....');
	$('#service_form').submit();
}
</script>
</div>
<footer class="content-Box">
       <div class="copyright"><span>Copyright © 2018 corbit GmbH</span> <span><!--All rights reserved.--></span></div>
        <div class="footer-bottom-link">
        	
        	<div class="footer-bottom-link-r">
				<a href="messe.html" class="text">Messe</a> 
				<a href="Karriere.html" class="text">Karriere</a> 
                <a href="impressum.html" class="text">Impressum</a>
                <a href="datenschutz.html" class="text">Datenschutz</a>
            	<a href="https://plus.google.com/112520038015305679181" target="_blank"><img src="images/icon-gplus.png"></a>
           	<a href="https://www.linkedin.com/company/corbit-gmbh" target="_blank"><img src="images/icon-in.png"></a>
				<a href="https://www.xing.com/xbp/pages/corbit-gmbh" target="_blank"><img src="images/icon-xing.png"></a></div>
        </div>
</footer>
<div id="gotop"><a class="fa fa-chevron-up"></a></div>

<script src="scripts/menubar/jquery.meanmenu.js"></script>
<script>
	jQuery(document).ready(function () {
	    jQuery('header nav').meanmenu();
	});
</script>

<script type="text/javascript" src="scripts/slick-master/slick/slick.js"></script>
<script type="text/javascript" src="scripts/slick-master/js/scripts.js"></script>

<script type="text/javascript" src="scripts/customer.js"></script>

<script type="text/javascript" src="scripts/jsManage.js"></script>
</body>
</html>
