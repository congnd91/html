    $(document).ready(function () {
        $('.page-preload').delay(400).fadeOut(200, function () {
            $('body').fadeIn();
        });
        $('.info').on('click', function (e) {
            e.stopPropagation();
            $(this).toggleClass("show");
        });
        $('.totop-icon').click(function () {
            $('html, body').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        $('.menu-mobile .caption').click(function () {
            var content = $(this).next();
            if ($(content).is(":visible")) {
                $(content).hide();
            } else {
                $(content).show();
            }
        });
    });
